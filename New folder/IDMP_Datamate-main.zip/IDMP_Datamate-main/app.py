# app.py

import os
import json
from flask import Flask, request, render_template, redirect, url_for, flash
from werkzeug.utils import secure_filename

# Import your existing extraction functions
from Extraction import main

UPLOAD_FOLDER = "uploads"
ALLOWED_EXTENSIONS = {"pdf"}

app = Flask(__name__)
app.config["UPLOAD_FOLDER"] = UPLOAD_FOLDER
app.secret_key = os.urandom(24)

# ensure upload folder exists
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS

@app.route("/", methods=["GET"])
def index():
    # Show upload form (and results if present)
    return render_template("index.html", result=None)

@app.route("/upload", methods=["POST"])
def upload():
    if "pdf_file" not in request.files:
        flash("No file part")
        return redirect(url_for("index"))
    file = request.files["pdf_file"]
    if file.filename == "":
        flash("No selected file")
        return redirect(url_for("index"))
    if not allowed_file(file.filename):
        flash("Only PDF files allowed")
        return redirect(url_for("index"))

    filename = secure_filename(file.filename)
    filepath = os.path.join(app.config["UPLOAD_FOLDER"], filename)
    file.save(filepath)

    # --- Extraction pipeline ---
    # try:
        # 4. Run extraction
    result = main(filepath)
    # except Exception as e:
    #     flash(f"Extraction error: {e}")
    #     return redirect(url_for("index"))

    # Render the same template, but now with `result` populated
    return render_template("index.html", result=result, indent=2)

if __name__ == "__main__":
    app.run(debug=True)

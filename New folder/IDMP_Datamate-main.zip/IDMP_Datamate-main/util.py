import re
import json
def get_codes(source_file, filters: dict,output):
    condition = True
    for key, value in filters.items():
        condition &= source_file[key].str.lower() == str(value).lower()
    filtered = source_file[condition]
    if len(filtered) > 0:
        return str(filtered[output].values[0])
    return ""
def get_batches(instructions):
    """Create a dictionary of batches for sections from the bot instructions file"""
    batches = {}
    duplicate_batches = {}
    current_sec = None
    original_fields = []
    duplicate_fields = []

    for _, row in instructions.iterrows():
        out_sec = row['Output Section']

        # on section change, flush previous data if not empty
        if out_sec != current_sec:
            if current_sec is not None:
                if original_fields:
                    batches[current_sec] = original_fields
                if duplicate_fields:
                    duplicate_batches[current_sec] = duplicate_fields
            # reset lists for new section
            original_fields = []
            duplicate_fields = []
            current_sec = out_sec

        # build field dicts
        if not row['Existing']:
            fields = {
                'section': row['Section'],
                'name': row['Field Name'],
                'code': row['Code'],
                'keywords': row['Keywords'],
                'description': row['Description']
            }
            original_fields.append(fields)
        else:
            dup = {
                'section': row['Section'],
                'name': row['Field Name'],
                'Existing Section': row['Existing Section'],
                'code': row['Code'],
                'Existing Label': row['Existing Label']
            }
            duplicate_fields.append(dup)

    # flush last section if not empty
    if current_sec is not None:
        if original_fields:
            batches[current_sec] = original_fields
        if duplicate_fields:
            duplicate_batches[current_sec] = duplicate_fields

    return batches, duplicate_batches
def get_storage_code(storage_codes,terms,language="en"):
    lang_filtered = storage_codes[storage_codes['Language']==language]
    final = []
    for item in terms:
        cleaned_item = item.lower().strip(".,")
        code = get_codes(lang_filtered, {"Term Name": cleaned_item}, 'Term ID')
        if code:
            final.append(f'{item} ({code})')
        else:
            remaining = cleaned_item

            for _, row in lang_filtered.iterrows():
                term = row['Term Name'].lower().strip(".,")
                if term in remaining:
                    final.append(f'{term} ({row['Term ID']})')
                    # Remove matched term from remaining text
                    remaining = re.sub(r'\b' + re.escape(term) + r'\b', '', remaining).strip()
            return final, remaining.strip()
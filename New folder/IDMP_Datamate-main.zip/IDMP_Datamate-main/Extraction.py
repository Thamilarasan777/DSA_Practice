import logging
import time
logger = logging.getLogger(__name__)
logger.setLevel(logging.DEBUG)
# Console handler
console_handler = logging.StreamHandler()
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
console_handler.setFormatter(formatter)
logger.addHandler(console_handler)
# File handler
file_handler = logging.FileHandler('application.log')
file_handler.setFormatter(formatter)
logger.addHandler(file_handler)
import json
from langchain.schema import HumanMessage
import re
from pathlib import Path
from json import JSONDecoder 
from typing import List, Dict, Optional
from langchain_community.document_loaders import PyPDFLoader, UnstructuredPDFLoader
from langchain_ollama import OllamaEmbeddings, ChatOllama
from langchain_community.vectorstores import FAISS
from langchain.chains import LLMChain
from langchain.prompts import ChatPromptTemplate
from typing import List, Optional, Tuple
from langchain.text_splitter import CharacterTextSplitter
from typing import List, Tuple
from rank_bm25 import BM25Okapi
from langchain_community.retrievers import BM25Retriever
import pandas as pd
import util
instructions = pd.read_excel("refrence files/IDMP_Requirement_instructions.xlsx",sheet_name="Bot_Instructions",keep_default_na=False)
country_codes = pd.read_csv("refrence files/DataSets/Country-codes.csv",keep_default_na=False)
material_codes = pd.read_excel("refrence files/rms-export-2025-07-16T14-16-50.xlsx",keep_default_na=False)
language_codes = pd.read_excel("refrence files/Language code_EMA.xlsx",keep_default_na=False)
route_of_administration_codes = pd.read_excel("refrence files/Route of Administration EMA Codes.xlsx",keep_default_na=False)
quantity_operator_codes = pd.read_excel("refrence files/Quantity operators EMA codes.xlsx",keep_default_na=False)
dosage_form_codes = pd.read_excel("refrence files/Pharmaceutical Dose Form.xlsx",keep_default_na=False)
shubstance_codes = pd.read_excel("refrence files/sms-substances-list-20250411030207.xlsx",keep_default_na=False)
storage_codes = pd.read_csv("refrence files/100000073344.csv",keep_default_na=False)
unit_codes = pd.read_csv("refrence files/Units of Presentations.csv",keep_default_na=False)
package_type_code = pd.read_excel("refrence files/Package Item Type.xlsx",keep_default_na=False)
ingredient_role_code = pd.read_excel("refrence files/Ingredient Role.xlsx",keep_default_na=False)
language_short = pd.read_csv("refrence files/language_short_name.csv",keep_default_na=False)
language_dic = {value.values[1]:value.values[0].lower() for index,value in language_short.iterrows()}
from dotenv import load_dotenv
import os
load_dotenv()
# === Configuration ===
BASE_URL = os.getenv("BASE_URL")
# EMBED_MODEL = os.getenv("EMBED_MODEL")
MODEL = os.getenv("MODEL")
logger.info(f"Loading llm Model- {MODEL}")
# LLM initialization 
llm = ChatOllama(
    model=MODEL,
    temperature=0,
    base_url=BASE_URL,
)

# # Embeddings initialization
# embeddings = OllamaEmbeddings(
#     model=EMBED_MODEL,
#     base_url=BASE_URL,
# )

# --- Functions ---
import re
import fitz  # PyMuPDF

def chunk_pdf_by_sections_with_bold(
    pdf_path,
    font_size_threshold=8.0,   # ← tuned down
    debug=False
):
    logger.info(f"Section spliting started")
    heading_re = re.compile(r'^\d+(\.\d+)*\b')
    chunks = []
    current = {"heading": None, "content": []}

    doc = fitz.open(pdf_path)
    for page_num, page in enumerate(doc, start=1):
        for block in page.get_text("dict")["blocks"]:
            if "lines" not in block:
                continue
            # print("hi ehllo")
            # print(block)
            for line in block["lines"]:
                line_text = "".join(span["text"] for span in line["spans"]).strip()
                if not line_text:
                    continue

                sizes = [span["size"] for span in line["spans"]]
                max_size = max(sizes)
                # look for "-Bold" or "_Bd" in the font name
                has_bold = any(
                    re.search(r'[-_]Bold', span.get("font", ""), re.IGNORECASE)
                    for span in line["spans"]
                )

                is_heading = (
                    heading_re.match(line_text)
                    and max_size >= font_size_threshold
                    and has_bold
                )

                if debug and (heading_re.match(line_text) or has_bold):
                    print(
                        f"[DEBUG] Pg {page_num:>2} | '{line_text[:30]}…' | "
                        f"max_size={max_size:.1f} | bold={has_bold} | heading? {is_heading}"
                    )

                if is_heading:
                    # close out the previous section
                    if current["heading"] is not None:
                        chunks.append({
                            "heading": current["heading"],
                            "content": "\n".join(current["content"]).strip()
                        })
                    # start a new section
                    current = {"heading": line_text, "content": []}
                else:
                    # collect body text
                    if current["heading"]:
                        current["content"].append(line_text)

    # append the last one
    if current["heading"] is not None:
        chunks.append({
            "heading": current["heading"],
            "content": "\n".join(current["content"]).strip()
        })

    doc.close()
    return chunks


def format_retrieval_query_for_batch(
    batch: List[Dict[str, Optional[str]]]
) -> str:
    """
    Build a concise retrieval query from the batch.
    E.g., include field names and section hints to focus similarity search.
    """
    parts = []
    for info in batch:
        name = info.get("name")
        section = info.get("section", "").strip() if info.get("section") else ""
        keywords = info.get("keywords", "").strip() if info.get("keywords") else ""
        if section:
            parts.append(f"{name} in '{section}'")
        else:
            parts.append(name)
        if keywords:
            parts.append(keywords)
    # Join with commas; you could also add verbs like "find info about ..."
    query = " , ".join(parts)
    # Optionally prepend something like "Find text about ..."
    return f"{query}"


def format_question_for_batch(
    batch: List[Dict[str, Optional[str]]]
) -> str:
    """
    Given a batch of field-info dicts, build a question string that includes:
      - field name
      - description
      - optional section hint
    Returns a bullet-list style question for the LLM.
    """
    lines = ["Extract the following fields as **JSON**:"]
    for info in batch:
        name = info.get("name").strip().replace(" ","_").lower()
        desc = info.get("description", "").strip()
        section = info.get("section", "").strip() if info.get("section") else None
        bullet = f"- {name}"
        details = []
        if desc:
            details.append(f"Instruction: '{desc}'")
        if section:
            if section not in lines:
                details.append(f"section hint: '{section}'")
        if details:
            bullet += " (" + "; ".join(details) + ")"
        lines.append(bullet)
    return "\n".join(lines)

def build_llm_chain(llm) -> LLMChain:
    """
    Build an LLMChain with fixed system and human prompts.
    The system prompt instructs the model to output valid JSON only.
    The human prompt inserts the retrieved context and question.
    """
    system_prompt = (
        "You should return JSON response only." \
        "Do not hallucinate, try to give response only from the text.\n"
    )
    human_template = (
        "Given the following extracted text from drug detail PDFs, answer the request below and "
        "return EXACTLY a **JSON** object with the keys specified (no extra keys).\n"
        "Return empty string if you cannot find values.\n\n"
        "Contex:\n\n{context}\n\n"
        "Request: {question}"
    )

    # Create a ChatPromptTemplate with system and user roles
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_prompt),
        ("user", human_template),
    ])
    # Build and return the LLMChain
    chain = LLMChain(llm=llm, prompt=prompt)
    return chain
import re
from typing import List, Dict

def retrieve_section_text(
    chunks: List[Dict[str, str]],
    sections: List[str]
) -> str:
    """
    Retrieve combined text for the given sections.
    
    - Purely numeric section keys (e.g. "1.", "2.3") match by numeric prefix.
    - Any key containing letters matches by substring of the heading.
    """
    # Pre-compile regexes
    num_re    = re.compile(r'^(\d+(?:\.\d+)*)')         # to extract heading prefix
    pure_num  = re.compile(r'^\d+(?:\.\d+)*\.?$')       # to recognize "1." or "2.3"
    
    # Classify requests
    numeric_only = set()
    textual_only = []
    for sec in sections:
        s = sec.strip()
        if pure_num.match(s):
            # normalize "1." -> "1"
            numeric_only.add(s.rstrip('.'))
        else:
            textual_only.append(s.lower())

    collected = []
    seen = set()

    for chunk in chunks:
        heading = chunk["heading"].strip()
        heading_lower = heading.lower()

        # Extract numeric prefix if it exists
        m = num_re.match(heading)
        num_prefix = m.group(1) if m else None

        matched = False

        # 1) try numeric-only matches
        if num_prefix:
            for num in numeric_only:
                if num_prefix == num or num_prefix.startswith(num + "."):
                    matched = True
                    break

        # 2) if not numeric-matched, try textual matches
        if not matched:
            for txt in textual_only:
                if txt in heading_lower:
                    matched = True
                    break

        # 3) collect content if matched
        if matched:
            content = chunk['heading']+"\n"+chunk["content"]
            if content and content not in seen:
                seen.add(content)
                collected.append(content)

    return collected

def get_role(values, role,language="en"):
    final_list = []
    for val in values:
        sub_code = util.get_codes(shubstance_codes,{"Language":language_dic[language],"Substance_Name":val.lower().replace("–","-")},'#SMS_ID')
        ingredient_code = util.get_codes(ingredient_role_code,{"Language":language,"Term Name":role.lower()},"Term ID")
        quantity_code = util.get_codes(quantity_operator_codes,{"Term Name":"equal to"},'Identifier')
        final_list.append({"Substance":val +" ("+str(sub_code)+")", "Ingredient role":role+" ("+ingredient_code+")",
                           "quantity_operator":"equal to ("+str(quantity_code)+")","denominator:":"1 tablet"})

    return final_list
  
def extract_fields_multi_step(
    chunk_texts,
    batches: Dict[str, List[Dict[str, Optional[str]]]],
    llm_chain: LLMChain,
    dublicate_batches
) -> Dict[str, Dict[str, str]]:
    """
    For each batch of field-info dicts:
      - Build separate retrieval query
      - Retrieve relevant chunks & print for debugging
      - Combine retrieved chunks as context
      - Build full LLM question
      - Invoke LLM chain to get JSON response
      - Parse and merge into final_result
    """
    # faiss_index, bm25 = vectorstore
    final_result: Dict[str, Dict[str, str]] = {}
    debug_details: Dict[str, str] = {}

    for out_section, batch in batches.items():
        print(f"Extracting {out_section}")
        final_result[out_section] = {}
        debug_details[out_section] = {}

        section_list = list({"6.3" if sec['section']=="" else sec['section'] for sec in batch })
        # Retrieve relevant chunks
        chunks = retrieve_section_text(chunk_texts,section_list)
        # Combine retrieved content as context string
        context = "\n\n".join([chunk for chunk in chunks])
        debug_details[out_section]['chunks'] = "\n\n".join(f"{'='*50}\n{c}" for c in chunks)

        # Build full LLM question
        question = format_question_for_batch(batch)
        debug_details[out_section]['rag_query'] = question
        # Invoke the LLM chain
        try:
            time.sleep(1)
            ai_response = llm_chain.invoke({"context": context, "question": question})
        except Exception as e:
            logging.info(f"[extract_fields_multi_step] LLM chain invocation failed: {e}")
            continue
        response_text1 = ai_response["text"].strip()
        response_text = re.sub(r"^```json\s*|\s*```$", "", response_text1, flags=re.IGNORECASE).strip()
        # 6. Parse JSON output
        try:
            decoder = JSONDecoder()
            parsed, idx = decoder.raw_decode(response_text)
            if not isinstance(parsed, dict):
                raise ValueError("Parsed JSON is not an object")
        except Exception as e:
            logging.error(f"[extract_fields_multi_step] Warning: failed to parse JSON for batch {batch}: {e!r}, response text {response_text1}")
            
            # Fallback: ask Ollama to re-extract JSON via your llm
            try:

                prompt = (
                    "From this response extract the JSON data and return JSON data only, no extra text:\n\n"
                    f"{response_text1}"
                )

                # Correct call
                ollama_response = llm.invoke(prompt)
                # If the response is a string (likely), parse it
                new_content = ollama_response.content
                response_text = re.sub(r"^```json\s*|\s*```$", "", new_content, flags=re.IGNORECASE).strip()
                # Try parsing the cleaned-up output
                parsed, idx = decoder.raw_decode(response_text)
                if not isinstance(parsed, dict):
                    raise ValueError("Ollama didn’t return a JSON object")
            except Exception as e2:
                logging.error(f"[extract_fields_multi_step] Ollama fallback failed for batch: {e2!r}")
        # 7. Merge into final_result; later batches override earlier for same key
        final_result[out_section]['output'] = {}
        debug_details[out_section]['output'] = {}
        
        try:
            for key, val in parsed.items():
                if key == "country":
                    language = parsed['language'] if 'language' in parsed.keys() else final_result["Country / Language"]['output']["language"]
                    final_result[out_section]['output']["country_code"] = util.get_codes(country_codes,{"Language":language,'Short Name':val},'Term ID')
                if key == 'language':
                    final_result[out_section]['output']["language_code"] = util.get_codes(language_codes, {"Source Id":val},"Identifier")
                if key == 'route_of_administration':
                    final_result[out_section]['output']["route_of_administration_code"] = util.get_codes(route_of_administration_codes,{"Term Name":val.lower()},'Identifier')
                if key == 'quantity_operator':
                    final_result[out_section]['output']["quantity_operator_code"] = util.get_codes(quantity_operator_codes,{"Term Name":val.lower()},'Identifier')
                if key == 'pharmaceutical_dose_form_part':
                    final_result[out_section]['output']["pharmaceutical_dose_form_part_code"] = util.get_codes(dosage_form_codes,{"Term Name":val.lower()},'Identifier')
                if key == "unit_of_presentation":
                    final_result[out_section]['output']["unit_of_presentation_code"] = util.get_codes(unit_codes,{"Language":final_result["Country / Language"]['output']["language"],'Term Name':val},'Term ID')
                if key == 'package_item_(container)_type':
                    if isinstance(val,str):
                        final_result[out_section]['output']["package_item_(container)_type_code"] = util.get_codes(package_type_code,{"Language":final_result["Country / Language"]['output']["language"],"Term Name":val.lower()},'Term ID')
                
                final_result[out_section]['output'][key] = val
                
                if key == 'material':
                    material_with_code = []
                    for material in val:
                        code = util.get_codes(material_codes,{"Language":final_result["Country / Language"]['output']["language"],"Term Name":material.lower()},'Term ID')
                        if code:
                            material_with_code.append(f'{material} ({code})')
                        else:
                            code = util.get_codes(material_codes,{"Language":final_result["Country / Language"]['output']["language"],"Short Name":material.lower()},'Term ID')
                            material_with_code.append(f'{material} ({code})')
                    final_result[out_section]['output']["material"] = material_with_code
                debug_details[out_section]['output'][key] = val
            if out_section == "List of Excipients":
                ingredients = get_role(final_result[out_section]['output']['list_of_excipient'],"Excipient")
                final_result[out_section]['output'] = ingredients
                debug_details[out_section]['output'] = ingredients
            if out_section == "Active Ingredient":
                final_result[out_section]['output']["rs_quantity_operator_code"] = util.get_codes(quantity_operator_codes,{"Term Name":final_result[out_section]['output']["rs_quantity_operator"]},'Identifier')
                sub_code = util.get_codes(shubstance_codes,{"Language":language_dic[final_result["Country / Language"]['output']["language"]],"Substance_Name":final_result[out_section]['output']['active_ingredient'].lower()},'#SMS_ID')
                role_code = util.get_codes(ingredient_role_code,{"Language":final_result["Country / Language"]['output']["language"],"Term Name":"active"},"Term ID")
                final_result[out_section]['output'].update({"Ingredient role":"Active ("+role_code+")",
                                                            "Substance code":sub_code,
                                                            "Denominator:":"1 tablet"})
                debug_details[out_section]['output'].update({"Substance code":sub_code,
                                                             "Ingredient role":"Active ("+role_code+")",
                                                             "Denominator:":"1 tablet"})
                sub_code = util.get_codes(shubstance_codes,{"Language":language_dic[final_result["Country / Language"]['output']["language"]],"Substance_Name":final_result[out_section]['output']['rs_reference_substance'].lower()},'#SMS_ID')
                final_result[out_section]['output'].update({"rs_reference_substance_code":sub_code})
            if out_section == "Shelf Life":
                matched,unmatched = util.get_storage_code(storage_codes,parsed['special_precautions_for_storage'],language=final_result["Country / Language"]['output']["language"])
                final_result[out_section]['output']['special_precautions_for_storage'] = matched
                debug_details[out_section]['output']['special_precautions_for_storage']
            
                            
        except Exception as e:
            logger.info(e)
            logger.info(response_text)
    if "pack_size" in final_result["Packaged Medicinal Product"]["output"].keys():
        if isinstance(final_result["Packaged Medicinal Product"]["output"]['pack_size'], list):
            if len(final_result["Packaged Medicinal Product"]["output"]['pack_size'])>1:
                for i, v in enumerate(final_result["Packaged Medicinal Product"]["output"]['pack_size']):
                    print(i,v)
                    if i==0:
                        continue
                    final_result["Packaged Medicinal Product"+"_"+str(i)] = {}
                    final_result["Packaged Medicinal Product"+"_"+str(i)]["output"]= final_result["Packaged Medicinal Product"]["output"].copy()
                    final_result["Packaged Medicinal Product"+"_"+str(i)]["output"]['pack_size'] = v
                    if "Packaged Medicinal Product" in dublicate_batches.keys():
                        dublicate_batches.update({"Packaged Medicinal Product"+"_"+str(i):dublicate_batches["Packaged Medicinal Product"].copy()})
                    final_result["Package Item (Container) (2)"+"_"+str(i)] = {}
                    final_result["Package Item (Container) (2)"+"_"+str(i)]["output"]= final_result["Package Item (Container) (2)"]["output"].copy()
                    if "Package Item (Container) (2)" in dublicate_batches.keys():
                        dublicate_batches.update({"Package Item (Container) (2)"+"_"+str(i):dublicate_batches["Package Item (Container) (2)"].copy()})
                final_result["Packaged Medicinal Product"]["output"]['pack_size'] = final_result["Packaged Medicinal Product"]["output"]['pack_size'][0]
    # write it with UTF‑8
    with open("extraction_details.txt", "w", encoding="utf-8") as file:
        file.write(json.dumps(debug_details, indent=4, ensure_ascii=False))
    return final_result, dublicate_batches

def main(PDF_PATH):
    # === User parameters ===
    # PDF path configured at top (PDF_PATH)
    # Batches: list of lists of field-info dicts
    batches, dublicate_batches = util.get_batches(instructions)
    with open("duplicate_batches.txt", "w", encoding="utf-8") as file:
        file.write(json.dumps(dublicate_batches, indent=4, default=str))
    with open("batches.txt", "w", encoding="utf-8") as file:
        file.write(json.dumps(batches, indent=4, default=str))
    # 1. Build vectorstore from PDF
    logger.info("Building FAISS vectorstore from PDF...")
    # faiss_index, chunk_texts, bm25 = build_vectorstore(PDF_PATH, chunk_size=int(os.getenv("CHUNK_SIZE",1000)), chunk_overlap=int(os.getenv("CHUNK_OVERLAP", 200)))
    chuncks = chunk_pdf_by_sections_with_bold(PDF_PATH, font_size_threshold=9.6,debug=False)
    # 2. Build LLMChain with customizable system prompt
    llm_chain = build_llm_chain(llm)

    # 3. Run multi-step extraction
    logger.info("Starting multi-step extraction...")
    result, dublicate_batches = extract_fields_multi_step(
        chunk_texts=chuncks,
        batches=batches,
        llm_chain=llm_chain,
        dublicate_batches=dublicate_batches
    )
    for out_section, batch_list in dublicate_batches.items():
        if out_section not in result.keys():
            result[out_section] = {}
            result[out_section]['output'] = {}
        # batch_list is a list of dicts
        try:
            for batch in batch_list:
                # build the new key from the target section’s "name"
                new_label_key = batch['name'].replace(" ", "_").lower()
                # build the existing key from the source section’s "Existing Label"
                existing_label_key = batch['Existing Label'].replace(" ", "_").lower()
                existing_section_key = batch['Existing Section'].strip()
                
                # copy the main field
                result[out_section]['output'][new_label_key] = result[existing_section_key]['output'][existing_label_key]
                
                # if there's a code flag, copy the corresponding _code field too
                if batch.get('code') == True:
                    result[out_section]['output'][new_label_key + "_code"] = result[existing_section_key]['output'][existing_label_key + "_code"]        
        except:
            logger.info(result[out_section])
    with open("Result.txt","w", encoding="utf-8") as file:
        file.write(json.dumps(result, indent=4, ensure_ascii=False))
    return json.dumps(result, indent=2, ensure_ascii=False)
if __name__ == "__main__":
    PDF_PATH = "pdfs/Losec Capsules 20mg (SmPC) -Chapter8-Example.pdf" 
    result = main(PDF_PATH)
    print("Final extracted result:")
    print(result)
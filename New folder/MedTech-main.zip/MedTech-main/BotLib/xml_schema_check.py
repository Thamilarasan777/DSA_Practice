import xml.etree.ElementTree as ET
import re
import pandas as pd
import zipfile
import csv
import os
from datetime import datetime
def load_conformance_parameters(conformance_check_file):
    """Load conformance parameters from an Excel file."""
    ref_file = pd.ExcelFile(conformance_check_file)
    df = pd.read_excel(ref_file, sheet_name='XML Schema details', keep_default_na=False)
    conformance_params = {}

    for _, row in df.iterrows():
        section = row['XML_TAG']
        field_name = row['Field Names']
        
        # Initialize the section dictionary if not already present
        if section not in conformance_params:
            conformance_params[section] = {}
        
        # Preprocess 'Limit' column
        limit = None if row['Limit'] == 'N/A' else int(row['Limit'])
        
        # Preprocess boolean columns
        Boolean_field = row['Boolean Fields'] == 'Yes'
        Mandatory_field = row['Mandatory Fields'] == 'Yes'
        
        # Preprocess 'Case' and 'Numeric' columns to form regex pattern
        alpha = ''
        if row['Case'] == 'Always Caps':
            alpha = 'A-Z'
        elif row['Case'] == 'Small':
            alpha = 'a-z'
        elif row['Case'] == 'Caps and Small':
            alpha = 'A-Za-z'

        if row['Numeric'] == 'Numeric':
            alpha += '0-9'

        # Preprocess 'spl_character' column
        if row['spl_characters'] == 'Any':
            spl_char = r'!"#$%&\'()*+,./:;<=>?@[\\\]^_`{|}~ \-'  # All printable special characters
        else:
            spl_char = re.escape(row['spl_characters']) if row['spl_characters'] else ''
        
        # Combine regex pattern
        regex_pattern = f"^[{alpha}{spl_char}]*$" if alpha or spl_char else None

        # Populate the dictionary with processed parameters
        conformance_params[section][field_name] = {
            'limit': limit,
            'dtype': row['Type'],
            'tag': row['XML_TAG'],
            'regex': regex_pattern,
            'Boolean_field': Boolean_field,
            'Mandatory_field': Mandatory_field
        }
    
    return conformance_params

def check_conformance(tag, value, limit, dtype, regex=None,Boolean_field=False,blank=False):
    """Check if the value conforms to given parameters and return results."""
    report = {'Failed': [], 'Pass': []}
    
    # Check if value is within length limit
    if value == "":
        if blank:
            pass
        else:
            report['Failed'].append(f"Failed: Value should not be Blank for {tag}")
    else:
        if limit is not None and len(value) > limit:
            report['Failed'].append(f"Failed: Exceeds length limit of {limit} characters (length is {len(value)})")
        else:
            report['Pass'].append("Pass: Length is within the limit")
            
        # Check data type
        type_checks = {
            "int": isinstance(value, int),
            "float": isinstance(value, float),
            "str": isinstance(value, str)
        }
        if not type_checks.get(dtype, True):
            report['Failed'].append(f"Failed: Value is not of type {dtype}")
        else:
            report['Pass'].append(f"Pass: Value is of type {dtype}")
        
        # Check regex pattern
        if regex:
            if re.match(regex, value):
                report['Pass'].append(f"Pass: Value matches the regex pattern {regex}")
            else:
                # print("hi hello ",tag, value,regex)
                report['Failed'].append(f"Failed: Value does not match the regex pattern {regex}")
        
    return (False, report['Failed']) if report['Failed'] else (True, report['Pass'])

def validate_xml_file(xml_content, filename, conformance_params,level):
    """Validate all tags in an XML file against conformance parameters."""
    errors = []

    try:
        root = ET.fromstring(xml_content)
        def validate_node(node, section_name):
            """Validate a single XML node's tags and values."""
            for child in node:
                tag = child.tag
                value = child.text if child.text is not None else ""
                section_params = conformance_params.get(section_name, {})
                params = section_params.get(tag, {})
                # Check if 'Boolean_field' is True
                if params.get('Boolean_field') is True:
                    # Replace 'T' with 'true' and 'F' with 'false'
                    if value == 'T':
                        child.text = 'true'
                    elif value == 'F':
                        child.text = 'false'
                    elif tag == 'C_DEFAULT_STORAGE_TIME' or tag == 'C_DEFAULT_STORAGE_TOLERANCE':
                        child.text = 'P0DT0H0M0S'
                    else:
                        errors.append((section_name, tag, value, 'The Boolean_field do not match the pattern.'))
                    continue  # Skip further validation for this tag
                # Check if 'Boolean_field' is True
                elif params.get('Mandatory_field') is True:
                    # Replace 'T' with 'true' and 'F' with 'false'
                    if value != '' and value is not None:
                        if tag == params.get('XML_TAG'):
                            # Validate using check_conformance
                            valid, error = check_conformance(
                                tag=tag,
                                value=value,
                                limit=params.get('limit'),
                                dtype=params.get('dtype'),
                                regex=params.get('regex')
                            )
                else:
                    # Check if 'Boolean_field' is True
                    if params.get('dtype') == 'DateTime':
                        if value == "":
                            pass
                        elif re.match(r'^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$', value):
                            child.text = value.replace(" ", 'T')
                        elif re.match(r'^\d{2}-\d{2}-\d{4} \d{2}:\d{2}$', value):
                            child.text = value.replace(" ", 'T')
                        elif re.match(r'^\d{2}-\d{2}-\d{4} \d{2}:\d{2}:\d{2}$$', value):
                            child.text = value.replace(" ", 'T')
                        else:
                            errors.append((section_name, tag, value, 'The date and time do not match the pattern.'))
                        continue  # Skip further validation for this tag
                    # Validate using check_conformance
                    valid, error = check_conformance(
                        tag=tag,
                        value=value,
                        limit=params.get('limit'),
                        dtype=params.get('dtype'),
                        regex=params.get('regex'),
                        blank=True
                    )
                     
                if not valid:
                    errors.append((section_name, tag, value, error))
                
                # Recursively validate child nodes
                validate_node(child, section_name)

        # Start validation from the root node
        for section in root:
            validate_node(section, section.tag)

        # Save the modified XML to a string
        updated_xml_content = ET.tostring(root, encoding='unicode')

    except ET.ParseError as e:
        errors.append(("XML_PARSE_ERROR", "STRUCTURE", "Invalid XML", str(e)))
    except Exception as e:
        errors.append(("UNEXPECTED_ERROR", "STRUCTURE", "Error processing file", str(e)))

    return errors, updated_xml_content


def process_xml_files(input_zip_path, output_dir, conformance_check_file, level):
    """
    Process XML files from input ZIP and create output files in specified directory.
    
    Args:
        input_zip_path (str): Path to input ZIP file containing XML files.
        output_dir (str): Directory where output files will be saved.
        conformance_check_file (str): Path to the Excel file containing conformance parameters.
        level (str): Level of processing (e.g., ItemCode or Product).
    """
    # Load conformance parameters from Excel
    conformance_params = load_conformance_parameters(conformance_check_file)
    os.makedirs(output_dir, exist_ok=True)
    
    valid_files = []
    invalid_files = []
    all_errors = []
    
    # Extract and process files from the input ZIP
    with zipfile.ZipFile(input_zip_path, 'r') as zip_ref:
        for filename in zip_ref.namelist():
            if filename.endswith('.xml'):
                with zip_ref.open(filename) as xml_file:
                    xml_content = xml_file.read().decode('utf-8')
                    errors, updated_xml_content = validate_xml_file(xml_content, filename, conformance_params, level)
                    if updated_xml_content:
                        xml_content = updated_xml_content
                    if errors:
                        invalid_files.append((filename, xml_content))
                        all_errors.extend([(filename, *error) for error in errors])
                    else:
                        valid_files.append((filename, xml_content))
    
    file_names = {}

    # Function to ensure XML declaration is included
    def ensure_xml_declaration(content):
        from xml.dom.minidom import parseString
        dom = parseString(content)
        return dom.toxml(encoding="utf-8").decode("utf-8")
    
    # Save valid files ZIP
    if valid_files:
        valid_zip_path = os.path.join(output_dir, 'valid_files.zip')
        with zipfile.ZipFile(valid_zip_path, 'w', zipfile.ZIP_DEFLATED) as valid_zip:
            for filename, content in valid_files:
                # Ensure XML declaration and encode as UTF-8
                utf8_content = ensure_xml_declaration(content).encode('utf-8')
                valid_zip.writestr(filename, utf8_content)
        file_names['valid_files'] = valid_zip_path

    # Save invalid files ZIP
    if invalid_files:
        invalid_zip_path = os.path.join(output_dir, 'invalid_files.zip')
        with zipfile.ZipFile(invalid_zip_path, 'w', zipfile.ZIP_DEFLATED) as invalid_zip:
            for filename, content in invalid_files:
                # Ensure XML declaration and encode as UTF-8
                utf8_content = ensure_xml_declaration(content).encode('utf-8')
                invalid_zip.writestr(filename, utf8_content)
        file_names['invalid_files'] = invalid_zip_path

        # Create a CSV report for errors
        error_csv_path = os.path.join(output_dir, 'error_report.csv')
        file_names['errors'] = error_csv_path
        error_df = pd.DataFrame(
            all_errors, 
            columns=['Filename', 'Section', 'Tag', 'Value', 'Error Message']
        )
        error_df = error_df.map(lambda x: f'="{x}"' if isinstance(x, (int, float, str)) else x)
        error_df.to_csv(error_csv_path, index=False, encoding='utf-8')
    
    return file_names

if __name__ == "__main__":
    level = "ItemCode"
    if level == 'ItemCode':
        xml_template_path = "..\\reference files\\XML_Template_ItemCode.xml"
        conformance_check_file = "..\\reference files\\ItemCode XML Schema.xlsx"
    else:
        xml_template_path = "..\\reference files\\Product XML Template.xml"
        conformance_check_file = "..\\reference files\\Product - XML Schema.xlsx"
    zip_file_path = "..\\uploads\\output_xml_files.zip"
    # input_zip_path = "xmlcheck.zip"  # Replace with your input ZIP path
    output_dir = "output_xml_files"     # Replace with your desired output directory
    # xsd_file_path = 'reference files/Itemcode_Schema.xsd'
    # try:
    filefnames = process_xml_files(zip_file_path, "uploads",conformance_check_file,level)
    # except Exception as e:
    #     print(f"Error processing files: {str(e)}")

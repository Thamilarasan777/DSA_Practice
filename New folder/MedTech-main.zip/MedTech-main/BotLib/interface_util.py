import os
import pandas as pd
import xml.etree.ElementTree as ET
import zipfile
from openpyxl.styles import PatternFill
def create_zip_file(file_paths, zip_filename='PRODDUCT_Highlighted_files.zip',remove_files=True):
    zip_path = os.path.join('uploads', zip_filename)
    with zipfile.ZipFile(zip_path, 'w') as zipf:
        for file_path in file_paths:
            zipf.write(file_path, os.path.basename(file_path))
            if remove_files:
                os.remove(file_path)  # Clean up individual files after zipping
    return zip_path
def save_xml_files_as_zip(name_classes, zip_filename="output_xmls.zip"):
    """Save all XML files for each instance into a zip file."""
    with zipfile.ZipFile(zip_filename, 'w', zipfile.ZIP_DEFLATED) as zf:
        for name, name_class in name_classes.items():
            # Generate the XML string using the `to_xml_string` method
            xml_string = name_class.to_xml_string()
            
            # Ensure the XML declaration is included in `to_xml_string`
            if not xml_string.startswith('<?xml'):
                raise ValueError(f"The XML string for {name} is missing the XML declaration.")
            
            # Create a filename for the XML file inside the ZIP
            xml_filename = f"{name}.xml"
            
            # Write the XML string into the ZIP archive as a file
            zf.writestr(xml_filename, xml_string)

    return zip_filename
def df_to_dict_with_colors(df):
    # Convert the DataFrame into a list of lists of dictionaries containing both value and color
    result = []
    # Assuming color data is stored separately or generated, for now, let's create placeholder colors
    for _, row in df.iterrows():
        row_data = []
        for col in df.columns:
            cell_value = row[col]
            cell_color = 'FFFFFF'  # Example color, in real scenarios, this would come from actual data
            row_data.append({'value': cell_value, 'color': f'0x{cell_color}'})
        result.append(row_data)
    # Add headers as the first row (dictionary structure: 'value': header_name, 'color': None or 'FFFFFF')
    headers = [{'value': col, 'color': None} for col in df.columns]
    result.insert(0, headers)  # Insert the headers at the top
    
    return result


def _save_styled_dataframe(df, style_df, writer, sheet_name):
    """
    Internal helper function to save a styled DataFrame to an Excel file with cell background colors.

    Parameters:
    - df (pd.DataFrame): The filtered DataFrame to save.
    - style_df (pd.DataFrame): The style DataFrame containing cell background colors.
    - writer (pd.ExcelWriter): The Excel writer object to save to.
    - sheet_name (str): Name of the Excel sheet to write to.
    """
    # Replace NaN values with empty strings in the DataFrame
    df = df.fillna("")

    # Define columns to be removed
    to_remove = ['Status', 'Approve', 'JsonData']

    # Filter out the columns from both DataFrame and style DataFrame
    df = df[[col for col in df.columns if col not in to_remove]]
    style_df = style_df[[col for col in style_df.columns if col not in to_remove]]

    # Save the filtered DataFrame to Excel
    df.to_excel(writer, sheet_name=sheet_name, index=False)
    workbook = writer.book
    worksheet = writer.sheets[sheet_name]

    # Dictionary for mapping common colors to hex codes
    color_dic = {"red": '#FF0000', "purple": "#800080", 'pink': '#FFC0CB', 'blue': "#00B0F0"}

    # Apply background colors from style_df to each cell
    for row in range(len(df)):
        for col, col_name in enumerate(df.columns):
            # Get the background color from style_df if available
            bg_color = style_df.iloc[row, col]
            if bg_color and isinstance(bg_color, str) and "background-color: " in bg_color:
                # Extract hex color code from style string
                color_code = bg_color.split("background-color: ")[-1].strip()
                if color_code in color_dic:
                    color_code = color_dic[color_code]
                # Ensure the color code is a valid aRGB hex value
                if color_code.startswith("#"):
                    color_code = color_code[1:]  # Remove the '#' for openpyxl
                try:
                    worksheet.cell(row=row + 2, column=col + 1).fill = PatternFill(
                        start_color=color_code,
                        end_color=color_code,
                        fill_type="solid"
                    )
                except ValueError as e:
                    print(f"Error applying color {color_code} to cell ({row + 2}, {col + 1}): {e}")

def filter_items(item_codes, stylers_dict, output_file="filtered_itemcodes.xlsx"):
    """
    Filters rows in multiple DataFrameStyler instances based on a list of item codes 
    and saves the filtered data with background colors to an Excel file.

    Parameters:
    - item_codes (list): List of item codes to filter.
    - stylers_dict (dict): Dictionary where keys are sheet names and values are tuples 
      (styler, foreign_key_column), where:
        - styler (DataFrameStyler): An instance of DataFrameStyler.
        - foreign_key_column (str): The column name to filter on.
    - output_file (str): Name of the output Excel file (default is "filtered_itemcodes.xlsx").
    """
    output_file = os.path.join('uploads', output_file)    
    with pd.ExcelWriter(output_file, engine='openpyxl') as writer:
        for sheet_name, (styler, foreign_key_column) in stylers_dict.items():
            # print("sheet name - ",sheet_name)
            # Filter rows based on the item codes and specified foreign key column
            filtered_df = styler.dataframe[styler.dataframe[foreign_key_column].isin(item_codes)].copy()
            # Create filtered style DataFrame for background colors
            filtered_style = styler.style_df.loc[filtered_df.index]
            # Save the styled DataFrame to the Excel writer
            _save_styled_dataframe(filtered_df, filtered_style, writer, sheet_name=sheet_name)

    print(f"Filtered Rerun items saved to {output_file}")
    return output_file

def load_xml_template(file_path):
    """
    Reads an XML file and loads it as an ElementTree.

    :param file_path: Path to the XML file containing the schema.
    :return: ElementTree object representing the loaded XML.
    """
    try:
        # Parse the XML file
        xml_tree = ET.parse(file_path)
        return xml_tree
    except FileNotFoundError:
        print(f"Error: The file '{file_path}' does not exist.")
        return None
    except ET.ParseError as e:
        print(f"Error parsing the XML file: {e}")
        return None
from openpyxl.utils import get_column_letter

def sheet_to_html(sheet):
    blocked_color = False
    table_html = '<table class="data-table">'
    
    # Adding the header row
    table_html += '<thead><tr><th>Si. No.</th>'
    
    for col in range(1, sheet.max_column + 1):
        col_letter = get_column_letter(col)
        if sheet.column_dimensions[col_letter].hidden:
            continue

        cell = sheet.cell(row=1, column=col)
        cell_value = cell.value or ''
        table_html += f'<th>{cell_value}</th>'
    
    # Adding the body rows
    table_html += '<tbody>'

    for row in range(2, sheet.max_row + 1):
        table_html += f'<tr><td>{row - 1}</td>'
        
        for col in range(1, sheet.max_column + 1):
            col_letter = get_column_letter(col)
            if sheet.column_dimensions[col_letter].hidden:
                continue

            cell = sheet.cell(row=row, column=col)
            cell_value = cell.value or ''
            cell_fill = cell.fill.fgColor

            # Ensure the fill color is an RGB string, and not an object
            if hasattr(cell_fill, 'rgb') and isinstance(cell_fill.rgb, str):
                # Exclude default empty fills and apply the background color
                if cell_fill.rgb != '00000000':  # Ignore transparent/no fill
                    if cell_fill.rgb[2:] not in ['92D050','00B0F0']:
                        # print(cell_fill.rgb[2:])
                        blocked_color = True
                    table_html += f'<td style="background-color: #{cell_fill.rgb[2:]};">{cell_value}</td>'
                else:
                    table_html += f'<td>{cell_value}</td>'
            else:
                table_html += f'<td>{cell_value}</td>'

    table_html += '</tbody></table>'
    
    return table_html, blocked_color
# def read_(file):
#     """Read the first sheet of an Excel file and return its data as a DataFrame with string data types."""
#     file_sheets = pd.read_excel(file, sheet_name=None, keep_default_na=False)
#     data = file_sheets[list(file_sheets.keys())[0]]
#     return data.astype(str)

# def save_to_excel_file(styler, filename,sheet_name):
#     file_path = os.path.join('uploads', filename)
#     with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
#         styler.save_to_excel(writer, sheet_name=sheet_name)
#     return file_path
# @app.route('/upload-task1', methods=['POST'])
# def upload_task1():
#     if 'taskFile' not in request.files:
#         return jsonify({'error': 'No file uploaded'}), 400
    
#     file = request.files['taskFile']
#     if file.filename == '':
#         return jsonify({'error': 'No selected file'}), 400

#     # Save the uploaded file
#     excel_path = os.path.join('uploads', file.filename)
#     file.save(excel_path)

#     # Prepare response data (you can also return sheet names, etc., if needed)
#     return jsonify({'filename': file.filename})
# def get_sheet_data_with_colors(workbook, sheet_name):
#     # Access the sheet
#     sheet = workbook[sheet_name]
#     data = []
    
#     for row in sheet.iter_rows():
#         row_data = []
        
#         for cell in row:
#             # Check if the cell has a fill and a foreground color
#             if cell.fill and cell.fill.fgColor and cell.fill.fgColor.rgb is not None:
#                 cell_color = cell.fill.fgColor.rgb
#             else:
#                 cell_color = None  # No color if not defined
#             # Store the cell value and color (if present)
#             cell_data = {
#                 'value': cell.value,
#                 'color': cell_color
#             }
#             row_data.append(cell_data)
#         data.append(row_data)
#     return data
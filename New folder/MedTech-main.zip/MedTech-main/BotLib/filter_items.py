import pandas as pd
from openpyxl import load_workbook, Workbook
from openpyxl.styles import PatternFill, Font, Border, Alignment
from copy import copy


class StyledExcelFile1:
    def __init__(self, filename):
        self.filename = filename
        self.data = self._read_excel_with_styles()

    def _read_excel_with_styles(self):
        workbook = load_workbook(self.filename)
        data = {}

        for sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            sheet_data = [
                [{
                    "value": cell.value if cell.value is not None else "",
                    "fill": copy(cell.fill) if cell.fill else PatternFill(fill_type=None),
                    "font": copy(cell.font),
                    "border": copy(cell.border),
                    "alignment": copy(cell.alignment),
                    "color": cell.fill.fgColor.rgb if cell.fill and cell.fill.fgColor and cell.fill.fgColor.rgb else None
                } for cell in row]
                for row in sheet.iter_rows()
            ]
            data[sheet_name] = sheet_data
        return data

    def filter_items(self, filter_values, output_filename):
        """
        Filters rows in all sheets based on the provided list of values.
        Saves the filtered rows into a new Excel file while preserving cell styles.

        :param filter_values: List of values to filter rows by.
        :param output_filename: Name of the output Excel file.
        """
        # Create a new workbook to save the filtered data
        new_workbook = Workbook()
        new_workbook.remove(new_workbook.active)  # Remove the default sheet

        for sheet_name, sheet_data in self.data.items():
            print("Processing sheet - ", sheet_name)
            # Create a new sheet in the new workbook
            new_sheet = new_workbook.create_sheet(title=sheet_name)

            # Get the header row
            header_row = sheet_data[0]  # Assume the first row contains headers
            header_values = [str(cell["value"]).strip().upper() for cell in header_row]

            # Determine the foreign key column
            if "NAME" in header_values:
                foreign_key_column = "NAME"
            elif "PRODUCT" in header_values:
                foreign_key_column = "PRODUCT"
            else:
                foreign_key_column = "PRODUCT_SPEC"

            try:
                name_col_index = next(
                    idx for idx, cell in enumerate(header_row)
                    if str(cell["value"]).strip().upper() == foreign_key_column
                )
            except StopIteration:
                print(f"Foreign key column not found in sheet '{sheet_name}'. Skipping this sheet.")
                continue

            # Filter rows where the foreign key column value is in the filter_values list
            filtered_rows = [
                row for row in sheet_data
                if str(row[name_col_index]["value"]).strip() in filter_values
            ]

            # Add the header row to the filtered rows
            filtered_rows.insert(0, header_row)

            # Write the filtered rows to the new sheet while preserving styles
            for row_idx, row in enumerate(filtered_rows, start=1):
                for col_idx, cell in enumerate(row, start=1):
                    new_cell = new_sheet.cell(row=row_idx, column=col_idx, value=cell["value"])
                    new_cell.fill = cell["fill"]
                    new_cell.font = cell["font"]
                    new_cell.border = cell["border"]
                    new_cell.alignment = cell["alignment"]

        # Save the new workbook
        new_workbook.save(output_filename)
        print(f"Filtered data saved to {output_filename}")



# Example usage
if __name__ == "__main__":
    
    path_a = "../uploads/Thamil/PRODUCT_12-02-2025_copied.xlsx"
    file_a = pd.ExcelFile(path_a)
    item_file = pd.read_excel(file_a, sheet_name="v7 DEV - Product Summary", keep_default_na=False)
    values = item_file["NAME"].tolist()
    print(len(values))
    source_file = "../uploads/Thamil/ETD_F_PRODUCT_Highlighted_V7_DEV.xlsx"
    excel_file = StyledExcelFile1(source_file)
    excel_file.filter_items(
        filter_values=values,  # Values to filter by in the 'NAME' column
        output_filename="filtered_example.xlsx",
        foreign_key_column="NAME"  # Column name to filter by
    )
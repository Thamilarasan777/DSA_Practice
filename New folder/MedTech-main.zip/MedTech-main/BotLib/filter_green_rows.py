import pandas as pd
import openpyxl
from copy import copy
import os

class RowData:
    def __init__(self, index, foreign_key, comments):
        self.index = index  # Row index in the DataFrame
        self.foreign_key = foreign_key  # Foreign key value
        self.comments = comments  # Comments column value

def load_sheet_data(sheet, foreign_key_column):
    # Load the data from sheet into a list of RowData objects
    return [RowData(idx, row[foreign_key_column], row['COMMENTS']) for idx, row in sheet.iterrows()]

def process_rows(sheet_data_dict, ignore_sheet=None):
    # Create foreign key mappings for each sheet
    key_mappings = {sheet_name: {} for sheet_name in sheet_data_dict.keys()}
    
    # Populate key_mappings with lists of rows for each foreign key
    for sheet_name, data in sheet_data_dict.items():
        for row in data:
            if row.foreign_key not in key_mappings[sheet_name]:
                key_mappings[sheet_name][row.foreign_key] = []
            key_mappings[sheet_name][row.foreign_key].append(row)

    ignored_rows = {sheet_name: [] for sheet_name in sheet_data_dict.keys()}
    remaining_rows = {sheet_name: [] for sheet_name in sheet_data_dict.keys()}

    # Process rows in the first sheet and compare with others
    first_sheet_name = next(iter(sheet_data_dict))
    for row1 in sheet_data_dict[first_sheet_name]:
        is_ignored = True
        for sheet_name, key_map in key_mappings.items():
            if sheet_name == first_sheet_name:
                continue

            matched_rows = key_map.get(row1.foreign_key, [])  # Get matched rows in other sheets
            if matched_rows:
                for matched_row in matched_rows:
                    if ignore_sheet is not None:
                        if first_sheet_name not in ignore_sheet:
                            if matched_row.comments != "Verified - OK" or row1.comments != "Verified - OK":
                                is_ignored = False
                                break
                    elif matched_row.comments != "Verified - OK" or row1.comments != "Verified - OK":
                        is_ignored = False
                        break
            elif row1.comments != "Verified - OK":
                is_ignored = False
                break

        if is_ignored:
            for sheet_name, key_map in key_mappings.items():
                if sheet_name == first_sheet_name:
                    ignored_rows[sheet_name].append(row1)
                elif row1.foreign_key in key_map:
                    ignored_rows[sheet_name].extend(key_map[row1.foreign_key])
        else:
            for sheet_name, key_map in key_mappings.items():
                if sheet_name == first_sheet_name:
                    remaining_rows[sheet_name].append(row1)
                elif row1.foreign_key in key_map:
                    remaining_rows[sheet_name].extend(key_map[row1.foreign_key])

    return ignored_rows, remaining_rows

def copy_rows_to_new_workbook(wb, original_sheet, new_sheet, rows):
    # Copy header row once to new sheet
    header_row = [cell for cell in original_sheet[1]]
    for cell in header_row:
        new_cell = new_sheet.cell(row=1, column=cell.column, value=cell.value)
        if cell.has_style:
            new_cell.font = copy(cell.font)
            new_cell.border = copy(cell.border)
            new_cell.fill = copy(cell.fill)
            new_cell.number_format = copy(cell.number_format)
            new_cell.protection = copy(cell.protection)
            new_cell.alignment = copy(cell.alignment)

    # Copy data rows
    for row_data in rows:
        new_row_index = new_sheet.max_row + 1
        for col_idx, cell in enumerate(original_sheet[row_data.index + 2], start=1):  # Adjust for header offset
            new_cell = new_sheet.cell(row=new_row_index, column=col_idx, value=cell.value)
            if cell.has_style:
                new_cell.font = copy(cell.font)
                new_cell.border = copy(cell.border)
                new_cell.fill = copy(cell.fill)
                new_cell.number_format = copy(cell.number_format)
                new_cell.protection = copy(cell.protection)
                new_cell.alignment = copy(cell.alignment)

def process_excel(file_path, level):
    # Load the workbook
    wb = openpyxl.load_workbook(file_path)
    xl = pd.ExcelFile(file_path)

    # Parse each sheet dynamically
    sheet_data_dict = {}
    for sheet_name in xl.sheet_names:
        sheet_df = xl.parse(sheet_name=sheet_name)
        if level == 'ItemCode':
            foreign_key_column = 'NAME' if 'NAME' in sheet_df.columns else 'T_PH_ITEM_CODE'
            ignore_sheet = None
        else:
            foreign_key_column = 'NAME' if 'NAME' in sheet_df.columns else 'PRODUCT'
            ignore_sheet = ["v7 DEV - Product Grade", "v7 DEV - ETD_F Product Compds", "v7 DEV - ETD_N Product Compds", "v7 DEV - ETD_S Product Compds"]
        sheet_data_dict[sheet_name] = load_sheet_data(sheet_df, foreign_key_column)

    # Process the rows and categorize them into ignored and remaining rows
    ignored_rows, remaining_rows = process_rows(sheet_data_dict, ignore_sheet)

    # Initialize new workbooks for ignored and remaining rows
    wb_ignored = openpyxl.Workbook()
    wb_remaining = openpyxl.Workbook()
    wb_ignored.remove(wb_ignored.active)
    wb_remaining.remove(wb_remaining.active)

    ignored_row_counts = {}
    remaining_row_counts = {}

    # Process each sheet and copy rows based on the categories
    for sheet_name in xl.sheet_names:
        original_sheet = wb[sheet_name]
        new_sheet_ignored = wb_ignored.create_sheet(sheet_name)
        new_sheet_remaining = wb_remaining.create_sheet(sheet_name)

        copy_rows_to_new_workbook(wb, original_sheet, new_sheet_ignored, ignored_rows[sheet_name])
        copy_rows_to_new_workbook(wb, original_sheet, new_sheet_remaining, remaining_rows[sheet_name])

        ignored_row_counts[sheet_name] = len(ignored_rows[sheet_name])
        remaining_row_counts[sheet_name] = len(remaining_rows[sheet_name])

    # Save the files after processing
    ignored_file_path = os.path.join('uploads', level + '_Passed_entries.xlsx')
    remaining_file_path = os.path.join('uploads', level + '_Failed_entries.xlsx')
    wb_ignored.save(ignored_file_path)
    wb_remaining.save(remaining_file_path)

    return ignored_file_path, remaining_file_path, ignored_row_counts, remaining_row_counts
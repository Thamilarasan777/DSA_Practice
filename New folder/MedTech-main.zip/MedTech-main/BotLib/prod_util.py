import re
import pandas as pd
def blank_check(v6, v7):
    if v6 == 'nil' and v7 == "":
        return True
    if v6 != 'nil' and v7 == "":
        return False
    if v6 == 'nil' and v7 != "":
        return False
def check_decimal_discrepancy(min_val, max_val):
    # Convert values to strings
    min_str = str(min_val).replace(",",'.')
    max_str = str(max_val).replace(",",'.')
    
    # Find the decimal part (if any) after the dot
    min_decimals = len(min_str.split('.')[1]) if '.' in min_str else 0
    max_decimals = len(max_str.split('.')[1]) if '.' in max_str else 0
    
    # Return True if there's a discrepancy, otherwise False
    return min_decimals == max_decimals
def get_decimal_places(number_str1: str, number_str2: str = None):
    # Count decimal places in the first number
    places1 = str(len(number_str1.split('.')[1]) if '.' in number_str1 else 0)

    if number_str2 is not None:
        # Count decimal places in the second number
        places2 = str(len(number_str2.split('.')[1]) if '.' in number_str2 else 0)
        
        # Return a tuple: (status, decimal places of the first number)
        return (places1 == places2, places1)

    # Return only the decimal places of the first number if the second is not provided
    return places1
def find_prod_for_required(prod_spec):
    # Define the possible values and their corresponding regex patterns
    value_patterns = {
        "ETD_N": r'^(ETD_N_).*',
        "ETD_S": r'^(ETD_S_).*', 
    }
    # Iterate through the value patterns and check if prod_spec matches any of them
    for value, pattern in value_patterns.items():
        if re.match(pattern, prod_spec):
            return True,value
    # If no match is found, return None or a default value
    return False,""
def get_v6_analysis_from_Tracker(MD, v7_analysis):
    if v7_analysis in MD['v7 Analysis'].values:
        v6_analysis_values = MD.loc[MD['v7 Analysis'] == v7_analysis, 'v6 Analysis'].dropna().unique()
        if len(v6_analysis_values) > 0:
            return list(v6_analysis_values)  # Return unique values as a list
        else:
            return False  # No valid v6 Analysis found
    else:
        return False  # v7_analysis not found in MD
def get_v7_analysis_from_Tracker(MD,v6_analysis):
    if v6_analysis in MD['v6 Analysis'].values:
        if not pd.isna(MD.loc[MD['v6 Analysis'] == v6_analysis, 'v7 Analysis'].values[0]) and MD.loc[MD['v6 Analysis'] == v6_analysis, 'v7 Analysis'].values[0] != '':
            v7_analysis = MD.loc[MD['v6 Analysis'] == v6_analysis, 'v7 Analysis'].dropna().unique()
            if len(v7_analysis) > 0:
                return list(v7_analysis)  # Return unique values as a list
            else:
                return False  # No valid v6 Analysis found
        else:
            return False
    else:
        return False
def get_v6_component(MD, v7_comp, v7_analysis=""):
    # Filter based on both 'v7 Components' and 'v7 Analysis'
    filtered_MD = MD[(MD['v7 Components'] == v7_comp) & (MD['v7 Analysis'] == v7_analysis)]
    
    if not filtered_MD.empty:
        v6_comp_value = filtered_MD['v6 Components'].values[0]
        if not pd.isna(v6_comp_value) and v6_comp_value != '':
            return v6_comp_value
        else:
            return False
    else:
        return False
def get_v7_component(MD,v6_comp):
    if v6_comp in MD['v6 Components'].values:
        if not pd.isna(MD.loc[MD['v6 Components'] == v6_comp, 'v7 Components'].values[0]) and MD.loc[MD['v6 Components'] == v6_comp, 'v7 Components'].values[0] != '':
            v7_comp = MD.loc[MD['v6 Components'] == v6_comp, 'v7 Components'].values[0]
            return v7_comp
        else:
            return False
    else:
        return False
def get_v7_units(MD, v6_unit):
  
    # Filter the DataFrame for the given v7_unit
    filtered_rows = MD.loc[MD['v6 - UNIT CODE'] == v6_unit, 'v7 - UNIT CODE']
    
    # Filter out invalid values (NaN and empty strings) and convert to a list
    valid_values = [val for val in filtered_rows if pd.notna(val) and val != '']
    
    return valid_values
def handle_combinations(v6_control, range_, v7_control,column,range_column):
    # Treat all values as strings, normalize 'nil' and 'Blank' to None for easier comparison
    v6_value = None if v6_control == 'nil' else v6_control
    range_value = None if range_ == 'nil' else range_
    v7_value = None if v7_control == '' else v7_control

    # Green Condition: when v7_value matches either v6_value or range_value and they are equal
    # Blue for SME Verification Condition: based on specific difference checks
    if (v6_value != range_value and range_value != None and v6_value != None):
        v7_value = "Blank" if v7_control == "" else v7_value
        return "blue", f'The {column} is "{v7_control}" in v7 DEV. The {range_column} is "{range_}" and {column} is "{v6_control}" in v6 PROD. Hence, it requires SME verification.'
        
    if (v6_value == v7_value and range_value is None) or \
       (range_value == v7_value and v6_value is None) or \
       (v6_value == range_value == v7_value) or \
       (v6_value is None and range_value is None and v7_value is None):
        return "#92D050",''   #returning light green

    # Red Condition: if v7_value doesn't match either v6_value or range_value
    
    if (v6_value == v7_value and range_value != v7_value) or \
       (v6_value != v7_value and range_value == v7_value) or \
       (v6_value != v7_value and range_value != v7_value):
        v7_value = "Blank" if v7_control == "" else v7_value
        final_val = range_ if v6_control == 'nil' else v6_control
        return "red",f'The {column} is "{v7_value}" in v7 DEV. The {range_column} is "{range_}" and {column} is "{v6_control}" in v6 PROD. It should be "{final_val}" in v7 DEV as per the v6 PROD.'
    
    # If no conditions match, return None
    return None
def get_product_Tracker_row(MD, val,grade=""):
    # Filter rows based on the 'v7 Product entry code'
    if grade == "":
        filtered_rows = MD.loc[MD['v7 Product entry code'] == str(val)]
    else:
        filtered_rows = MD.loc[(MD['v7 Product entry code'] == str(val)) & (MD['v7 Grades'] == str(grade))]
    # if val == 'ETD_S_NVC_PROCESS_AV':
    #     print(val,len(filtered_rows))
    # Check if the filtered result is not empty
    if len(filtered_rows) > 0:
        MD_Trak_v6_code = filtered_rows.loc[filtered_rows['v7 Product entry code'] == str(val), 'v6 Product entry code'].values[0]
        if not pd.isna(MD_Trak_v6_code):
            # if val == 'ETD_S_NVC_PROCESS_AV':
            #     print(MD_Trak_v6_code, filtered_rows)
            MD_Trak_v6_grade = filtered_rows.loc[filtered_rows['v7 Product entry code'] == str(val), 'v6 Grades'].values[0]
            MD_Trak_v7_grade = filtered_rows.loc[filtered_rows['v7 Product entry code'] == str(val), 'v7 Grades'].values[0]
            return True, {"filtered_rows":filtered_rows,"v6_code": MD_Trak_v6_code, "v6_grade": MD_Trak_v6_grade,'v7_grade':MD_Trak_v7_grade}
        else:
            return False, ""
    else:
        return False, ""
import pandas as pd

def get_v6_row(v6, name, grade, analysis=None, component=None, product='PRODUCT'):
    # Convert inputs to strings for consistency
    name = str(name)
    grade = str(grade)
    
    # Start filtering conditions
    conditions = (v6[product] == name) & (v6['GRADE'] == grade)
    
    # Handle analysis (single value or list)
    if analysis is not None:
        if isinstance(analysis, list):
            analysis = list(map(str, analysis))  # Convert list elements to strings
            conditions &= v6['ANALYSIS'].isin(analysis)  # Use .isin() for list
        else:
            conditions &= v6['ANALYSIS'] == str(analysis)  # Convert to string for comparison
    
    # Handle component
    if component is not None:
        conditions &= v6['COMPONENT'] == str(component)
    
    # Filter DataFrame
    matched_rows = v6[conditions]
    
    return matched_rows

def check_prodname_in_v6(MD,v6,value,grade=False,Grade=""):
    status, v6_val = get_product_Tracker_row(MD,value,grade=Grade)
    if status:
        MD_Trak_v6_code = v6_val['v6_code']
        if grade:
            v6_entry = get_v6_row(v6,MD_Trak_v6_code,v6_val['v6_grade'])
            if not v6_entry.empty:
                return True,v6_entry,"#92D050" # Light Green
            else:
                return False,'The PRODUCT Name "{}" is not present in v6 PROD.'.format(value),"#FFFF00"  #Standard Yellow color
        else:
            v6_names = list(v6['NAME'].astype(str))
            if MD_Trak_v6_code in v6_names:
                return True,v6[v6['NAME'] == MD_Trak_v6_code],"#92D050" # Light Green
            else:
                return False,'The PRODUCT Name "{}" is not available in v6 PROD.'.format(value),"#FFFF00"  #Standard Yellow color
    else:
        return False,'The PRODUCT Name "{}" is not available in Product MD Tracker.'.format(value),"#7030A0" #Standard Purple color

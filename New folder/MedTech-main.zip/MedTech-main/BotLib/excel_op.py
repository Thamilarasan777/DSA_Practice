import pandas as pd
from openpyxl.utils import get_column_letter
from openpyxl.styles import PatternFill
import re
from io import BytesIO
from openpyxl import load_workbook, Workbook
from copy import copy
class DataFrameStyler:
    def __init__(self, dataframe, com_columns=[]):
        self.dataframe = dataframe.reset_index(drop=True).copy()
        self.dataframe.columns = pd.Index(self.dataframe.columns).drop_duplicates()
        self.style_df = pd.DataFrame('', index=self.dataframe.index, columns=self.dataframe.columns)
        self.columns_to_show = com_columns
        self.manual_columns = ['COMMENTS','Verified by','Pass/Fail']

    def highlight_cell(self, row_index, col_name, color="#FFFF00"):  # Default color is yellow
        self.style_df.at[row_index, col_name] = f'background-color: {color}'

    def highlight_entire_row(self, row_index, color="#FFFF00",all_column=False,to_check=False):  # New method to highlight entire row
        for col_name in self.dataframe.columns:
            if not all_column:
                if col_name in self.columns_to_show:
                    if col_name not in self.manual_columns:
                        self.highlight_cell(row_index, col_name, color)
            else:
                if col_name in self.columns_to_show:
                    self.highlight_cell(row_index, col_name, color)


    def get_cell_color(self, row_index, col_name):
        """Returns the background color of a specific cell."""
        return self.style_df.at[row_index, col_name]

    def add_column(self, column_name, values, after_column_name=None):
        if isinstance(values, str):
            values = [values] * len(self.dataframe)
        if len(values) != len(self.dataframe):
            raise ValueError(f"Length of values ({len(values)}) does not match length of index ({len(self.dataframe)}).")
        values = ["" if v is None else v for v in values]
        if after_column_name is None:
            self.dataframe[column_name] = values
            self.style_df[column_name] = ''
        else:
            # print(after_column_name)
            pos = self.dataframe.columns.get_loc(after_column_name) + 1
            cols = list(self.dataframe.columns)
            cols.insert(pos, column_name)
            self.columns_to_show.insert(pos, column_name)
            self.dataframe[column_name] = values
            self.dataframe = self.dataframe[cols]
            self.style_df[column_name] = ''
            self.style_df = self.style_df[cols]
    def filter_rows_by_value(self, column_name, value):
        """Filter rows where the specified column's value is equal to the provided value.
        
        Args:
            column_name (str): The name of the column to filter by.
            value: The value to filter for in the specified column.
        
        Returns:
            pd.DataFrame: A DataFrame with rows where the specified column matches the value.
        """
        if column_name not in self.dataframe.columns:
            raise ValueError(f"Column '{column_name}' does not exist in the DataFrame.")
        
        filtered_df = self.dataframe[self.dataframe[column_name] == value]
        return filtered_df
    def update_cell(self, row_index, col_name, value):
        if col_name in self.dataframe.columns:
            self.dataframe.at[row_index, col_name] = value

    def get_cell_value(self, row_index, col_name):
        return self.dataframe.at[row_index, col_name]

    def apply_styles(self):
        def apply_style(x):
            for row_index in self.style_df.index:
                row_style = self.style_df.loc[row_index]
                if 'background-color: red' in row_style.values or 'background-color: #FF0000' in row_style.values :
                    self.update_cell(row_index, "Pass/Fail", "FAIL")
                    for col_name in row_style.index:
                        if row_style[col_name] == 'background-color: #92D050': # Light Green
                            self.highlight_cell(row_index, col_name, color="#FFC000") # orange "#FFC000"
                else:
                    self.update_cell(row_index, "Pass/Fail", "PASS")
                    self.update_cell(row_index, "Verified by", "BOT")
                    if "PRODUCT" in self.dataframe.columns:
                        prd = self.get_cell_value(row_index, "PRODUCT")
                    for color in row_style.values:
                        # if "PRODUCT" in self.dataframe.columns:
                            # if prd == "SFG_MACRO_CER_VB":
                                # print(color)
                        if 'background-color: #00B0F0' != color: #blue sme
                            self.update_cell(row_index, "Pass/Fail", "")
                            self.update_cell(row_index, "Verified by", "BOT")
                        elif 'background-color: #92D050' != color and color != "": # Light Green
                            self.update_cell(row_index, "Pass/Fail", "FAIL")
                            self.update_cell(row_index, "Verified by", "")
            return self.style_df
        return self.dataframe.style.apply(apply_style, axis=None)

    def save_to_excel(self, writer, sheet_name):
        """Save the styled DataFrame to an Excel file and hide specified columns."""
        styled_df = self.apply_styles()
        styled_df.to_excel(writer, sheet_name=sheet_name, index=False, engine='openpyxl')

        # Get the workbook and sheet
        workbook = writer.book
        worksheet = writer.sheets[sheet_name]
        for col_name in self.dataframe.columns:
            col_idx = self.dataframe.columns.get_loc(col_name) + 1  # +1 because openpyxl is 1-indexed
            col_letter = get_column_letter(col_idx)
            
            if len(self.columns_to_show) > 0:
                # Check if the column is in columns_to_show; show it if yes, hide it otherwise
                if col_name in self.columns_to_show:
                    worksheet.column_dimensions[col_letter].hidden = False
                else:
                    worksheet.column_dimensions[col_letter].hidden = True

    def add_comments(self, index, comment):
        """Add comments to the 'COMMENTS' column."""
        # Retrieve the old comment
        old_comment = self.get_cell_value(index, "COMMENTS")
        # Initialize the new comment number
        new_comment_number = 1
        # Check if there are existing comments
        if old_comment == "Verified - OK" or not old_comment.strip():
            # No previous comments, add the new comment as the first one
            updated_comment = f"{new_comment_number}. {comment}"
        else:
            # Split the old comments into lines
            lines = old_comment.strip().split('\n')
            # Initialize the comment counter based on the existing comments
            comment_counter = 0
            # Iterate through each line to check for numbered comments
            for line in lines:
                match = re.match(r'^(\d+)\.', line.strip())
                if match:
                    comment_number = int(match.group(1))
                    if comment_number > comment_counter:
                        comment_counter = comment_number
            # Increment the comment counter for the new comment
            new_comment_number = comment_counter + 1
            # Create the new comment string with the incremented number
            new_comment_string = f"{new_comment_number}. {comment}"
            # Append the new comment to the existing comments
            updated_comment = old_comment + "\n" + new_comment_string

        # Update the DataFrame with the new comment
        self.update_cell(row_index=index, col_name='COMMENTS', value=updated_comment)

    def color_specific_columns(self, row_index, columns, color="#FFFF00"):
        """Color specific columns in a row."""
        for col_name in columns:
            if col_name in self.dataframe.columns:
                self.highlight_cell(row_index, col_name, color)
            else:
                raise ValueError(f"Column '{col_name}' does not exist in the DataFrame.")
    def duplicate_column(self, column_name, df):
        """Duplicate a column from the style DataFrame to the given DataFrame."""
        if column_name not in self.style_df.columns:
            raise ValueError(f"Column '{column_name}' does not exist in style_df.")

        # Duplicate the column and add it to the provided DataFrame
        df[column_name] = self.style_df[column_name]
        
        return df

class StyledExcelFile:
    def __init__(self, filename):
        self.filename = filename
        self.data = self._read_excel_with_styles()

    def _read_excel_with_styles(self):
        workbook = load_workbook(self.filename)
        data = {}

        for sheet_name in workbook.sheetnames:
            sheet = workbook[sheet_name]
            sheet_data = [
                [{
                    "value": cell.value if cell.value is not None else "",
                    "fill": copy(cell.fill) if cell.fill else PatternFill(fill_type=None),
                    "font": copy(cell.font),
                    "border": copy(cell.border),
                    "alignment": copy(cell.alignment),
                    "color": cell.fill.fgColor.rgb if cell.fill and cell.fill.fgColor and cell.fill.fgColor.rgb else None
                } for cell in row]
                for row in sheet.iter_rows()
            ]
            data[sheet_name] = sheet_data
        return data
    def create_json(self, columns):
        for sheet_name, sheet_data in self.data.items():
            if any(cell["value"] == 'JsonData' for cell in sheet_data[0]):
                # print(f"Column JsonData already exists in sheet '{sheet_name}'. Skipping addition.")
                continue
            # Check if 'JsonData' column exists
            json_data_column_index = None
            comments_column_index = None
            for idx, cell in enumerate(sheet_data[0]):
                if cell["value"] == 'JsonData':
                    json_data_column_index = idx
                if cell["value"] == 'COMMENTS':
                    comments_column_index = idx

            # If 'JsonData' column does not exist, add it
            if json_data_column_index is None:
                sheet_data[0].append({"value": 'JsonData', "fill": None, "font": None, "border": None, "alignment": None})
                json_data_column_index = len(sheet_data[0]) - 1

                # Add an empty JSON cell for each subsequent row
                for row in sheet_data[1:]:
                    row.append({"value": "", "fill": None, "font": None, "border": None, "alignment": None})

            # Identify available columns in the sheet
            available_columns = [cell["value"] for cell in sheet_data[0]]

            # Populate the 'JsonData' column for each row
            for row in sheet_data[1:]:
                if comments_column_index is not None and row[comments_column_index]["value"] == 'Verified - OK':
                    row[json_data_column_index]["value"] = "Passed"
                else:
                    json_data = {
                        column_name: "Select"
                        for column_name in columns
                        if column_name in available_columns
                    }
                    row[json_data_column_index]["value"] = str(json_data)
    def add_column(self, column_name,value):
        for sheet_name, sheet_data in self.data.items():
            # Check if the column already exists
            if any(cell["value"] == column_name for cell in sheet_data[0]):
                # print(f"Column '{column_name}' already exists in sheet '{sheet_name}'. Skipping addition.")
                continue
            # Add header to the first row
            sheet_data[0].append({"value": column_name, "fill": None, "font": None, "border": None, "alignment": None})
            # Add an empty cell to the new column for each subsequent row
            for row in sheet_data[1:]:
                row.append({"value": value, "fill": None, "font": None, "border": None, "alignment": None})

    def update_cell(self, sheet_name, column1_reference, new_value):
        if sheet_name not in self.data:
            return []  # Exit if the sheet doesn't exist

        sheet_data = self.data[sheet_name]
        header_row = sheet_data[0]

        # Get reference column indices and values
        ref_col_indices = {
            col_name: next((i for i, cell in enumerate(header_row) if cell["value"] == col_name), None)
            for col_name in column1_reference
        }

        # Ensure all reference columns exist
        if None in ref_col_indices.values():
            missing_cols = [col for col, idx in ref_col_indices.items() if idx is None]
            print(f"Reference columns {missing_cols} not found.")
            return []

        # Identify column indices for each target column in new_value
        target_col_indices = {
            col: next((i for i, cell in enumerate(header_row) if cell["value"] == col), None)
            for col in new_value
        }

        # Filter out non-existing target columns
        target_col_indices = {col: idx for col, idx in target_col_indices.items() if idx is not None}

        updated_indices = []  # Collect indices of updated rows

        # Update cells in rows where **all reference conditions match**
        for row_idx, row in enumerate(sheet_data[1:], start=1):  # Skip header row
            # Check if all reference column conditions match
            if all(row[ref_col_indices[col]]["value"] == val for col, val in column1_reference.items()):
                updated = False  # Track if this row is updated

                # Update target columns
                for col, vals in new_value.items():
                    if col in target_col_indices:
                        col_index = target_col_indices[col]

                        if vals["old_value"] == "":
                            # No old value provided, directly update the cell
                            row[col_index]["value"] = vals["new_value"]
                            updated = True
                        else:
                            # Old value is provided, check before updating
                            if row[col_index]["value"] == vals["old_value"]:
                                row[col_index]["value"] = vals["new_value"]
                                updated = True

                if updated:
                    updated_indices.append(row_idx + 1)  # Convert to 1-based index
        return updated_indices
    def get_cell_value(self, sheet_name, filter_criteria, column_name, return_all=False):
        """
        Get the value of a specific cell by filtering rows based on column references, using Pandas for efficiency.

        Args:
            sheet_name (str): Name of the sheet to search.
            filter_criteria (dict): Dictionary of column-value pairs to filter rows, e.g., {"column1": "value1", "column2": "value2"}.
            column_name (str): Name of the column whose value to retrieve from the matching row.
            return_all (bool): If True, return all matching values as a list; otherwise, return only the first match.

        Returns:
            Any: Single value if return_all is False, otherwise a list of values.
            None: If no row matches the filter criteria.
        """
        if sheet_name not in self.data:
            raise ValueError(f"Sheet '{sheet_name}' does not exist.")

        # Convert sheet data to a Pandas DataFrame
        sheet_data = self.data[sheet_name]
        header = [cell["value"] for cell in sheet_data[0]]
        rows = [[cell["value"] for cell in row] for row in sheet_data[1:]]

        # If sheet is empty (no rows), return None
        if not rows:
            return None

        df = pd.DataFrame(rows, columns=header)

        # Ensure the target column exists
        if column_name not in df.columns:
            raise ValueError(f"Column '{column_name}' does not exist in sheet '{sheet_name}'.")

        # Apply filter criteria
        for col, value in filter_criteria.items():
            if col not in df.columns:
                raise ValueError(f"Column '{col}' does not exist in sheet '{sheet_name}'.")
            df = df[df[col] == value]

        # Retrieve the value(s) from the filtered DataFrame
        if not df.empty:
            if return_all:
                return df[column_name].tolist()  # Return all matches as a list
            return df[column_name].iloc[0]  # Return the first match

        return None  # No match found

    def save(self, output_filename):
        new_workbook = Workbook()
        new_workbook.remove(new_workbook.active)

        for sheet_name, sheet_data in self.data.items():
            sheet = new_workbook.create_sheet(sheet_name)
            for r_idx, row_data in enumerate(sheet_data, start=1):
                for c_idx, cell_data in enumerate(row_data, start=1):
                    cell_value = cell_data["value"] if cell_data["value"] is not None else ""
                    cell = sheet.cell(row=r_idx, column=c_idx, value=cell_value)    
                    cell.fill = cell_data["fill"] if cell_data["fill"] and cell_data["fill"].fill_type else PatternFill(fill_type=None)
                    cell.font = cell_data["font"]
                    cell.border = cell_data["border"]
                    cell.alignment = cell_data["alignment"]

        new_workbook.save(output_filename)

import copy as C # Ensure correct import for deepcopy
import xml.etree.ElementTree as ET

class CreateXML:
    def __init__(self, name, xml_template,level):
        self.name = name
        self.lims_tree = C.deepcopy(xml_template)
        # Map sheet index to XML sections
        if level == "ItemCode":
            self.section_mapping = {
                "IC v7 summary": "T_PH_ITEM_CODE",
                "IC v7 spec": "T_PH_ITEM_CODE_SPEC",
                "IC v7 supplier": "T_PH_ITEM_CODE_SUPP",
            }
        else:
            self.section_mapping = {
                "v7 DEV - Product Summary": "PRODUCT",
                "v7 DEV - Product Grade": "PRODUCT_GRADE",
                "v7 DEV - Product Grade Stage": "PROD_GRADE_STAGE",
                "v7 DEV - Product Specification": "PRODUCT_SPEC",
                "v7 DEV - ETD_F Product Compds": "T_PH_PROD_COMP",
                "v7 DEV - ETD_N Product Compds": "T_PH_PROD_COMP",
                "v7 DEV - ETD_S Product Compds": "T_PH_PROD_COMP",
                "v7 DEV - ETD_F Prdt Cmpds Item": "T_PH_PROD_COMP_ITEM",
                "v7 DEV - ETD_N Prdt Cmpds Item": "T_PH_PROD_COMP_ITEM",
                "v7 DEV - ETD_S Prdt Cmpds Item": "T_PH_PROD_COMP_ITEM",
            }
        # self.sections_present = [False, False, False]

    def add_data(self, sheet_name, row_data):
        root = self.lims_tree.getroot()
        
        section_name = self.section_mapping[sheet_name]
        section_template = root.find(section_name)
        
        if section_template is None:
            raise ValueError(f"Section {section_name} not found in the template.")
        
        # Copy the template for the section
        new_section = C.deepcopy(section_template)
        
        # Populate data into the copied section
        self._populate_section(new_section, row_data)
        
        # Append the new section to the root
        root.append(new_section)
        # self.sections_present[sheet_index] = True

    def _populate_section(self, section, row_data):
        for key, value in row_data.items():
            if pd.isna(value):
                value = ""
            element = section.find(key)
            if element is not None:
                element.text = str(value)

    def remove_empty_sections(self):
        root = self.lims_tree.getroot()
                
        for sheet, section in self.section_mapping.items():
            elements = root.findall(section)  # Get all instances of the section
            for elem in elements:
                # Check if all child elements are empty
                if all((child.text is None or child.text.strip() == "") for child in elem):
                    root.remove(elem)  # Remove the section if empty
        
    def to_xml_string(self):
        """
        Returns the XML as a UTF-8 encoded string with the XML declaration.
        """
        self.remove_empty_sections()
        tree = ET.ElementTree(self.lims_tree.getroot())
        buffer = BytesIO()
        tree.write(buffer, encoding="utf-8", xml_declaration=True)
        return buffer.getvalue().decode("utf-8")

    def save_to_file(self, file_path):
        """
        Saves the XML to a file with UTF-8 encoding and the XML declaration.
        """
        self.remove_empty_sections()
        tree = ET.ElementTree(self.lims_tree.getroot())
        tree.write(file_path, encoding="utf-8", xml_declaration=True)
from flask import Flask, render_template, request, redirect, url_for, flash, session, jsonify, send_file
from pymongo import MongoClient
from openpyxl.styles import PatternFill
import openpyxl
from openpyxl import Workbook
import pandas as pd
import os
import git
GITHUB_REPO_URL = "github.com/Global-Value-Web/MedTech.git"
GITHUB_USERNAME = "Thamilarasan-GVW"
GITHUB_PAT = "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"
import re
import zipfile
# import shutil
import itemcode_comparison as IC
import product_comparison as Prod
import BotLib.interface_util as Util
from BotLib.filter_green_rows import process_excel
from BotLib.xml_schema_check import process_xml_files
# import logging
app = Flask(__name__)
app.config['MAX_CONTENT_LENGTH'] = 50 * 1024 * 1024  # 50 MB
app.secret_key = 'supersecretkey'  # For flash messages and session handling
# logging.basicConfig(level=logging.INFO)
# MongoDB connection details
# connection_string = "mongodb://192.168.0.2:27017/"
connection_string = "mongodb://localhost:27017/" 
db_name = "MedTech"
collection_name = "users"

# Connect to MongoDB
client = MongoClient(connection_string)
db = client[db_name]
collection = db[collection_name]
#================================================================= Login =================================================================
@app.route('/')
def login():
    return render_template('login_page.html')
@app.route('/login', methods=['POST'])
def login_post():
    gvw_id = request.form['gvw_id']
    password = request.form['password']

    user = collection.find_one({"gvw_id": gvw_id, "password": password})
    if user:
        session['gvw_id'] = user['gvw_id']
        session['username'] = user['user_name']
        session['status'] = user['status']

        flash("Login Successful!", "success")

        if user["status"] == 'admin':  # Admin login
            return redirect(url_for('admin_dashboard'))
        else:
            return redirect(url_for('itemcode'))
    else:
        flash("Invalid username or password. Please try again.", "error")
        return redirect(url_for('login'))
@app.route('/logout')
def logout():
    session.clear()
    flash("Logged out successfully.", "info")
    return redirect(url_for('login'))
def getusers():
    return list(collection.find({}, {"_id": 0,"gvw_id": 1, "user_name": 1, "status": 1}))
@app.route('/api/users', methods=['GET'])
def get_users_and_status():
    return jsonify(getusers())

@app.route('/api/users', methods=['POST'])
def add_user():
    if 'username' not in session or session['status'] != 'admin':
        return jsonify({"error": "Not authorized"}), 403

    data = request.get_json()
    gvw_id = data.get('gvw_id')
    username = data.get('username')
    password = data.get('password')
    status = data.get('status')
    if not gvw_id or not username or not password or not status:
        return jsonify({"error": "All fields are required"}), 200
    existing_user = collection.find_one({"gvw_id": gvw_id})
    if existing_user:
        return jsonify({"error": f"User '{gvw_id}' already exists."}), 200

    collection.insert_one({"gvw_id":gvw_id,"user_name": username, "password": password, "status": status})
    return jsonify({"message": f"User '{username}' added successfully."})
@app.route('/api/users/<username>', methods=['DELETE'])
def remove_user(username):
    if 'username' not in session or session['status'] != 'admin':
        return jsonify({"error": "Not authorized"}), 403

    current_admin = session.get('username')

    if username == current_admin:
        return jsonify({"error": "You cannot delete your own account."}), 400

    # if username == "admin":
    #     return jsonify({"error": "Cannot remove the main admin user."}), 400

    result = collection.delete_one({"user_name": username})
    if result.deleted_count > 0:
        return jsonify({"message": f"User '{username}' removed successfully."})
    else:
        return jsonify({"error": f"User '{username}' not found."}), 404

#=================================================================== Admin ===============================================================
import json
from datetime import datetime
from copy import copy
from copy import deepcopy

@app.route('/assign-tasks', methods=['POST'])
def assign_tasks():
    try:
        # Get the file path and task data from the request
        file_path = request.form.get('filepath')
        task_data = request.form.get('taskData')
        task_data = json.loads(task_data)
        selected_users = task_data['selected_users']
        thresholds = task_data['thresholds']
        level = request.form.get('level')  # Added level to the logic
        current_date = datetime.now().strftime('%d-%m-%Y')
        upload_dir = 'uploads'
        os.makedirs(upload_dir, exist_ok=True)

        user_files = []

        # Helper function to copy cell styles
        def copy_cell_styles(src_cell, dest_cell):
            """Copy cell styles from the source cell to the destination cell."""
            if src_cell.has_style:
                dest_cell.fill = copy(src_cell.fill)

        # Load the original workbook
        workbook = openpyxl.load_workbook(file_path)

        # Process each selected user
        for user in selected_users:
            start_row = thresholds[user]['start'] + 1
            end_row = thresholds[user]['end'] + 1

            # Create a new workbook for the user
            new_workbook = openpyxl.Workbook()
            new_workbook.remove(new_workbook.active)

            unique_item_codes = set()

            # Process each sheet in the original workbook
            for sheet_name in workbook.sheetnames:
                original_sheet = workbook[sheet_name]
                new_sheet = new_workbook.create_sheet(sheet_name)

                headers = {cell.value: cell.col_idx for cell in original_sheet[1]}
                
                # Determine the foreign key column based on the level and sheet structure
                if level == 'ItemCode':
                    foreign_key_column = 'NAME' if 'NAME' in headers else 'T_PH_ITEM_CODE'
                else:
                    foreign_key_column = 'NAME' if 'NAME' in headers else 'PRODUCT'

                key_col_idx = headers.get(foreign_key_column)

                # Copy headers
                for header_row in original_sheet.iter_rows(min_row=1, max_row=1):
                    for cell in header_row:
                        new_cell = new_sheet.cell(row=1, column=cell.column, value=cell.value)
                        copy_cell_styles(cell, new_cell)

                # Copy rows based on the logic
                for row in original_sheet.iter_rows(min_row=2):
                    key = row[key_col_idx - 1].value if key_col_idx else None

                    if sheet_name == workbook.sheetnames[0]:
                        # For the first sheet, filter rows based on the start_row and end_row
                        if row[0].row >= start_row and row[0].row <= end_row and key:
                            unique_item_codes.add(key)
                            new_row_index = new_sheet.max_row + 1
                            for cell in row:
                                new_cell = new_sheet.cell(row=new_row_index, column=cell.column, value=cell.value)
                                copy_cell_styles(cell, new_cell)
                    else:
                        # For subsequent sheets, filter rows based on the unique_item_codes
                        if key in unique_item_codes:
                            new_row_index = new_sheet.max_row + 1
                            for cell in row:
                                new_cell = new_sheet.cell(row=new_row_index, column=cell.column, value=cell.value)
                                copy_cell_styles(cell, new_cell)

            # Create a folder for the user's output files
            user_folder = os.path.join(upload_dir, user)
            os.makedirs(user_folder, exist_ok=True)
            output_file = os.path.join(user_folder, f'{level}_{current_date}.xlsx')

            # Ensure unique filename if file already exists
            def get_file_path(filepath):
                base, ext = os.path.splitext(filepath)  # Separate the filename and extension
                i = 1
                while os.path.exists(filepath):  # Keep checking until a unique filename is found
                    filepath = f"{base}_{i}{ext}"  # Add a counter to the filename
                    i += 1
                return filepath

            output_file = get_file_path(output_file)
            new_workbook.save(output_file)
            user_files.append(output_file)

        return jsonify({"message": "Tasks successfully assigned to users", "files": user_files})

    except Exception as e:
        print(f"Error occurred: {e}")
        return jsonify({"error": "Error assigning tasks."}), 400

@app.route('/admin')
def admin_dashboard():
    if 'username' not in session or session['status'] != 'admin':
        flash("You must be logged in as an admin to view this page.", "error")
        return redirect(url_for('login'))

    return render_template('admin_dashboard.html', users=list(collection.find({}, {"_id": 0, "user_name": 1, "status": 1})))
@app.route('/manage-users')
def manage_users():
    if 'username' not in session or session['status'] != 'admin':
        flash("You must be logged in as an admin to view this page.", "error")
        return redirect(url_for('login'))

    return render_template('manage_user.html', users=getusers()) 
@app.route('/assign')
def assign_task1():
    return render_template('assign_task.html')

UPLOAD_FOLDER = 'uploads/'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

@app.route('/upload-task-file', methods=['POST'])  # admin task file to assign
def upload_task_file():
    if 'taskFile' not in request.files:
        return jsonify({'error': 'No file part'}), 400

    file = request.files['taskFile']
    level = request.form.get('level')
    if file.filename == '':
        return jsonify({'error': 'No selected file'}), 400
    if file:
        try:
            # Save the uploaded file temporarily on the server
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], file.filename)
            file.save(file_path)
            
            # Process the Excel file using the process_excel function
            ignored_file, remaining_file, ignored_row_counts, remaining_row_counts = process_excel(file_path,level)
            print("process completed")
                # Extract the sheet names from the remaining file and return the row counts
            sheets = list(remaining_row_counts.keys())
            total_rows_per_sheet = remaining_row_counts  # Using the row counts of the remaining file

            # Respond with sheet names and total rows based on the remaining file
            return jsonify({    
                'sheets': sheets,
                'total_rows': total_rows_per_sheet,
                'passed_items': ignored_row_counts,
                'remaining_row_file_path':remaining_file,
                'users': getusers(),  # Assuming this function provides a list of users
                'download_url': '/download_file?path=' + ignored_file
            })

        except Exception as e:
            print(str(e))
            return jsonify({'error': str(e)}), 500

# =================================================================== Analyst ===================================================================================
@app.route('/compare')
def compare():
    # Fetch current username from the session
    current_user = session.get('username')
    user_status = session.get('status')

    if not current_user:
        return redirect(url_for('login'))  # Redirect to login if no username is found
    return render_template('compare_excel.html', username=current_user, status=user_status)
@app.route('/product')
def product():
    # Fetch current username from the session
    current_user = session.get('username')
    user_status = session.get('status')

    if not current_user:
        return redirect(url_for('login'))  # Redirect to login if no username is found
    return render_template('product_compare.html', username=current_user, status=user_status)
# @app.route('/product1')
# def product1():
#     return render_template('product_compare.html')
@app.route('/an_dashboard')
def analyst_dashboard():
    # Fetch current username from the session
    current_user = session.get('username')

    if not current_user:
        return redirect(url_for('login'))  # Redirect to login if no username is found
    return render_template('analyst_dashboard.html')



@app.route('/itemcode', methods=['GET', 'POST'])  # comparison itemcode
def itemcode():
    # Fetch current username from the session
    current_user = session.get('username')
    user_status = session.get('status')

    if not current_user:
        return redirect(url_for('login'))  # Redirect to login if no username is found
    if request.method == 'POST':
        file1 = request.files.get('file1')
        file2 = request.files.get('file2')
        if file1 and file2:
            v6_file = pd.ExcelFile(file1)
            v7_file = pd.ExcelFile(file2)
            if v6_file is not None and v7_file is not None:
                stylers = IC.read_itemcode_files(v6_excel=v6_file,v7_excel=v7_file)
                output_filename = os.path.join('uploads','Highlighted_V7_DEV.xlsx')
                with pd.ExcelWriter(output_filename, engine='openpyxl') as writer:
                    stylers['v7']['summary'].save_to_excel(writer, sheet_name='IC v7 summary')
                    stylers['v7']['spec'].save_to_excel(writer, sheet_name='IC v7 spec')
                    if len(stylers['v7']['supplier'].dataframe)>0:
                        stylers['v7']['supplier'].save_to_excel(writer, sheet_name='IC v7 supplier')
                output_filename1 = os.path.join('uploads','Highlighted_V6_PROD.xlsx')
                with pd.ExcelWriter(output_filename1, engine='openpyxl') as writer:
                    stylers['v6']['summary'].save_to_excel(writer, sheet_name='IC v6 summary')
                    stylers['v6']['spec'].save_to_excel(writer, sheet_name='IC v6 spec')
                    if len(stylers['v6']['supplier'].dataframe)>0:
                        stylers['v6']['supplier'].save_to_excel(writer, sheet_name='IC v6 supplier')

            # Save individual Excel files and zip them
            zip_file_path = Util.create_zip_file([output_filename,output_filename1], zip_filename='IC_Highlighted_files.zip',remove_files=False)

            return jsonify({"message": "Files are ready for download.", "download_url": '/download_file?path=' + zip_file_path})
        else:
            return 'Please upload two files.'
    return render_template('compare_excel.html', username=current_user, status=user_status)

import re

def generate_select_elements(comments, cell_value, Itemcode_Columns, idx, table_id):
    """
    Generate select elements for the approve column based on numbered comments.
    :param comments: COMMENTS column content (string)
    :param cell_value: Dictionary containing default selection for each column (e.g., {'NAME': 'Select'})
    :param Itemcode_Columns: List of column names to match in the comments
    :param idx: Index of the row (used in the onchange function)
    :param table_id: ID of the table (used in the onchange function)
    :return: HTML string with dropdowns for each numbered comment
    """
    table_html = ""

    # Split comments into lines and iterate through numbered comments
    for line in comments.split("\n"):
        match = re.match(r"(\d+)\.\s+(.*)", line)
        if match:
            comment_number = match.group(1)  # Extract the number (e.g., 1, 2, 3)
            comment_text = match.group(2)   # Extract the actual comment text

            # Check if the comment matches any pattern
            column_name = None
            Itemcode_Columns_with_the = ["The " + i for i in Itemcode_Columns]
            for name in Itemcode_Columns_with_the:
                if name in comment_text:
                    column_name = name.replace("The ", "")
                    break  # Exit the loop once a match is found

            # Determine the selected value for the dropdown
            selected_value = cell_value.get(column_name, "Select")

            # Create select element, include column name if matched
            label = f"{comment_number}. {column_name}:" if column_name else f"{comment_number}. Comment:"
            table_html += f'''
            <div>
                <label>{label}</label>
                <select name="{column_name}" onchange="edit_column('{table_id}','{column_name or 'UNKNOWN'}','{idx}')">
                    <option value="Select" {'selected' if selected_value == 'Select' else ''}>Select</option>
                    <option value="No" {'selected' if selected_value == 'No' else ''}>No</option>
                    <option value="NA" {'selected' if selected_value == 'NA' else ''}>N/A</option>
                    <option value="Yes" {'selected' if selected_value == 'Yes' else ''}>Yes</option>
                    <option value="Manual Correction" {'selected' if selected_value == 'Manual Correction' else ''}>Manual Correction</option>
                    <option value="Remove" {'selected' if selected_value == 'Remove' else ''}>Remove</option>
                    <option value="SME Verification" {'selected' if selected_value == 'SME Verification' else ''}>SME Verification</option>
                </select>
            </div>
            '''

    return table_html

def render_table(data,column_names, approve=True, sheet=None):
    if not data:
        return "<p>No data available</p>"
    # Itemcode_Columns = ["NAME","DESCRIPTION","SAMPLE_PLAN",'SPEC_CODE', 'T_PH_ITEM_CODE','PRODUCT_SPEC', 'PRODUCT_SPEC', 'SPEC_CLASS', 'GRADE',"SUPPLIER"]
    
    if sheet is not None:
        # Convert the Excel data into an HTML table
        table_html = '<table id="'+sheet+'" class="responsive-table">'
    else:
        # Convert the Excel data into an HTML table
        table_html = '<table class="responsive-table">'
    
    # Extract the first row as header
    header_row = data[0]
    data_rows = data[1:]  # Remaining rows are data
    
    # Identify the index of 'Approve', 'Status', and 'COMMENTS' columns
    approve_index = None
    status_index = None
    comments_index = None
    JsonData_index = None
    for i, cell in enumerate(header_row):
        if cell.get('value', '').lower() == 'approve':
            approve_index = i
        elif cell.get('value', '').lower() == 'status':
            status_index = i
        elif cell.get('value', '').lower() == 'comments':
            comments_index = i
        elif cell.get('value', '').lower() == 'jsondata':
            JsonData_index = i

    # Add table header row
    table_html += '<thead><tr>'
    table_html += '<th>S.No</th>'  # Serial Number column
    
    # Add headers dynamically
    for cell in header_row:
        header_value = cell.get('value', 'Column')
        if header_value == 'COMMENTS':
            table_html += f'<th> <div class="resizable">{header_value}</div></th>'
        elif header_value == 'History of Comments':
            table_html += f'<th> <div class="resizable">{header_value}</div></th>'
        else:
            table_html += f'<th>{header_value}</th>'
    
    table_html += '</tr></thead>'
    
    # Add table body
    table_html += '<tbody>'
    
    for idx, row in enumerate(data_rows, start=1):  # idx will be used for serial numbers
        table_html += '<tr>'
        
        # Add serial number column
        table_html += f'<td>{idx}</td>'
        
        # Add data from the Excel sheet with background color for each cell
        for col_idx, cell in enumerate(row):
            cell_value = cell.get("value", "")
            cell_color = cell.get("color")
            
            # Apply background color if specified
            if cell_color and cell_color != '00000000':  # Skip unfilled/black cells
                if isinstance(cell_color, str):  # Hex string
                    color_style = f'background-color: #{cell_color[2:]};'  # Remove '0x' prefix if needed
                elif isinstance(cell_color, tuple) and len(cell_color) == 3:  # RGB tuple
                    color_style = 'background-color: #{:02x}{:02x}{:02x};'.format(*cell_color)
                else:
                    color_style = ''
            else:
                color_style = ''  # No background color
            
            # Handle Approve and Status columns with dropdowns
            if col_idx == approve_index and approve:
                # Check COMMENTS column value for the current row
                comments_value = row[comments_index].get("value", "") if comments_index is not None else ""
                # comment_count = len(comments_value.split("\n"))
                cell_value = row[approve_index].get("value", "") if approve_index is not None else ""
                JsonData = row[JsonData_index].get("value", "").replace("'", "\"") if JsonData_index is not None else ""
                if comments_value == "Verified - OK" or JsonData == "Remove" or JsonData == "Passed":
                    table_html += f'''
                    <td style="{color_style}">
                        <select name="approve" disabled>
                            <option value="NA">N/A</option>
                        </select>
                    </td>
                    '''
                else:
                    # Use generate_select_elements for numbered comments
                    # print(" hi hello", JsonData)
                    table_html += f'<td style="{color_style}">' + generate_select_elements(comments_value, json.loads(JsonData),column_names,idx,sheet) + '</td>'
            elif col_idx == status_index:
                # Check COMMENTS column value for the current row
                cell_value = row[status_index].get("value", "") if status_index is not None else ""
                comments_value = row[comments_index].get("value", "") if comments_index is not None else ""
                cell_value = "BOT Verified" if comments_value == "Verified - OK" else cell_value
                selected_other = {
                    "Select": "selected" if cell_value == "Select" else "",
                    "In-Progress": "selected" if cell_value == "In-Progress" else "",
                    "Query": "selected" if cell_value == "Query" else "",
                    "Completed": "selected" if cell_value == "Completed" else "",
                    "Removed": "Removed" if cell_value == "Removed" else "",
                    "BOT Verified": "selected" if cell_value == "BOT Verified" else "",
                }
                disable_select = "disabled" if selected_other["BOT Verified"] !="" else ""
                table_html += f'''
                <td style="{color_style}">
                    <select name="status" {disable_select}>
                        <option value="Select" {selected_other["Select"]}>Select</option>
                        <option value="In-Progress" {selected_other["In-Progress"]}>In-Progress</option>
                        <option value="Query" {selected_other["Query"]}>Query</option>
                        <option value="Completed" {selected_other["Completed"]}>Completed</option>
                        <option value="Removed" {selected_other["Removed"]} >Removed</option>
                        <option value="BOT Verified" {selected_other["BOT Verified"]} >BOT Verified</option>
                    </select>
                </td>
                '''
            else:
                table_html += f'<td style="{color_style}">{cell_value}</td>'
        
        table_html += '</tr>'
    
    table_html += '</tbody>'
    table_html += '</table>'
    
    return table_html

# @app.route('/task') # load analyst task page and get assigned task files
# def task():
#     # Fetch current username from the session
#     current_user = session.get('username')
#     user_status = session.get('status')
#     if not current_user:
#         return redirect(url_for('login'))  # Redirect to login if no username is found

#     # Define the path to the user's folder inside 'upload'
#     user_folder = os.path.join('uploads', current_user)
#     # Check if the folder exists
#     if not os.path.exists(user_folder):
#         os.makedirs(user_folder, exist_ok=True)
#         # return f"Folder for user {current_user} not found."

#     # Get a list of Excel files in the user's folder (checking for .xls and .xlsx extensions)
#     excel_files = [f for f in os.listdir(user_folder) if f.endswith(('.xlsx'))]

#     # Render the task.html template, passing the list of Excel files
#     return render_template('task.html', excel_files=excel_files, username=current_user,status=user_status)

from BotLib.excel_op import StyledExcelFile
@app.route('/read_excel', methods=['POST']) # analyst task file upload or change
def read_excel():
    # Get the selected file name from the request
    file_name = request.form['fileName']
    level = request.form['level']
    file_path = os.path.join('uploads', session['username'], file_name)
    # Initialize and load data with styles using StyledExcelFile
    analyst_task_file = StyledExcelFile(file_path)
    analyst_task_file.add_column("Status", "Select")
    analyst_task_file.add_column("Approve", "Select")
    manual_cols_to_show = ["S.No","COMMENTS", "Verified by", "Pass/Fail","Approve","Status",'History of Comments']
    if level == 'ItemCode':
        column_names = list(set(IC.summary_columns+IC.specification_columns+IC.supplier_columns))
        # Itemcode_Columns = ["NAME","DESCRIPTION","SAMPLE_PLAN",'SPEC_CODE', 'T_PH_ITEM_CODE','PRODUCT_SPEC', 'PRODUCT_SPEC', 'SPEC_CLASS', 'GRADE',"SUPPLIER"]
        analyst_task_file.create_json(column_names)
        col_to_show = {"IC v7 summary":IC.summary_columns+manual_cols_to_show, "IC v7 spec":IC.specification_columns+manual_cols_to_show,"IC v7 supplier":IC.supplier_columns+manual_cols_to_show}
    else:
        column_names = list(set(Prod.summary_columns+Prod.prod_stage_columns+Prod.prod_spec_columns+Prod.prod_comp_col_ETDF+Prod.prod_comp_col_ETDN+Prod.prod_comp_col_ETDS))
        # Itemcode_Columns = ["NAME","DESCRIPTION","SAMPLE_PLAN",'SPEC_CODE', 'T_PH_ITEM_CODE','PRODUCT_SPEC', 'PRODUCT_SPEC', 'SPEC_CLASS', 'GRADE',"SUPPLIER"]
        analyst_task_file.create_json(column_names)
        col_to_show = {"v7 DEV - Product Summary":Prod.summary_columns+manual_cols_to_show,
                            "v7 DEV - Product Grade":[],
                            "v7 DEV - Product Grade Stage":Prod.prod_stage_columns+manual_cols_to_show,
                            "v7 DEV - Product Specification":Prod.prod_spec_columns+manual_cols_to_show, 
                            "v7 DEV - ETD_F Product Compds":[],
                            "v7 DEV - ETD_N Product Compds":[],
                            "v7 DEV - ETD_S Product Compds":[],
                            "v7 DEV - ETD_F Prdt Cmpds Item":Prod.prod_comp_col_ETDF+manual_cols_to_show,
                            "v7 DEV - ETD_N Prdt Cmpds Item":Prod.prod_comp_col_ETDN+manual_cols_to_show,
                            "v7 DEV - ETD_S Prdt Cmpds Item":Prod.prod_comp_col_ETDS+manual_cols_to_show}
    
    # Convert all sheets to HTML tables
    sheet_data = {}
    for sheet_name, sheet_rows in analyst_task_file.data.items():
        html_table = render_table(sheet_rows,column_names,sheet=sheet_name)  # Generate HTML table with cell styles
        sheet_data[sheet_name] = html_table
    analyst_task_file.save(file_path)
    # Return all sheet tables in the response
    return jsonify({"sheets": list(analyst_task_file.data.keys()), "tables": sheet_data,"columns_to_show":col_to_show})

import ast

def is_string_dictionary(string):
    try:
        data = ast.literal_eval(string)
        return isinstance(data, dict)
    except (ValueError, SyntaxError):
        return False
@app.route('/save_verified_task', methods=['POST']) # clicked save button in approval interface
def save_verified_task():
    # Get the filtered data from the request
    filtered_data = request.json['operational_data']
    analyst_name = session['username']  # Get the analyst name from the session

    file_name = request.json['task_file_name']
    level = request.json['level']
    file_path = os.path.join('uploads', analyst_name, file_name)
    analyst_task_file = StyledExcelFile(file_path)
    # Ensure analyst_task_file exists
    if not analyst_task_file:
        print("Workbook not loaded. Please upload the Excel file first.")
        return jsonify({"error": "Workbook not loaded. Please upload the Excel file first."}), 400

    # Iterate over the sheets in the operational data
    for i, (sheet_name, sheet_data) in enumerate(filtered_data.items()):
        if sheet_data:
            # Convert sheet data into a DataFrame
            df = pd.DataFrame(sheet_data)
            if level == 'ItemCode':
                foreign_key_column = 'NAME' if 'NAME' in df.columns else 'T_PH_ITEM_CODE'
            else:
                foreign_key_column = 'NAME' if 'NAME' in df.columns else 'PRODUCT'
                sheet_foreign_key = ['PRODUCT','GRADE','ANALYSIS','COMPONENT']
            # Process each row in the DataFrame
            for index, row in df.iterrows():
                approve_data = row.get('Approve', {})  # Get the nested Approve dictionary
                code = row.get(foreign_key_column, "")
                if level == 'ItemCode':
                    column1_reference = {foreign_key_column: code}
                else:
                    abc = {key: row[key] for key in sheet_foreign_key if key in row.index}  
                    column1_reference = {foreign_key_column: code, **abc}
                JsonData = analyst_task_file.get_cell_value(sheet_name,column1_reference,"JsonData")
                # print(column1_reference, JsonData, code)
                if is_string_dictionary(JsonData):
                    JsonData = json.loads(JsonData.replace("'", "\""))
                    JsonData.update(approve_data)
                    update_data = {"JsonData":{"new_value": json.dumps(JsonData),"old_value":""}}
                else:
                    update_data = {"JsonData":{"new_value": json.dumps(approve_data),"old_value":""}}
                analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)
                update_status = {"Status":{"new_value": row.get('Status', ""),"old_value":""}}
                analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_status)
                
    analyst_task_file.save(file_path)
    print("Workbook saved at:", file_path)

    # GitHub authentication URL (HTTPS)
    repo_url = f"https://{GITHUB_USERNAME}:{GITHUB_PAT}@{GITHUB_REPO_URL}"

    # Local repository path (clone it once if not already cloned)
    local_repo_path = "C:\\Users\\THAMILARASAN\\Desktop\\MedTech Project\\Bot\\MedTech"  # Change this to your local repo path
    # local_repo_path = r"C:\Users\THAMILARASAN\Desktop\MedTech Project\Bot\MedTech"
    if not os.path.exists(local_repo_path):
        git.Repo.clone_from(repo_url, local_repo_path)

    # Open the repo
    repo = git.Repo(local_repo_path)

    # Copy the file to the repository
    dest_path = os.path.join(local_repo_path, file_name)
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    # os.system(f'cp "{file_path}" "{dest_path}"')

    # src = os.path.join('uploads', analyst_name, file_name)
    # dst = os.path.join(local_repo_path, file_name)
    # shutil.copy(src, dst)

    # Add, commit, and push the file
    repo.git.add(file_path)
    repo.index.commit(f"Added by {analyst_name} on {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    repo.remotes.origin.push()

    return {"status": "success", "message": f"{file_name} pushed to GitHub"}, 200

    # # Return the updated HTML tables as a JSON response
    # return jsonify({'tables': "Saved Successfully"}), 200
IC_comment_patterns = {
    "SPEC_CODE": [
        r'The SPEC_CODE is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)"'
    ],
    "DESCRIPTION": [
        r'The DESCRIPTION is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)"',
        r'The Itemcode "ETD_(?P<item>.*?)" is not available in Artikel Liste file\. The DESCRIPTION is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)" as per v6 PROD\.'
    ],
    "SAMPLE_PLAN": [
        r'The SAMPLE_PLAN is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)"'
    ],
    "PRODUCT_SPEC": [
        r'The PRODUCT_SPEC is "(?P<current>.*?)".*?It should be "(?P<expected>.*?)".*?as per the combination of product spec and Grade in v6 PROD\.'
    ],
    "GRADE": [
        r'The GRADE is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)" as per Product MD Tracker\.'
    ],
    "SPEC_CLASS": [
        r'The SPEC_CLASS is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)" as per MD Protocol\.'
    ],
    "SUPPLIER": [
        # In this pattern, we capture the second value as "prod" and then ensure the expected value is "ETD_" followed by that same value.
        r'The SUPPLIER is "(?P<current>.*?)" in v7 DEV\. It is "(?P<prod>.*?)" as per v6 PROD\. It should be "ETD_(?P<expected>(?P=prod))" in v7 DEV\.',
        r'The SUPPLIER is "(?P<current>.*?)" in v7 DEV\. It is "\[(?P<prod>.*?)\]" in v6 PROD\. It should be either (?P<expected>.*?) in v7 DEV\.'
    ]
}


Product_comment_patterns = {
    # specification patterns
    "PRODUCT": [],
    "UNITS": [
        r'The UNITS is "(?P<current>.*?)" in v7 DEV\. It is "(?P<prod>.*?)" in v6 PROD\. It should be "(?P<expected>.*?)" as per v6 PROD and MD Tracker\.'
    ],
    "RULE_TYPE": [
        r'The RULE_TYPE is "(.*?)" in v7 DEV\. It is "(.*?)" in v6 PROD\.'
    ],
    "SPEC_RULE": [
        r'The SPEC_RULE is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD'
    ],
    "PLACES": [
        r'The PLACES is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" according to v6 Spec limits \(Min value - (.*?)\)(?:\. Note: v7 Min value is Blank)?\.',
        r'The PLACES is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" according to v6 Spec limits \(Max value - (.*?)\)(?:\. Note: v7 Max value is Blank)?\.',
        r'The PLACES is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" according to v6 Spec limits \(Min value - (.*?)\)\. Note: v7 Min value is Blank\.',
        r'The PLACES is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" according to v6 Spec limits \(Min value - (.*?)\)\.',
        r'The PLACES is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" according to v6 Spec limits \(Max value - (.*?)\)\. Note: v7 Max value is Blank\.',
        r'The PLACES is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" according to v6 Spec limits \(Max value - (.*?)\)\.'
    ],
    "MIN_VALUE": [
        r'The MIN_VALUE is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.?'
    ],
    "MAX_VALUE": [
        r'The MAX_VALUE is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.?'
    ],
    "GRADE": [
        r'The GRADE "(?P<current>.*?)" is in v7 DEV\. It should be "(?P<expected>.*?)" as per MD Tracker\.?',
        r'The GRADE is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)" as per Product MD Tracker\.'
    ],
    "HI_CONTROL_2": [
        r'The HI_CONTROL_2 is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.?'
    ],
    "TEXT_VALUE": [
        r'The TEXT_VALUE is "Blank" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.?',
        r'The TEXT_VALUE is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.?'
    ],
    "REQUIRED": [
        r'The REQUIRED Boolean is "False" in v7 DEV\. It Should be "(?P<expected>True)" as per site instruction for (.*?) prefix Products\.?'
    ],
    "ROUND": [
        r'The ROUND is "False" in v7 DEV\. It should be "(?P<expected>True)" as per MD Protocol for Numeric component\.?',
        r'The ROUND is "True" in v7 DEV\. It should be "(?P<expected>False)" as per MD Protocol for Text component\.?'
    ],
    "STAGE": [
        r'The STAGE is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.'
    ],
    "ANALYSIS": [],
    "COMPONENT": [],
    # summary patterns
    "CODE": [],
    "SAMPLE_PLAN": [
        r'The SAMPLE_PLAN is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)"'
    ],
    "T_PH_CU_DOSAGE": [
        r'The T_PH_CU_DOSAGE is "(?P<current>.*?)" in v7 DEV\. It should be BLANK as per MD Protocol\.?',
        r'The T_PH_CU_DOSAGE is "(?P<current>.*?)" in v7 DEV\. It should be "CIA or RM" as per MD Protocol\.?',
        r'The T_PH_CU_DOSAGE is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per MD Protocol\.?'
    ],
    "REPORTED_NAME": [
        r'The REPORTED_NAME is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per MD Protocol\.?'
    ],
    "NUM_RESULT_REPS": [
        r'The NUM_RESULT_REPS is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.?'
    ],
    "CLASS": [
        r'The CLASS is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.'
    ],
    "HI_CONTROL_1": [
        r'The HI_CONTROL_1 is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.?'
    ],
    "LO_CONTROL_1": [
        r'The LO_CONTROL_1 is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.?'
    ],
    "NUM_REPS": [
        r'The NUM_REPS is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.'
    ],
    "T_PH_SAME_LOT": [
        r'The T_PH_SAME_LOT is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.?'
    ],
    "T_PH_STATUS1": [
        r'The T_PH_STATUS1 is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per v6 PROD\.?'
    ],
    "DESCRIPTION": [
        r'The DESCRIPTION is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per Artikel Liste file\.?',
        r'The DESCRIPTION is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)"',
        r'The DESCRIPTION is "(?P<current>.*?)" in v7 DEV\. The Item Code "(.*?)" is unavailable in Artikel liste file\. It should be "(?P<expected>.*?)" as per v6 PROD\.?'
        r'The Itemcode "ETD_(?P<item>.*?)" is not available in Artikel Liste file\. The DESCRIPTION is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)" as per v6 PROD\.'
    ],
    "PRODUCT_SPEC": [
        r'The PRODUCT_SPEC is "(?P<current>.*?)".*?It should be "(?P<expected>.*?)".*?as per the combination of product spec and Grade in v6 PROD\.'
    ],
    "SPEC_CLASS": [
        r'The SPEC_CLASS is "(?P<current>.*?)" .* It should be "(?P<expected>.*?)" as per MD Protocol\.'
    ],
    # compound_ETDF_comment_patterns
    "ITEM": [
        r'The ITEM "(?P<current>.*?)" is not available in v6 PROD to perform the comparison\.?'
    ],
    "COMPOUND": [
        r'The COMPOUND is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per site instruction for ETD_F Prefix Products\.?',
        r'The COMPOUND is "(?P<current>.*?)" in v7 DEV\. It is apart from the mentioned compound list\.?'
    ],
    "VALUE": [
        r'The VALUE of (?P<compound>.*?) is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per site instruction\.?',
        r'The VALUE is "(?P<current>.*?)" in v7 DEV\. It should be "(?P<expected>.*?)" as per site instruction\.?'
    ],
}

@app.route('/submit_filtered_data', methods=['POST']) # clicked submit button in approval interface
def submit_filtered_data():
    # Get the filtered data from the request
    filtered_data = request.json['operational_data']
    level = request.json['level']
    updated_tables = {}
    all_changes_logs = []  # Store all logs here
    analyst_name = session['username']  # Get the analyst name from the session

    file_name = request.json['task_file_name']
    file_path = os.path.join('uploads', analyst_name, file_name)
    analyst_task_file = StyledExcelFile(file_path)
    # Ensure analyst_task_file exists
    if not analyst_task_file:
        print("Workbook not loaded. Please upload the Excel file first.")
        return jsonify({"error": "Workbook not loaded. Please upload the Excel file first."}), 400

    # Iterate over the sheets in the operational data
    for i, (sheet_name, sheet_data) in enumerate(filtered_data.items()):
        if sheet_data:
            print(sheet_name,len(sheet_data))
            # Convert sheet data into a DataFrame
            df = pd.DataFrame(sheet_data)
            if level == 'ItemCode':
                foreign_key_column = 'NAME' if 'NAME' in df.columns else 'T_PH_ITEM_CODE'
                column_names = list(set(IC.summary_columns+IC.specification_columns+IC.supplier_columns))
                comment_patterns = IC_comment_patterns
            else:
                foreign_key_column = 'NAME' if 'NAME' in df.columns else 'PRODUCT'
                sheet_foreign_key = ['PRODUCT','GRADE','ANALYSIS','COMPONENT','ITEM','COMPOUND']
                column_names = list(set(Prod.summary_columns+Prod.prod_stage_columns+Prod.prod_spec_columns+Prod.prod_comp_col_ETDF+Prod.prod_comp_col_ETDN+Prod.prod_comp_col_ETDS))
                comment_patterns = Product_comment_patterns
      
            # Process each row in the DataFrame
            for index, row in df.iterrows():
                approve_data = row.get('Approve', {})  # Get the nested Approve dictionary
                status_val = row.get('Status', "")
                code = row.get(foreign_key_column, "")
                if level == 'ItemCode':
                    column1_reference = {foreign_key_column: code}
                else:
                    abc = {key: row[key] for key in sheet_foreign_key if key in row.index}  
                    column1_reference = {foreign_key_column: code, **abc}
                # Process based on the length of the Approve dictionary
                if len(approve_data) > 0:
                    for approve_key, approve_value in approve_data.items():
                        if approve_value == "Yes":
                            # Call process_comments_and_update for rows with Approve "Yes"
                            if 'COMMENTS' in df.columns:
                                row = df.iloc[index]
                                comment = row['COMMENTS']
                                approve_data = row['Approve']
                                Status = row['Status']
                                if pd.notna(comment):  # Ensure the comment is not NaN
                                    # Split the comments by serial number (e.g., '1.', '2.')
                                    comment_sections = re.split(r'\d+\.\s+', comment)[1:]  # Split and ignore the first empty element
                                    for section in comment_sections:
                                        for pattern in comment_patterns[approve_key]:
                                            try:
                                                match = re.search(pattern, section)
                                            except re.error as regex_error:
                                                # Log the error and skip to the next pattern
                                                # print(f"Regex error with pattern '{pattern}': {regex_error}")
                                                continue
                                            if match:
                                                # Directly retrieve the expected value using the named capturing group.
                                                try:
                                                    expected_value = match.group("expected")
                                                except IndexError:
                                                    # Log the error and skip to the next pattern
                                                    # print(f"Regex error with pattern '{pattern}': {regex_error}")
                                                    continue
                                                if expected_value:
                                                    # If the expected value is "Blank", set new_value to an empty string.
                                                    new_value = "" if expected_value == "Blank" else expected_value
                                                    old_value = row.get(approve_key, None)
                                                    all_changes_logs.append({
                                                        "Analyst": analyst_name,
                                                        level:code,
                                                        "Level":sheet_name,
                                                        "Column": approve_key,
                                                        "Old_value": old_value,
                                                        "New_value": new_value,
                                                        'Approved': 'Yes',
                                                        "Date": datetime.now()  # Timestamp of when the log was recorded
                                                    })
                                                    df.at[index, approve_key] = new_value
                                                    # Create the reference to locate the row and the new value to update
                                                    update_data = {approve_key:{"new_value": new_value,"old_value":old_value}}
                                                    # print(update_data)
                                                    # Update the specific cell in the workbook using StyledExcelFile's method
                                                    analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)
                                                    JsonData = analyst_task_file.get_cell_value(sheet_name,column1_reference,"JsonData")
                                                    # print(column1_reference, JsonData, code)
                                                    if is_string_dictionary(JsonData):
                                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                                        JsonData.update(approve_data)
                                                        update_data = {"JsonData":{"new_value": json.dumps(JsonData),"old_value":""}}
                                                    else:
                                                        update_data = {"JsonData":{"new_value": json.dumps(approve_data),"old_value":""}}
                                                    analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)

                                                    update_data = {"Status":{"new_value": Status,"old_value":""}}
                                                    analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)
                                                    break  # Break the pattern loop if a match is found
                                                else:
                                                    print("No expected value captured in the pattern:",section, pattern)                                                    
                                        else:
                                            continue  # Continue to the next column if no pattern matches
                                        break  # Break the column loop if a pattern matches
                                    
                        elif approve_value == "Manual Correction":
                            new_val = df.iloc[index][approve_key]
                            update_data = {approve_key:{"new_value": new_val,"old_value":""}}
                            analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)
                            JsonData = analyst_task_file.get_cell_value(sheet_name,column1_reference,"JsonData")
                            if is_string_dictionary(JsonData):
                                JsonData = json.loads(JsonData.replace("'", "\""))
                                JsonData.update(approve_data)
                                update_data = {"JsonData":{"new_value": json.dumps(JsonData),"old_value":""}}
                            else:
                                update_data = {"JsonData":{"new_value": json.dumps(approve_data),"old_value":""}}
                            analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)
                            old_val = analyst_task_file.get_cell_value(sheet_name,column1_reference,approve_key)
                            all_changes_logs.append({
                                                    "Analyst": analyst_name,
                                                    level:code,
                                                    "Level":sheet_name,
                                                    "Column": approve_key,
                                                    "old_value": old_val,
                                                    "New_value": new_val,
                                                    'Approved': approve_value,
                                                    "Date": datetime.now()  # Timestamp of when the log was recorded
                                                    })
                        elif approve_value == "Remove":
                            update_data = {"JsonData":{"new_value": "Remove","old_value":""}}
                            analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)
                            
                            update_data = {"Status":{"new_value": status_val,"old_value":""}}
                            analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)
                        elif approve_value == "No":
                            JsonData = analyst_task_file.get_cell_value(sheet_name,column1_reference,"JsonData")
                            if is_string_dictionary(JsonData):
                                JsonData = json.loads(JsonData.replace("'", "\""))
                                JsonData.update(approve_data)
                                update_data = {"JsonData":{"new_value": json.dumps(JsonData),"old_value":""}}
                            else:
                                update_data = {"JsonData":{"new_value": json.dumps(approve_data),"old_value":""}}
                            analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)
                            
                            update_data = {"Status":{"new_value": status_val,"old_value":""}}
                            analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data) 
                        elif approve_value == "SME Verification":
                            JsonData = analyst_task_file.get_cell_value(sheet_name,column1_reference,"JsonData")
                            if is_string_dictionary(JsonData):
                                JsonData = json.loads(JsonData.replace("'", "\""))
                                JsonData.update(approve_data)
                                update_data = {"JsonData":{"new_value": json.dumps(JsonData),"old_value":""}}
                            else:
                                update_data = {"JsonData":{"new_value": json.dumps(approve_data),"old_value":""}}
                            analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)

                            update_data = {"Status":{"new_value": status_val,"old_value":""}}
                            analyst_task_file.update_cell(sheet_name=sheet_name, column1_reference=column1_reference, new_value=update_data)  
                            all_changes_logs.append({
                                                    "Analyst": analyst_name,
                                                    level:code,
                                                    "Level":sheet_name,
                                                    "Column": approve_key,
                                                    # "old_value": old_value,
                                                    # "new_value": new_val,
                                                    'Approved': approve_value,
                                                    "Date": datetime.now()  # Timestamp of when the log was recorded
                                                })             
            # Convert the updated DataFrame back into the list-of-dictionaries format with colors
            updated_data = Util.df_to_dict_with_colors(df)
            # Render the updated HTML table with colors
            updated_tables[sheet_name] = render_table(updated_data,column_names, approve=False, sheet=sheet_name)
    # If there are changes to log, save them to MongoDB
    collection_name = "Change_Logs"
    # Connect to MongoDB
    # client = MongoClient(connection_string)
    # db = client[db_name]
    collection = db[collection_name]
    # Prepare the change logs for MongoDB
    for log_entry in all_changes_logs:
        collection.insert_one(log_entry)
    # client.close()  # Close the MongoDB connection
    print(file_path)
    analyst_task_file.save(file_path)
    print("Workbook saved at:", file_path)
    # print(updated_tables)
    # Return the updated HTML tables as a JSON response
    return jsonify({'tables': updated_tables}), 200

@app.route('/upload_files', methods=['POST'])
def upload_files_for_rerun():
    try:
        v6File = request.files.get('v6File')
        IC_file = request.files.get('IC_file')

        v6FilePath, ICFilePath = None, None

        if v6File:
            v6FilePath = os.path.join(UPLOAD_FOLDER, v6File.filename)
            v6File.save(v6FilePath)

        if IC_file:
            ICFilePath = os.path.join(UPLOAD_FOLDER, IC_file.filename)
            IC_file.save(ICFilePath)

        return jsonify({
            "message": "Files uploaded successfully",
            "v6FilePath": v6FilePath,
            "ICFilePath": ICFilePath
        })
    except Exception as e:
        return jsonify({"error": str(e)}), 500
@app.route('/rerun_md_review_bot', methods=['POST']) #rerun the bot
def rerun_md_review_bot():
    # Retrieve the uploaded V6 Excel file
    data = request.get_json()
    v6_file = data.get('v6File')
    level = data.get('level')
    if not v6_file:
        print("No V6 file found in the request.")
        return jsonify({'error': 'V6 file is required'}), 400

    # Retrieve the V7 data sent from the front-end
    v7_data = data.get('allData')
    if not v7_data:
        print("No V7 data found in the request.")
        return jsonify({'error': 'V7 data is required'}), 400

    # Convert the V7 JSON data back into a dictionary
    # v7_data = eval(v7_data)  # Be careful with eval, only use it if input is trusted
    file_name = data.get('task_file_name')
    file_path = os.path.join('uploads', session['username'], file_name)
    v7_excel = pd.ExcelFile(file_path)
    # Load V6 Excel file into pandas DataFrames
    v6_excel = pd.ExcelFile(v6_file)  # Read the uploaded V6 file
    # Helper function to check if DataFrame is effectively empty based on placeholder values
    def is_effectively_empty(df):
        return df.empty or df.eq('No Data Available').all().all() or df.eq('undefined').all().all()
    styler_dict = {}
    if level == 'ItemCode':
        # Load V6 Excel file into pandas DataFrames, specifying dtypes or converters
        stylers = IC.read_itemcode_files(v6_excel=v6_excel,v7_excel=v7_excel,rerun=True)
        unique_itemcodes_set = set()
        with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
            stylers['v7']['summary'].save_to_excel(writer, sheet_name='IC v7 summary')
            styler_dict['IC v7 summary'] = (stylers['v7']['summary'],"NAME")
            v7_query_summary1 = pd.DataFrame(v7_data.get('IC v7 summary'))
            # Check and collect unique values from `v7_query_summary1`
            if isinstance(v7_query_summary1, pd.DataFrame) and not is_effectively_empty(v7_query_summary1):
                unique_itemcodes_set.update(v7_query_summary1['NAME'].unique())

            stylers['v7']['spec'].save_to_excel(writer, sheet_name='IC v7 spec')
            styler_dict['IC v7 spec'] = (stylers['v7']['spec'],"T_PH_ITEM_CODE")
            v7_query_spec1 = pd.DataFrame(v7_data.get('IC v7 spec'))
            if isinstance(v7_query_spec1, pd.DataFrame) and not is_effectively_empty(v7_query_spec1):
                unique_itemcodes_set.update(v7_query_spec1['T_PH_ITEM_CODE'].unique())

            if stylers['v7']['supplier'] is not None:
                stylers['v7']['supplier'].save_to_excel(writer, sheet_name='IC v7 supplier')
                styler_dict['IC v7 supplier'] = (stylers['v7']['supplier'],"T_PH_ITEM_CODE")
                v7_query_supplier1 = pd.DataFrame(v7_data.get('IC v7 supplier'))
                if isinstance(v7_query_supplier1, pd.DataFrame) and not is_effectively_empty(v7_query_supplier1):
                    unique_itemcodes_set.update(v7_query_supplier1['T_PH_ITEM_CODE'].unique())       
        # Convert the set to a list for final output
        unique_itemcodes = list(unique_itemcodes_set)
        # Use the unique item codes to filter across the three sheets and save to Excel
        output_filename = Util.filter_items(unique_itemcodes, styler_dict, output_file='Rerun_Itemcode_Highlighted_V7_DEV.xlsx')

    else:
        IC_file = data.get('IC_file')
        stage_summary_styler, spec_styler, comp_styler, prefix, Missing_data = Prod.process_Product_files(v6_excel,v7_excel,IC_file,rerun=True)
        unique_product_set = set()
        # output_filename = os.path.join('uploads', prefix+'PRODUCT_Highlighted_V7_DEV.xlsx')
        with pd.ExcelWriter(file_path, engine='openpyxl') as writer:
            stage_summary_styler['v7']['summary'].save_to_excel(writer, sheet_name='v7 DEV - Product Summary')
            styler_dict['v7 DEV - Product Summary'] = (stage_summary_styler['v7']['summary'], "NAME")
            v7_prod_summary = pd.DataFrame(v7_data.get('v7 DEV - Product Summary')) if 'v7 DEV - Product Summary' in v7_data.keys() else None
            if isinstance(v7_prod_summary, pd.DataFrame) and not is_effectively_empty(v7_prod_summary):
                unique_product_set.update(v7_prod_summary['NAME'].unique())

            Missing_data['v7_Grade'].save_to_excel(writer, sheet_name='v7 DEV - Product Grade')
            styler_dict['v7 DEV - Product Grade'] = (Missing_data['v7_Grade'], "PRODUCT")
            v7_prod_grade = pd.DataFrame(v7_data.get('v7 DEV - Product Grade')) if 'v7 DEV - Product Grade' in v7_data.keys() else None
            if isinstance(v7_prod_grade, pd.DataFrame) and not is_effectively_empty(v7_prod_grade):
                unique_product_set.update(v7_prod_grade['PRODUCT'].unique())
                
            stage_summary_styler['v7']['stage'].save_to_excel(writer, sheet_name='v7 DEV - Product Grade Stage')
            styler_dict['v7 DEV - Product Grade Stage'] = (stage_summary_styler['v7']['stage'], "PRODUCT")
            v7_prod_stage = pd.DataFrame(v7_data.get('v7 DEV - Product Grade Stage')) if 'v7 DEV - Product Grade Stage' in v7_data.keys() else None
            if isinstance(v7_prod_stage, pd.DataFrame) and not is_effectively_empty(v7_prod_stage):
                unique_product_set.update(v7_prod_stage['PRODUCT'].unique())

            spec_styler['v7']['spec'].save_to_excel(writer, sheet_name='v7 DEV - Product Specification')
            styler_dict['v7 DEV - Product Specification'] = (spec_styler['v7']['spec'], "PRODUCT")
            v7_prod_stage = pd.DataFrame(v7_data.get('v7 DEV - Product Specification')) if 'v7 DEV - Product Specification' in v7_data.keys() else None
            if isinstance(v7_prod_stage, pd.DataFrame) and not is_effectively_empty(v7_prod_stage):
                unique_product_set.update(v7_prod_stage['PRODUCT'].unique())

            if Missing_data['v7_comp_ETDF'] is not None:
                Missing_data['v7_compound_ETDF'].save_to_excel(writer, sheet_name='v7 DEV - ETD_F Product Compds')
                comp_styler['v7']['Compds_ETDF'].save_to_excel(writer, sheet_name='v7 DEV - ETD_F Prdt Cmpds Item')
                styler_dict['v7 DEV - ETD_F Product Compds'] = (Missing_data['v7_compound_ETDF'], "PRODUCT")
                styler_dict['v7 DEV - ETD_F Prdt Cmpds Item'] = (comp_styler['v7']['Compds_ETDF'], "PRODUCT")
                v7_prod_etdf = pd.DataFrame(v7_data.get('v7 DEV - ETD_F Prdt Cmpds Item')) if 'v7 DEV - ETD_F Prdt Cmpds Item' in v7_data.keys() else None
                if isinstance(v7_prod_etdf, pd.DataFrame) and not is_effectively_empty(v7_prod_etdf):
                    unique_product_set.update(v7_prod_etdf['PRODUCT'].unique())

            if Missing_data['v7_comp_ETDN'] is not None:
                Missing_data['v7_compound_ETDN'].save_to_excel(writer, sheet_name='v7 DEV - ETD_N Product Compds')
                comp_styler['v7']['Compds_ETDN'].save_to_excel(writer, sheet_name='v7 DEV - ETD_N Prdt Cmpds Item')
                styler_dict['v7 DEV - ETD_N Product Compds'] = (Missing_data['v7_compound_ETDN'], "PRODUCT")
                styler_dict['v7 DEV - ETD_N Prdt Cmpds Item'] = (comp_styler['v7']['Compds_ETDN'], "PRODUCT")
                v7_prod_etdn = pd.DataFrame(v7_data.get('v7 DEV - ETD_N Prdt Cmpds Item')) if 'v7 DEV - ETD_N Prdt Cmpds Item' in v7_data.keys() else None
                if isinstance(v7_prod_etdn, pd.DataFrame) and not is_effectively_empty(v7_prod_etdn):
                    unique_product_set.update(v7_prod_etdn['PRODUCT'].unique())

            if Missing_data['v7_comp_ETDS'] is not None:
                Missing_data['v7_compound_ETDS'].save_to_excel(writer, sheet_name='v7 DEV - ETD_S Product Compds')
                comp_styler['v7']['Compds_ETDS'].save_to_excel(writer, sheet_name='v7 DEV - ETD_S Prdt Cmpds Item')
                styler_dict['v7 DEV - ETD_S Product Compds'] = (Missing_data['v7_compound_ETDS'], "PRODUCT")
                styler_dict['v7 DEV - ETD_S Prdt Cmpds Item'] = (comp_styler['v7']['Compds_ETDS'], "PRODUCT")
                v7_prod_etds = pd.DataFrame(v7_data.get('v7 DEV - ETD_S Prdt Cmpds Item')) if 'v7 DEV - ETD_S Prdt Cmpds Item' in v7_data.keys() else None
                if isinstance(v7_prod_etds, pd.DataFrame) and not is_effectively_empty(v7_prod_etds):
                    unique_product_set.update(v7_prod_etds['PRODUCT'].unique())
    
        # Convert the set to a list for final output
        unique_products = list(unique_product_set)
        # Use the unique item codes to filter across the three sheets and save to Excel
        output_filename = Util.filter_items(unique_products, styler_dict,output_file='Rerun_Product_Highlighted_V7_DEV.xlsx')
    
    # Instead of sending the file directly, return the download URL
    return jsonify({'download_url': '/download_file?path=' + output_filename})
def process_files1(source_path, item_list):
    # Process the source file
    excel_file = StyledExcelFile1(source_path)
    excel_file.filter_items(
        filter_values=item_list,
        output_filename="filtered_output.xlsx",
        foreign_key_column="NAME"
    )
app.config['UPLOAD_FOLDER'] = 'uploads/'
app.config['ALLOWED_EXTENSIONS'] = {'xlsx'}

def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']
@app.route('/filters')
def index():
    # Fetch current username from the session
    current_user = session.get('username')
    user_status = session.get('status')

    if not current_user:
        return redirect(url_for('login'))  # Redirect to login if no username is found
    return render_template('filter_items.html', username=current_user,status=user_status)
from werkzeug.utils import secure_filename
from BotLib.filter_items import StyledExcelFile1
@app.route('/upload', methods=['POST'])
def upload_files():
    if 'source_file' not in request.files or 'duplicate_file' not in request.files:
        return "Missing files", 400
    
    source_file = request.files['source_file']
    duplicate_file = request.files['duplicate_file']

    if source_file.filename == '' or duplicate_file.filename == '':
        return "Empty file names", 400

    if source_file and allowed_file(source_file.filename) and duplicate_file and allowed_file(duplicate_file.filename):
        source_filename = secure_filename(source_file.filename)
        duplicate_filename = secure_filename(duplicate_file.filename)

        source_filepath = os.path.join(app.config['UPLOAD_FOLDER'], source_filename)
        duplicate_filepath = os.path.join(app.config['UPLOAD_FOLDER'], duplicate_filename)

        source_file.save(source_filepath)
        duplicate_file.save(duplicate_filepath)

        # Process the files (Ensure this function returns the processed file path)
        output_filepath = process_files(source_filepath, duplicate_filepath)

        # Send the processed file to the browser
        return send_file(output_filepath, as_attachment=True)

    return "Invalid file format", 400

def process_files(source_path, duplicate_path):
    # Read the duplicate file to get the filter values
    duplicate_file = pd.ExcelFile(duplicate_path)
    item_file = pd.read_excel(duplicate_file, sheet_name=None, keep_default_na=False)
    item_file = item_file[list(item_file.keys())[0]].astype(str)
    filter_values = item_file["NAME"].tolist()
    output_filename="filtered_output.xlsx"
    # Process the source file
    excel_file = StyledExcelFile1(source_path)
    excel_file.filter_items(
        filter_values=filter_values,
        output_filename=output_filename,
        # foreign_key_column="NAME"
    )
    return output_filename

@app.route('/download_file')
def download_files():
    # Get the file path from the request
    file_path = request.args.get('path')

    # Ensure the file exists before serving it
    if os.path.exists(file_path):
        return send_file(file_path, as_attachment=True)

@app.route('/product_submit', methods=['GET', 'POST'])  # product interface
def product_submit():
    # Retrieve the uploaded V6 Excel file
    file1 = request.files.get('file1')
    file2 = request.files.get('file2')
    file3 = request.files.get('file3')
    if file1 and file2 and file3:
        v6_file = pd.ExcelFile(file1)
        v7_file = pd.ExcelFile(file2)
        IC_file = pd.ExcelFile(file3)
        if v6_file is not None and v7_file is not None and IC_file is not None:
            stage_summary_styler, spec_styler, comp_styler, prefix, Missing_data = Prod.process_Product_files(v6_file,v7_file,IC_file)

            output_filename = os.path.join('uploads', prefix+'PRODUCT_Highlighted_V7_DEV.xlsx')
            with pd.ExcelWriter(output_filename, engine='openpyxl') as writer:
                stage_summary_styler['v7']['summary'].save_to_excel(writer, sheet_name='v7 DEV - Product Summary')
                Missing_data['v7_Grade'].save_to_excel(writer, sheet_name='v7 DEV - Product Grade')
                stage_summary_styler['v7']['stage'].save_to_excel(writer, sheet_name='v7 DEV - Product Grade Stage')
                spec_styler['v7']['spec'].save_to_excel(writer, sheet_name='v7 DEV - Product Specification')
                if Missing_data['v7_comp_ETDF'] is not None:
                    Missing_data['v7_compound_ETDF'].save_to_excel(writer, sheet_name='v7 DEV - ETD_F Product Compds')
                    comp_styler['v7']['Compds_ETDF'].save_to_excel(writer, sheet_name='v7 DEV - ETD_F Prdt Cmpds Item')
                    
                if Missing_data['v7_comp_ETDN'] is not None:
                    Missing_data['v7_compound_ETDN'].save_to_excel(writer, sheet_name='v7 DEV - ETD_N Product Compds')
                    comp_styler['v7']['Compds_ETDN'].save_to_excel(writer, sheet_name='v7 DEV - ETD_N Prdt Cmpds Item')
                    
                if Missing_data['v7_comp_ETDS'] is not None:
                    Missing_data['v7_compound_ETDS'].save_to_excel(writer, sheet_name='v7 DEV - ETD_S Product Compds')
                    comp_styler['v7']['Compds_ETDS'].save_to_excel(writer, sheet_name='v7 DEV - ETD_S Prdt Cmpds Item')
                    
            output_filename1 = os.path.join('uploads',prefix+'PRODUCT_Highlighted_V6_PROD.xlsx')
            with pd.ExcelWriter(output_filename1, engine='openpyxl') as writer:
                stage_summary_styler['v6']['summary'].save_to_excel(writer, sheet_name='v6 PROD - Product Summary')
                Missing_data['v6_grade'].save_to_excel(writer, sheet_name='v6 PROD - Product Grade')
                stage_summary_styler['v6']['stage'].save_to_excel(writer, sheet_name='v6 PROD - Product Grade Stage')
                spec_styler['v6']['spec'].save_to_excel(writer, sheet_name='v6 PROD - Product Specification')
                if Missing_data['v6_comp'] is not None:
                    comp_styler['v6']['Compds'].save_to_excel(writer, sheet_name='v6 PROD - IC Dimensions')
            # Save individual Excel files and zip them
            zip_file_path = Util.create_zip_file([output_filename,output_filename1],zip_filename=prefix+'PRODUCT_Highlighted_files.zip',remove_files=False)
            return jsonify({"message": "Files are ready for download.", "download_url": '/download_file?path=' + zip_file_path})

        else:
            return jsonify({"error": "Invalid combination type."}), 400


from BotLib.excel_op import CreateXML
# In-memory storage for uploaded Excel workbooks
uploaded_workbooks = {}

def read_excel_and_create_classes(file_path,xml_template_path,level):
    # Load the XML template
    xml_template = Util.load_xml_template(xml_template_path)

    # Read the Excel file with all sheets
    xls = pd.ExcelFile(file_path)
    sheets = xls.sheet_names

    # Dictionary to store class instances for each NAME or T_PH_ITEM_CODE
    name_classes = {}

    # Iterate over each sheet
    for s, sheet in enumerate(sheets):
        df = pd.read_excel(file_path, sheet_name=sheet)
        if level == 'ItemCode':
            # Handle the first sheet with 'NAME' column and others with 'T_PH_ITEM_CODE'
            foreign_key_column = 'NAME' if sheet == 'IC v7 summary' else 'T_PH_ITEM_CODE'
        else:
            foreign_key_column = 'NAME' if sheet == 'v7 DEV - Product Summary' else 'PRODUCT'

        # Ensure the foreign key column exists in the sheet
        if foreign_key_column not in df.columns:
            continue

        # Iterate over each row in the sheet
        for _, row in df.iterrows():
            foreign_key_value = row[foreign_key_column]

            # If this foreign key doesn't have a class yet, create it
            if foreign_key_value not in name_classes:
                name_classes[foreign_key_value] = CreateXML(foreign_key_value, xml_template,level)

            # Prepare the row data (including foreign key for each sheet)
            row_data = row.to_dict()

            # Add the data to the respective class instance
            name_classes[foreign_key_value].add_data(sheet, row_data)

    return name_classes

@app.route('/convert', methods=['POST']) #convert excel to xml
def convert():
    # try:
    data = request.get_json()
    uploaded_file_name = data.get('filename')
    level = data.get('level')
    if not uploaded_file_name:
        return jsonify({"error": "No file name provided."}), 400

    excel_file_path = os.path.join('uploads', uploaded_file_name)
    if level == 'ItemCode':
        xml_template_path = "reference files\\XML_Template_ItemCode.xml"
        conformance_check_file = "reference files\\ItemCode XML Schema.xlsx"
    else:
        xml_template_path = "reference files\\Product XML Template.xml"
        conformance_check_file = "reference files\\Product - XML Schema.xlsx"
    output_directory = 'uploads'

    if not os.path.exists(excel_file_path):
        return jsonify({"error": "Excel file not found."}), 404
    
    # Process Excel and generate XML files
    name_classes = read_excel_and_create_classes(excel_file_path,xml_template_path,level)

    # Create ZIP for XML files
    zip_file_path = os.path.join(output_directory, 'output_xml_files.zip')
    Util.save_xml_files_as_zip(name_classes, zip_filename=zip_file_path)

    # Process XML files and determine valid/invalid paths
    filenames = process_xml_files(zip_file_path, "uploads",conformance_check_file,level)
    valid_files_path = filenames.get('valid_files', None)
    invalid_files_path = filenames.get('invalid_files', None)
    errors_files_path = filenames.get('errors', None)

    # Create a combined ZIP for all outputs
    combined_zip_path = os.path.join(output_directory, level+'_converted_files.zip')
    with zipfile.ZipFile(combined_zip_path, 'w') as combined_zip:
        if valid_files_path:
            combined_zip.write(valid_files_path, arcname='valid_files.zip')
        if invalid_files_path:
            combined_zip.write(invalid_files_path, arcname='invalid_files.zip')
        if errors_files_path:
            combined_zip.write(errors_files_path, arcname=os.path.basename(errors_files_path))

    # Send the combined ZIP file as a response
    return send_file(
        combined_zip_path,
        as_attachment=True,
        download_name='all_output_files.zip',
        mimetype='application/zip'
    )
    # except Exception as e:
    #     print(str(e))
    #     return jsonify({"error": str(e)}), 500

@app.route('/get-sheet-data', methods=['POST']) #XML CONVERT
def get_sheet_data():
    sheet_name = request.json.get('sheet_name')
    # Get the approval status from the form data
    if 'current' not in uploaded_workbooks:
        return jsonify({'error': 'No file uploaded yet'}), 400

    try:
        wb = uploaded_workbooks['current']
        if sheet_name not in wb.sheetnames:
            return jsonify({'error': 'Invalid sheet name'}), 400

        sheet = wb[sheet_name]
        table_html = Util.sheet_to_html(sheet)

        return jsonify({'table_html': table_html}), 200

    except Exception as e:
        return jsonify({'error': str(e)}), 500
@app.route('/upload-task', methods=['POST'])  #file upload to condvert excel to xml
def upload_task():
    if 'taskFile' not in request.files:
        return jsonify({'error': 'No file uploaded'}), 400

    file = request.files['taskFile']
    
    file_path = os.path.join(UPLOAD_FOLDER, file.filename)

    # Ensure upload directory exists
    if not os.path.exists(UPLOAD_FOLDER):
        os.makedirs(UPLOAD_FOLDER)

    try:
        # Save the file to disk
        file.save(file_path)
        
        # Load workbook and store it
        wb = openpyxl.load_workbook(file_path)
        uploaded_workbooks['current'] = wb
        
        # Get sheet names and generate the dropdown HTML
        sheet_names = wb.sheetnames
        sheet_select_html = '<select id="sheetSelect">'
        for sheet_name in sheet_names:
            sheet_select_html += f'<option value="{sheet_name}">{sheet_name}</option>'
        sheet_select_html += '</select>'
        
        # Convert the first sheet to HTML with the approval status
        blocked_color = False
        first_sheet = wb[sheet_names[0]]
        table_html, blocked_color = Util.sheet_to_html(first_sheet)
        for sheet_name in sheet_names:
            first_sheet = wb[sheet_name]
            _, color = Util.sheet_to_html(first_sheet)
            if color:
                blocked_color = True

        # Return the sheet and table HTML
        return jsonify({
            'sheet_select_html': sheet_select_html,
            'table_html': table_html,
            'filename': file.filename,
            'blocked_color':blocked_color
        }), 200

    except Exception as e:
        print(f"Error processing file: {e}")  # Log the error for debugging
        return jsonify({'error': str(e)}), 500


# @app.route('/xml_convert')
# def second_screen():
#     # Fetch current username from the session
#     current_user = session.get('username')
#     user_status = session.get('status')

#     if not current_user:
#         return redirect(url_for('login'))  # Redirect to login if no username is found
#     return render_template('convert_to_xml.html', username=current_user, status=user_status)

@app.route('/demo')
def demo_screen():
    return render_template('demo_screen1.html')
if __name__ == '__main__':
    # app.run(debug=True)
    app.run(host='192.168.0.14', port=5000,debug=False)

import pandas as pd
import json
import re
import os
from BotLib.excel_op import DataFrameStyler as DStyler

requirements_file = pd.ExcelFile("reference files\\Itemcode_Bot_Instruction.xlsx")

Artikel_Liste = pd.ExcelFile("reference files\\Artikel Liste.xlsx")
Tabelle3 = pd.read_excel(Artikel_Liste, sheet_name="IC Summary page description", keep_default_na=False).astype(str)

MD_Trak = pd.ExcelFile("reference files\\MD Tracker - Products.xlsx")
MD_Traker = pd.read_excel(MD_Trak, sheet_name="MD Tracker - Products", keep_default_na=False)
MD_Traker = MD_Traker.astype(str)

SM_FOR_ETD_S = pd.ExcelFile("reference files\\Item code Sample Plan for ETD_S Prefix products.xlsx")
SM_ETD_S = pd.read_excel(SM_FOR_ETD_S, sheet_name="Sample Plan for IC", keep_default_na=False).astype(str)

requirements = {}
if requirements_file is not None:
    requirements = pd.read_excel(requirements_file, sheet_name=None, keep_default_na=False)
    IC_summary_req = requirements[list(requirements.keys())[0]]
    summary_columns = IC_summary_req.loc[IC_summary_req['Comments'] != 'Comparison not required', 'Column Name'].tolist()
    IC_specification_req = requirements[list(requirements.keys())[1]]
    specification_columns = IC_specification_req.loc[IC_specification_req['Comments'] != 'Comparison not required', 'Column Name'].tolist()
    IC_supplier_req = requirements[list(requirements.keys())[2]]
    supplier_columns = IC_supplier_req.loc[IC_supplier_req['Comments'] != 'Comparison not required', 'Column Name'].tolist()

def get_v6_value(v7,v6,index_column,index,column):
    item_code_v7 = v7[index_column][index].replace('ETD_', '')
    item_code_v6 = list(v6[index_column].astype(str))
    if item_code_v7 in item_code_v6:
        matched_rows = v6[v6[index_column] == item_code_v7]
        
        return str(matched_rows[column].values[0]),True, matched_rows
    else:
        return item_code_v7,False, ""
def get_prod_spec_value(v7_value,spec_styler,index_column,column):
    item_code_v7 = list(spec_styler.dataframe[index_column].astype(str))
    if v7_value in item_code_v7:
        if 'Corrected PRODUCT_SPEC (GVW)' in spec_styler.dataframe.columns: 
            corrected_spec = spec_styler.dataframe.loc[spec_styler.dataframe[index_column] == v7_value, 'Corrected PRODUCT_SPEC (GVW)'].values[0]
            if corrected_spec != "":
                return corrected_spec,True
            else:
                return spec_styler.dataframe.loc[spec_styler.dataframe[index_column] == v7_value, column].values[0],True
        else:
            return spec_styler.dataframe.loc[spec_styler.dataframe[index_column] == v7_value, column].values[0],True
    else:
        return v7_value,False

def find_prod_spec_for_Spec_Class(prod_spec):
    # Define the possible values and their corresponding regex patterns
    value_patterns = {
        "UNKNOWN": r'^(ETD_S_R).*',
        "MP": r'^(ETD_F_|ETD_S_|ETD_N_).*',
        "RM": r'^(ETD_R_).*',
        "STAB": r'^(ETD_LABORDER|ETD_NR_).*',
        "INST": r'^(ETD_BALANCE_PERFORM).*'
    }
    # Iterate through the value patterns and check if prod_spec matches any of them
    for value, pattern in value_patterns.items():
        if re.match(pattern, prod_spec):
            return value
    # If no match is found, return None or a default value
    return 'UNKNOWN'
def find_prod_spec_for_SM(prod_spec):
    # Define the possible values and their corresponding regex patterns
    value_patterns = {
        "ETD_FG": r'^(ETD_F).*',
        "ETD_NR_LABORDER": r'^(ETD_NR_LABORDER).*',
        "ETD_N_QANEEDLES": r'^(ETD_N).*',
        "ETD_RM": r'^(ETD_R).*',
        "ETD_STERI": r'^(ETD_STERI).*|ETD_DRYING',
        "ETD_S": r'^(ETD_S).*',        
    }
    # Iterate through the value patterns and check if prod_spec matches any of them
    for value, pattern in value_patterns.items():
        if re.match(pattern, prod_spec):
            return value
    # If no match is found, return None or a default value
    return None
def col_to_col_comparison(v6, v7, styler_df, column,rerun=False,spec=False):
    if spec:
        duplicates  = styler_df.dataframe[styler_df.dataframe.duplicated(subset=[column],keep=False)]
        for index in duplicates.index:
            styler_df.highlight_entire_row(index,"#00B0F0",to_check=True) # for SME Blue
            comment = "v7 IC has Multiple SPEC_CODE , hence the line should be marked in blue for SME verification"
            styler_df.add_comments(index, comment)
    if column in v6.columns:
        v6_data = list(v6[column].astype(str))
        for index, value in v7[column].items():
            if rerun:
                JsonData = v7['JsonData'][index]
                if JsonData == 'Remove':
                    styler_df.highlight_entire_row(index,"#001D58") # for removed itemcode
                    continue
                elif JsonData != "Passed":
                    JsonData = json.loads(JsonData.replace("'", "\""))
                    if JsonData[column] == 'No':
                        styler_df.highlight_entire_row(index,"#92D050") # Light Green
                        continue
                    elif JsonData == 'SME Verification':
                        styler_df.highlight_entire_row(index,"#00B0F0")
                        continue
            if spec:
                if v7[column][index] == "ETD_CPX0405521GS":
                    styler_df.highlight_entire_row(index,"purple")
                    comment = f'The Item Code has multiple Spec Code in v6 PROD. Hence, marked in Purple for MedTech verification.'
                    styler_df.add_comments(index, comment)
                    continue
            color = styler_df.get_cell_color(index, column)
            if color == "":
                if str(value).replace('ETD_', '') in v6_data:
                    styler_df.highlight_cell(index, column,"#92D050") # Light Green
                else:
                    comment = 'Item Code "{}" is not available in v6 PROD.'.format(value)
                    styler_df.add_comments(index, comment)
                    styler_df.highlight_entire_row(index,"#FFFF00") #Standard yellow
def add_manual_columns(file,rerun=False):
    if rerun:
        if 'History of Comments' not in file.columns:
            file['History of Comments'] = file['COMMENTS']
    file['COMMENTS'] = 'Verified - OK'
    file['Verified by'] = ''
    file['Pass/Fail'] = 'N/A'
    return file.astype(str)
def highlight_excess_row(v6,v7,columns,color="#FFFF00",string=""): #Standard yellow
    if not columns:
        raise ValueError("The 'columns' list cannot be empty.")

    # Ensure columns exist in both DataFrames
    if not set(columns).issubset(v6.dataframe.columns) or not set(columns).issubset(v7.columns):
        raise ValueError("One or more specified columns do not exist in both DataFrames.")
    
    # Work with the first column for string manipulation
    primary_column = columns[0]
    # Iterate over rows in v6 and compare with v7
    for index, row in v6.dataframe[columns].iterrows():
        # Replace or append the string during comparison
        if string:
            temp_row = row.copy()
            temp_row[primary_column] = f"{string}{row[primary_column]}"
        else:
            temp_row = row
        # Perform the comparison
        if not any((v7[columns] == temp_row).all(axis=1)):
            # Highlight the entire row if no match is found
            v6.highlight_entire_row(index, color)
    

manual_columns = ['COMMENTS','Verified by','Pass/Fail']
def compare_v6_v7_itemcode(v7_query_summary,v7_query_spec,v7_query_supplier,
                           v6_query_summary,v6_query_spec,v6_query_supplier, rerun=False):
    v7_query_summary = add_manual_columns(v7_query_summary,rerun=rerun)
    summary_styler = DStyler(v7_query_summary,summary_columns+manual_columns)
    v7_query_spec = add_manual_columns(v7_query_spec,rerun=rerun)
    spec_styler = DStyler(v7_query_spec,specification_columns+manual_columns)
    if v7_query_supplier is not None:
        v7_query_supplier = add_manual_columns(v7_query_supplier,rerun=rerun)
        sub_styler = DStyler(v7_query_supplier,supplier_columns+manual_columns)
    else:
        sub_styler = None
    
    v6_query_summary = v6_query_summary.astype(str)
    v6_summary_styler = DStyler(v6_query_summary,summary_columns+manual_columns)
    highlight_excess_row(v6_summary_styler,v7_query_summary,["NAME"],color="#FFFF00",string="ETD_") #Standard yellow
    v6_query_spec = v6_query_spec.astype(str)
    v6_spec_styler = DStyler(v6_query_spec,specification_columns+manual_columns)
    highlight_excess_row(v6_spec_styler,v7_query_spec,["T_PH_ITEM_CODE"],color="#FFFF00",string="ETD_") #Standard yellow
    if v6_query_supplier is not None and len(v6_query_spec) >0:
        v6_query_supplier = v6_query_supplier.astype(str)
        v6_sub_styler = DStyler(v6_query_supplier,supplier_columns+manual_columns)
        highlight_excess_row(v6_sub_styler,v7_query_supplier,["T_PH_ITEM_CODE"],color="#FFFF00",string="ETD_") #Standard yellow
    else:
        v6_sub_styler = None
    #================================================================= Specification =================================================================================
    # Iterate over the columns in v7_query
    for column in v7_query_spec.columns: # iterating
        if column in specification_columns and column not in manual_columns:
            if not pd.isna(IC_specification_req.loc[IC_specification_req['Column Name'] == column, 'Bot Instructions'].values[0]):
                instructions = json.loads(IC_specification_req.loc[IC_specification_req['Column Name'] == column, 'Bot Instructions'].values[0])
                # print(instructions)
                if instructions['Type'] == 'column to column':
                    if column == "T_PH_ITEM_CODE":
                        col_to_col_comparison(v6_query_spec,v7_query_spec,spec_styler,column,rerun=rerun,spec=True)
                    elif instructions['Note'] == "":
                        if column in v6_query_spec.columns:
                            v6_data = list(v6_query_spec[column].astype(str))
                            index_column = 'T_PH_ITEM_CODE'
                            item_code_v6 = list(v6_query_spec[index_column].astype(str))
                            for index, value in v7_query_spec[column].items():
                                color = spec_styler.get_cell_color(index, column)
                                if color == "":
                                    if rerun:
                                        JsonData = v7_query_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if JsonData[column] == 'Manual Correction':
                                                spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                            elif JsonData[column] == 'SME Verification':
                                                spec_styler.highlight_cell(index, column,"#00B0F0") #SME blue
                                                comment = f'Unsure of the correct {column}. Hence marked in blue for SME Verification.'
                                                spec_styler.add_comments( index, comment)
                                                continue
                                            elif JsonData[column] == "No":
                                                spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                    item_code_v7 = v7_query_spec[index_column][index].replace('ETD_', '')
                                    if item_code_v7 in item_code_v6:
                                        if str(value) in v6_data:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        else:
                                            v6_value = v6_query_spec.loc[v6_query_spec[index_column] == item_code_v7, column].values[0]
                                            spec_styler.highlight_cell(index, column,"red")
                                            comment = 'The SPEC_CODE is "{}" in v7 DEV. It should be "{}" as per v6 PROD.'.format(value,v6_value)
                                            spec_styler.add_comments( index, comment)
                                    else:
                                        spec_styler.highlight_cell(index, column,"red")
                                        # comment = 'Item Code "{}" is not available in v6 PROD.'.format(value)
                                        # spec_styler.add_comments( index, comment)
                                        pass
                    
                elif instructions['Type'] == 'column to others':
                    if column == "PRODUCT_SPEC":
                        if "Corrected PRODUCT_SPEC (GVW)" not in spec_styler.dataframe.columns:
                            spec_styler.add_column('Corrected PRODUCT_SPEC (GVW)', "", after_column_name='PRODUCT_SPEC')
                        else:
                            spec_styler.columns_to_show.append('Corrected PRODUCT_SPEC (GVW)')
                        for index, value in v7_query_spec[column].items():
                            color = spec_styler.get_cell_color(index, column)
                            if color == "":
                                if rerun:
                                    JsonData = v7_query_spec['JsonData'][index]
                                    if JsonData == 'Remove':
                                        spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                    elif JsonData != "Passed":
                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                        if JsonData['SPEC_CLASS'] == 'SME Verification':
                                            spec_styler.highlight_cell(index, 'SPEC_CLASS',"#00B0F0") #SME blue
                                            comment = 'Unsure of the correct SPEC_CLASS. Hence marked in blue for SME Verification.'
                                            spec_styler.add_comments( index, comment)
                                        elif JsonData['SPEC_CLASS'] == 'No': 
                                            spec_styler.highlight_cell(index, 'SPEC_CLASS',"#92D050") # Light Green   
                                        elif JsonData['SPEC_CLASS'] == 'Manual Correction':
                                            spec_styler.highlight_cell(index, 'SPEC_CLASS',"#92D050") # Light Green

                                        if JsonData['GRADE'] == 'SME Verification':
                                            spec_styler.highlight_cell(index, 'GRADE',"#00B0F0") #SME blue
                                            comment = 'Unsure of the correct GRADE. Hence marked in blue for SME Verification.'
                                            spec_styler.add_comments( index, comment)
                                        elif JsonData['GRADE'] == 'No': 
                                            spec_styler.highlight_cell(index, 'GRADE',"#92D050") # Light Green   
                                        elif JsonData['GRADE'] == 'Manual Correction':
                                            spec_styler.highlight_cell(index, 'GRADE',"#92D050") # Light Green
                                        
                                        if JsonData[column] == 'Manual Correction':
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                        elif JsonData[column] == 'SME Verification':
                                            spec_styler.highlight_cell(index, column,"#00B0F0") #SME blue
                                            comment = 'Unsure of the correct {column}. Hence marked in blue for SME Verification.'
                                            spec_styler.add_comments( index, comment)
                                            continue
                                        elif JsonData[column] == 'No':
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                item = v7_query_spec[instructions['Column_Included']['v7'][0]][index].replace('ETD_', '')
                                # print(instructions,len(v6_query_spec), item)
                                v6_row = v6_query_spec[v6_query_spec[instructions['Column_Included']['v6'][0]]== item]
                                
                                v6_prod_spec = v6_row[instructions['Column_Included']['v6'][1]].values[0]
                                v6_grade = v6_row[instructions['Column_Included']['v6'][2]].values[0]
                                
                                filtered_df = MD_Traker[(MD_Traker[instructions['Column_Included']['MD Tracker'][0]] == v6_prod_spec) & (MD_Traker[instructions['Column_Included']['MD Tracker'][1]] == v6_grade)]
                                def Grade_Check(filtered_df,v7_Grade,spec_styler,index):
                                    MD_v7_Grade = filtered_df['v7 Grades'].values[0]
                                    if v7_Grade == MD_v7_Grade: # for Grade
                                        spec_styler.highlight_cell(index, 'GRADE',"#92D050") # Light Green
                                    else:
                                        spec_styler.highlight_cell(index, 'GRADE',"red")
                                        comment = 'The GRADE is "{}" in v7 DEV. It should be "{}" as per Product MD Tracker.'.format(v7_Grade,MD_v7_Grade)
                                        spec_styler.add_comments(index, comment)
                                def Spec_Class_Check(v7_query_spec,MD_Prod_Spec,spec_styler,index):
                                    v7_spec_class = v7_query_spec['SPEC_CLASS'][index]
                                    matched_spec_class = find_prod_spec_for_Spec_Class(MD_Prod_Spec)
                                    if v7_spec_class == matched_spec_class:  # for spec_class
                                        spec_styler.highlight_cell(index, 'SPEC_CLASS', "#92D050")  # Light Green
                                    elif matched_spec_class == 'UNKNOWN':
                                        spec_styler.highlight_cell(index, 'SPEC_CLASS', "purple")
                                        comment = f'The SPEC_CLASS is "{value}" in v7 DEV. The Product "{value}" prefix is not defined in the MD Protocol. Hence, unsure of the Spec class.'
                                        spec_styler.add_comments( index, comment)
                                    else:
                                        spec_styler.highlight_cell(index, column, "red")
                                        comment = f'The SPEC_CLASS is "{value}" in v7 DEV. It should be "{matched_spec_class}" as per MD Protocol.'
                                        spec_styler.add_comments( index, comment)
                                if len(filtered_df)>1:
                                    comment = f'The PRODUCT_SPEC is "{value}" in v7 DEV. It\'s corresponding v6 product spec "{v6_prod_spec}" and Grade "{v6_grade}" has multiple product linked as per MD Tracker.'
                                    spec_styler.add_comments(index, comment)
                                    spec_styler.highlight_cell(index, column,"purple")
                                    comment = f'The SPEC_CLASS field is highlighted in Purple as we are unsure of the correct PRODUCT SPEC.'
                                    spec_styler.add_comments( index, comment)
                                    spec_styler.highlight_cell(index, 'SPEC_CLASS',"purple")
                                    comment = f'The GRADE field is highlighted in Purple as we are unsure of the correct PRODUCT SPEC.'
                                    spec_styler.add_comments( index, comment)
                                    spec_styler.highlight_cell(index, 'GRADE',"purple")
                                elif not filtered_df.empty:
                                    MD_Prod_Spec = filtered_df[instructions['Column_Included']['MD Tracker'][2]].values[0]
                                    MD_Prod_Spec_comment = filtered_df['Comments'].values[0]
                                    v7_Grade = v7_query_spec['GRADE'][index]
                                    
                                    if MD_Prod_Spec_comment != "":
                                        if MD_Prod_Spec_comment.lower() == "mark the product in purple":
                                            spec_styler.highlight_cell(index, column,"purple")
                                            comment = f'The PRODUCT_SPEC is "{value}" in v7 DEV. It\'s corresponding v6 product spec "{v6_prod_spec}" and Grade "{v6_grade}" has multiple product linked as per MD Tracker.'
                                            spec_styler.add_comments( index, comment)
                                            spec_styler.highlight_cell(index, 'GRADE',"purple")
                                            comment = f'The GRADE field is highlighted in Purple as we are unsure of the correct PRODUCT SPEC'
                                            spec_styler.add_comments( index, comment)
                                            comment = f'The SPEC_CLASS field is highlighted in Purple as we are unsure of the correct PRODUCT SPEC'
                                            spec_styler.highlight_cell(index, 'SPEC_CLASS', "purple")
                                            spec_styler.add_comments( index, comment) 
                                        else:
                                            spec_styler.highlight_entire_row(index,"#00B0F0") # SME blue
                                            comment = MD_Prod_Spec_comment.replace('"PRODUCT_SPEC"', f'"{value}"').replace('"Grade"', f'"{v7_Grade}"')
                                            spec_styler.add_comments( index, comment)
                                    else:
                                        #======================================= GRADE ===============================
                                        Grade_Check(filtered_df,v7_Grade,spec_styler,index)
                                        #======================================= SPEC_CLASS ===============================
                                        Spec_Class_Check(v7_query_spec,MD_Prod_Spec,spec_styler,index)
                                        #======================================= PRODUCT_SPEC ===============================
                                        if value == MD_Prod_Spec:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        else:
                                            spec_styler.update_cell(row_index=index, col_name='Corrected PRODUCT_SPEC (GVW)', value=MD_Prod_Spec)                                            
                                            spec_styler.highlight_cell(index, column,"purple")
                                            # spec_styler.highlight_cell(index, 'GRADE',"purple")
                                            if pd.isna(MD_Prod_Spec):
                                                MD_Prod_Spec = ""
                                            comment = 'The PRODUCT_SPEC is "{}" in v7 DEV. It should be "{}" as per the combination of product spec and Grade in v6 PROD.'.format(value,MD_Prod_Spec)
                                            spec_styler.add_comments(index, comment)
                                else:
                                    filtered_df = MD_Traker[(MD_Traker['v7 Product entry code'] == value)]
                                    if not filtered_df.empty:
                                        MD_Prod_Spec_comment = filtered_df['Comments'].values[0]
                                        v7_Grade = v7_query_spec['GRADE'][index]
                                        
                                        if MD_Prod_Spec_comment != "":
                                            if MD_Prod_Spec_comment.lower() == "mark the product in purple":
                                                spec_styler.highlight_cell(index, column,"purple")
                                                comment = f'The PRODUCT_SPEC is "{value}" in v7 DEV. It\'s corresponding v6 product spec "{v6_prod_spec}" and Grade "{v6_grade}" has multiple product linked as per MD Tracker.'
                                                spec_styler.add_comments( index, comment)
                                                spec_styler.highlight_cell(index, 'GRADE',"purple")
                                                comment = f'The GRADE field is highlighted in Purple as we are unsure of the correct PRODUCT SPEC'
                                                spec_styler.add_comments( index, comment)
                                                comment = f'The SPEC_CLASS field is highlighted in Purple as we are unsure of the correct PRODUCT SPEC'
                                                spec_styler.highlight_cell(index, 'SPEC_CLASS', "purple")
                                                spec_styler.add_comments( index, comment) 
                                                
                                            else:
                                                spec_styler.highlight_entire_row(index,"#00B0F0") # SME blue
                                                comment = MD_Prod_Spec_comment.replace('"PRODUCT_SPEC"', f'"{value}"').replace('"Grade"', f'"{v7_Grade}"')
                                                spec_styler.add_comments( index, comment)
                                        else:
                                            comment = 'The PRODUCT_SPEC is "{}" in v7 DEV. It\'s corresponding v6 product spec "{}" and Grade "{}" is not available in MD Tracker.'.format(value,v6_prod_spec,v6_grade)
                                            spec_styler.add_comments(index, comment)
                                            spec_styler.highlight_cell(index, column,"purple")
                                            spec_styler.highlight_cell(index, 'GRADE',"purple")
                                            spec_styler.highlight_cell(index, 'SPEC_CLASS', "purple")
                                                
                                    else:
                                        comment = 'The PRODUCT_SPEC is "{}" in v7 DEV. It\'s corresponding v6 product spec "{}" and Grade "{}" is not available in MD Tracker.'.format(value,v6_prod_spec,v6_grade)
                                        spec_styler.add_comments(index, comment)
                                        spec_styler.highlight_cell(index, column,"purple")
                                        spec_styler.highlight_cell(index, 'GRADE',"purple")
                                        spec_styler.highlight_cell(index, 'SPEC_CLASS', "purple")                                
                
                else:
                    pass
    v7_query_spec = spec_styler.duplicate_column('Corrected PRODUCT_SPEC (GVW)',v7_query_spec)

# =========================================================================== summary =========================================================================
    # Iterate over the columns in v7_query
    for column in v7_query_summary.columns: # iterating
        if column in summary_columns and column not in manual_columns:
            if not pd.isna(IC_summary_req.loc[IC_summary_req['Column Name'] == column, 'Bot Instructions'].values[0]):
                instructions = json.loads(IC_summary_req.loc[IC_summary_req['Column Name'] == column, 'Bot Instructions'].values[0])
                # print(instructions)
                if instructions['Type'] == 'column to column':
                    if column == 'NAME':
                        col_to_col_comparison(v6_query_summary,v7_query_summary,summary_styler,column,rerun=rerun)
                elif instructions['Type'] == 'column to others':
                    if column == "DESCRIPTION":
                        # pass
                        #print(instructions['Column_Included'])
                        AL_index = list(Tabelle3[instructions['Column_Included']['Artikel Liste'][0]].astype(str))
                        for index, value in v7_query_summary[column].items():
                            color = summary_styler.get_cell_color(index, column)
                            if color == "":
                                if rerun:
                                    JsonData = v7_query_summary['JsonData'][index]
                                    if JsonData == 'Remove':
                                        summary_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                    elif JsonData != "Passed":
                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                        if JsonData[column] == 'Manual Correction':
                                            summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                        elif JsonData[column] == 'SME Verification':
                                            summary_styler.highlight_cell(index, column,"#00B0F0")
                                            comment = f'Unsure of the correct {column}. Hence marked in blue for SME Verification.'
                                            summary_styler.add_comments( index, comment)
                                            continue
                                        elif JsonData[column] == "No":
                                            summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                item = v7_query_summary[instructions['Column_Included']['v7'][0]][index].replace('ETD_', '')
                                
                                if item in AL_index:
                                    df = Tabelle3[Tabelle3[instructions['Column_Included']['Artikel Liste'][0]]== str(item)]
                                    df.columns = df.columns.str.lower()
                                    AL_desc = df[instructions['Column_Included']['Artikel Liste'][1].lower()].values[0]
                                    if AL_desc == value:
                                        summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    else:
                                        summary_styler.highlight_cell(index, column,"red")
                                        comment = 'The DESCRIPTION is "{}" in v7 DEV. It should be "{}" as per Artikel Liste file.'.format(value,AL_desc)
                                        summary_styler.add_comments( index, comment)
                                else:
                                    summary_styler.highlight_cell(index, column,"purple")
                                    comment = 'The Itemcode "ETD_{}" is not available  in Artikel Liste file.'.format(item)
                                    # summary_styler.add_comments( index, comment)
                                    index_column = 'NAME'
                                    v6_value,IC,v6_rows = get_v6_value(v7_query_summary,v6_query_summary,index_column,index,column)
                                    if IC:
                                        if v6_value == value:
                                            summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        else:
                                            summary_styler.highlight_cell(index, column,"red")
                                            comment = f'The Itemcode "ETD_{item}" is not available in Artikel Liste file. The DESCRIPTION is "{value}" in v7 DEV. It should be "{v6_value}" as per v6 PROD.'
                                            summary_styler.add_comments( index, comment)
                                    else:
                                        summary_styler.highlight_cell(index, column,"purple")
                                        comment = f'The Itemcode "ETD_{item}" is not available in Artikel Liste file. The DESCRIPTION is "{value}" in v7 DEV and not available in v6 PROD.'
                                        summary_styler.add_comments( index, comment)
                    if column == "SAMPLE_PLAN":
                        index_column = 'T_PH_ITEM_CODE'
                        exception_IC = ['ETD_7006418','ETD_7006448','ETD_4501658','ETD_4511658']
                        for index, value in v7_query_summary[column].items():
                            color = summary_styler.get_cell_color(index, column)
                            if color == "":
                                if rerun:
                                        JsonData = v7_query_summary['JsonData'][index]
                                        if JsonData == 'Remove':
                                            summary_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if JsonData[column] == 'Manual Correction':
                                                summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                            elif JsonData[column] == 'SME Verification':
                                                summary_styler.highlight_cell(index, column,"#00B0F0") #SME blue
                                                comment = f'Unsure of the correct {column}. Hence marked in blue for SME Verification.'
                                                summary_styler.add_comments( index, comment)
                                                continue
                                            elif JsonData[column] == "No":
                                                summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                itemcode = v7_query_summary['NAME'][index]
                                prod_spec,IC = get_prod_spec_value(itemcode,spec_styler,index_column,'PRODUCT_SPEC')
                                if itemcode in exception_IC:
                                    if value == 'ETD_FGIP':
                                        summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    else:
                                        summary_styler.highlight_cell(index, column,"red")
                                        comment = 'The SAMPLE_PLAN is "{}" in v7 DEV. It should be "ETD_FGIP" (The Product linked in v7 DEV is "{}") as per MD Protocol.'.format(value,prod_spec)
                                        summary_styler.add_comments( index, comment) 
                                else:
                                    if IC:
                                        SM_from_spec = find_prod_spec_for_SM(prod_spec)
                                        if SM_from_spec:
                                            if SM_from_spec == 'ETD_S':
                                                filtered_values = SM_ETD_S.loc[SM_ETD_S['T_PH_ITEM_CODE'] == itemcode, 'PRODUCT_SPEC'].tolist()
                                                prod_spec_S = filtered_values[0] if filtered_values else None  # Use None or a default value

                                                # prod_spec_S = SM_ETD_S.loc[SM_ETD_S['T_PH_ITEM_CODE'] == itemcode, 'PRODUCT_SPEC'].values[0]
                                                if prod_spec_S == prod_spec:
                                                    S_SM = SM_ETD_S.loc[SM_ETD_S['T_PH_ITEM_CODE'] == itemcode, 'SAMPLE_PLAN'].values[0]
                                                    if value == S_SM:
                                                        summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    else:
                                                      summary_styler.highlight_cell(index, column,"red")
                                                      comment = 'The SAMPLE_PLAN is "{}" in v7 DEV. It should be "{}" (The Product linked in v7 DEV is "{}") as per MD Protocol.'.format(value,S_SM,prod_spec)
                                                      summary_styler.add_comments( index, comment) 
                                                else:
                                                    summary_styler.highlight_cell(index, column,"purple")
                                                    comment = 'For SAMPLE_PLAN "{}" produc spec "{}" is not equal to "{}" in item code "{}" is not available is v7 specification'.format(value,prod_spec,prod_spec_S,itemcode)
                                                    summary_styler.add_comments( index, comment)                                                    
                                            elif SM_from_spec == 'ETD_RM':
                                                if value == 'ETD_CIA':
                                                    summary_styler.highlight_cell(index, column,"purple")
                                                    comment = 'The SAMPLE_PLAN to be verified against the Product type, thus highlighted in purple.'
                                                    summary_styler.add_comments( index, comment)
                                                elif value == 'ETD_RM':
                                                    summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                else:
                                                  summary_styler.highlight_cell(index, column,"red")
                                                  comment = 'The SAMPLE_PLAN is "{}" in v7 DEV. It should be "{}" (The Product linked in v7 DEV is "{}") as per MD Protocol.'.format(value,SM_from_spec,prod_spec)
                                                  summary_styler.add_comments( index, comment) 
                                            else:
                                                if SM_from_spec == value:
                                                    summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                else:
                                                    summary_styler.highlight_cell(index, column,"red")
                                                    comment = 'The SAMPLE_PLAN is "{}" in v7 DEV. It should be "{}" (The Product linked in v7 DEV is "{}") as per MD Protocol.'.format(value,SM_from_spec,prod_spec)
                                                    summary_styler.add_comments( index, comment)
                                        else:
                                            summary_styler.highlight_cell(index, column,"purple")
                                            comment = 'For SAMPLE_PLAN unknown product spec "{}" from v7 specification'.format(prod_spec)
                                            summary_styler.add_comments( index, comment)
                                    else:
                                        summary_styler.highlight_cell(index, column,"purple")
                                        comment = 'The SAMPLE_PLANis "{}" in v7 DEV. The Item Code "{}" is not linked to any of the v7 Product in the Item Code Specification. Hence, unsure of the Sample plan.'.format(value,itemcode)
                                        summary_styler.add_comments( index, comment)
                                        pass
                else:
                    pass
            
# ================================================================ Supplier ========================================================================================== 
    if v7_query_supplier is not None and len(v7_query_supplier)>0:
        # Iterate over the columns in v7_query
        for column in v7_query_supplier.columns: # iterating
            if column in supplier_columns and column not in manual_columns:
                if not pd.isna(IC_supplier_req.loc[IC_supplier_req['Column Name'] == column, 'Bot Instructions'].values[0]):
                    instructions = json.loads(IC_supplier_req.loc[IC_supplier_req['Column Name'] == column, 'Bot Instructions'].values[0])
                    # print(instructions)
                    if instructions['Type'] == 'column to column':
                        if column == 'T_PH_ITEM_CODE':
                            col_to_col_comparison(v6_query_supplier,v7_query_supplier,sub_styler,column,rerun=rerun)
                        elif column == 'SUPPLIER':
                            if column in v6_query_supplier.columns:
                                index_column = 'T_PH_ITEM_CODE'
                                for index, value in v7_query_supplier[column].items():
                                    color = sub_styler.get_cell_color(index, column)
                                    if color == "":
                                        if rerun:
                                            JsonData = v7_query_supplier['JsonData'][index]
                                            if JsonData == 'Remove':
                                                sub_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            elif JsonData != "Passed":
                                                JsonData = json.loads(JsonData.replace("'", "\""))
                                                if JsonData[column] == 'Manual Correction':
                                                    sub_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    sub_styler.highlight_cell(index, column,"#00B0F0") #SME blue
                                                    comment = f'Unsure of the correct {column}. Hence marked in blue for SME Verification.'
                                                    sub_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    sub_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        v6_value,IC, v6_rows = get_v6_value(v7_query_supplier,v6_query_supplier,index_column,index,column)
                                        if IC:
                                            v6_suppliers = v6_rows[column].values
                                            if value.replace('ETD_', '') in v6_suppliers:
                                                sub_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            else:
                                                sub_styler.highlight_cell(index, column,"red") # Teal
                                                if len(v6_suppliers) == 1:
                                                    comment = f'The SUPPLIER is "{value}" in v7 DEV. It is "{v6_suppliers[0]}" as per v6 PROD. It should be "ETD_{v6_suppliers[0]}" in v7 DEV."" in v7 DEV.'
                                                else:
                                                    comment = f'The SUPPLIER is "{value}" in v7 DEV. It is "{[s for s in v6_suppliers]}" in v6 PROD. It should be either ({"or".join(v6_suppliers)}) in v7 DEV.'
                                                sub_styler.add_comments(index, comment) 
                                        # else:
                                        #     sub_styler.highlight_entire_row(index,"#66FFFF") # Teal
                                        #     # comment = 'Item Code "{}" is not available in v6 PROD.'.format(v6_value)
                                        #     # add_comments(sub_styler, index, comment)
                    else:
                        pass                

    return {"v7":{'spec':spec_styler,'summary':summary_styler,'supplier':sub_styler},"v6":{'spec':v6_spec_styler,'summary':v6_summary_styler,'supplier':v6_sub_styler}}
def read_itemcode_files(v6_excel,v7_excel,rerun=False):
    v6_sheets = pd.read_excel(v6_excel, sheet_name=None, keep_default_na=False)
    v6_query_summary = v6_sheets['IC v6 summary'].astype(str)
    v6_query_spec = v6_sheets['IC v6 spec'].astype(str)
    v6_query_supplier = v6_sheets['IC v6 supplier'].astype(str) if 'IC v6 supplier' in v6_sheets.keys() else None
    # Load V7 data into pandas DataFrames, keeping empty cells as empty strings
    v7_sheets = pd.read_excel(v7_excel, sheet_name=None, keep_default_na=False)
    v7_query_summary = v7_sheets['IC v7 summary'].astype(str)
    v7_query_spec = v7_sheets['IC v7 spec'].astype(str)
    v7_query_supplier = v7_sheets['IC v7 supplier'].astype(str) if 'IC v7 supplier' in v7_sheets.keys() else None
    # You can now process the data
    stylers = compare_v6_v7_itemcode(v7_query_summary, v7_query_spec, v7_query_supplier,
                                     v6_query_summary, v6_query_spec, v6_query_supplier,rerun=rerun)
    return stylers
if __name__ == '__main__':
    v6_file = pd.ExcelFile("sample files\\ItemCode\\Highlighted_V6_PROD_18-Dec-2024.xlsx")
    v7_file = pd.ExcelFile("sample files\\ItemCode\\Highlighted_V7_DEV_18-Dec-2024.xlsx")            
    if v6_file is not None and v7_file is not None:
        stylers = read_itemcode_files(v6_excel=v6_file,v7_excel=v7_file)
        output_filename = os.path.join('uploads','Highlighted_V7_DEV.xlsx')
        with pd.ExcelWriter(output_filename, engine='openpyxl') as writer:
            stylers['v7']['summary'].save_to_excel(writer, sheet_name='IC v7 summary')
            stylers['v7']['spec'].save_to_excel(writer, sheet_name='IC v7 spec')
            if len(stylers['v7']['supplier'].dataframe)>0:
                stylers['v7']['supplier'].save_to_excel(writer, sheet_name='IC v7 supplier')
        output_filename1 = os.path.join('uploads','Highlighted_V6_PROD.xlsx')
        with pd.ExcelWriter(output_filename1, engine='openpyxl') as writer:
            stylers['v6']['summary'].save_to_excel(writer, sheet_name='IC v6 summary')
            stylers['v6']['spec'].save_to_excel(writer, sheet_name='IC v6 spec')
            if len(stylers['v6']['supplier'].dataframe)>0:
                stylers['v6']['supplier'].save_to_excel(writer, sheet_name='IC v6 supplier')
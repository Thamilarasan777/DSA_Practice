import pandas as pd
import json
import re
import os
import zipfile
import BotLib.prod_util as Util
from BotLib.excel_op import DataFrameStyler as DF_Styler 

requirements_file = pd.ExcelFile("reference files\\Product_Bot_Instruction.xlsx")

Prod_MD_Traker = pd.ExcelFile("reference files\\MD Tracker - Products.xlsx")
Prod_MD_Traker = pd.read_excel(Prod_MD_Traker, sheet_name="MD Tracker - Products", keep_default_na=False)
Prod_MD_Traker = Prod_MD_Traker.astype(str)

Anal_MD_Trak = pd.ExcelFile("reference files\\MD Tracker - Analysis and its components.xlsx")
Analysis_MD_Trak = pd.read_excel(Anal_MD_Trak, sheet_name="Analysis & its Components")

stage_spec_type_comb_file = pd.ExcelFile("reference files\\List of Stage and Spec type combination with respect to Sample Plan.xlsx")
stage_spec_type_comb_file = pd.read_excel(stage_spec_type_comb_file)
Compnd_MD_Trak = Analysis_MD_Trak

Artikel_Liste = pd.ExcelFile("reference files\\Artikel Liste.xlsx")
Tabelle3 = pd.read_excel(Artikel_Liste, sheet_name="IC Summary page description").astype(str)

Units_MD_Trak = pd.ExcelFile("reference files\\MD Tracker - Units.xlsx")
Units_MD_Trak = pd.read_excel(Units_MD_Trak, sheet_name="MD Tracker - Units")

manual_columns = ['COMMENTS','Verified by','Pass/Fail']
requirements = {}
if requirements_file is not None:
    requirements = pd.read_excel(requirements_file, sheet_name=None)
    prod_sum_req = requirements['Summary']
    summary_columns = prod_sum_req.loc[prod_sum_req['Comments'] != 'Do not compare', 'Column Name'].tolist()
    prod_stage_req = requirements['Product Grade Stage']
    prod_stage_columns = prod_stage_req.loc[prod_stage_req['Comments'] != 'Do not compare', 'Column Name'].tolist()
    prod_spec_req = requirements['Specification']
    prod_spec_columns = prod_spec_req.loc[prod_spec_req['Comments'] != 'Do not compare', 'Column Name'].tolist()
    
    prod_comp_req_ETDF = requirements['ETD_F Prefix-Product Cmpnds Tab']
    prod_comp_col_ETDF = prod_comp_req_ETDF.loc[prod_comp_req_ETDF['Comments'] != 'Do not compare', 'Column Name'].tolist()
    prod_comp_req_ETDN = requirements['ETD_N Prefix-Product Cmpnds Tab']
    prod_comp_col_ETDN = prod_comp_req_ETDN.loc[prod_comp_req_ETDN['Comments'] != 'Do not compare', 'Column Name'].tolist()
    prod_comp_req_ETDS = requirements['ETD_S Prefix-Product Cmpnds Tab']
    prod_comp_col_ETDS = prod_comp_req_ETDS.loc[prod_comp_req_ETDS['Comments'] != 'Do not compare', 'Column Name'].tolist()
    
def add_manual_columns(file,rerun=False):
    if rerun:
        if 'History of Comments' not in file.columns:
            print("creating history of comments")
            file['History of Comments'] = file['COMMENTS']
    file['COMMENTS'] = 'Verified - OK'
    file['Verified by'] = ''
    file['Pass/Fail'] = 'N/A'
    return file.astype(str)

def find_prod_for_dosage(prod_spec):
    # Define the possible values and their corresponding regex patterns
    value_patterns = {
        "BLANK": r'ETD_INSTRUMENT_CHECK|ETD_PERFORMANCE_CHECK',
        "ETD_STERI": r'ETD_STERI|ETD_DRYING',
        "SOL_LANI": r'ETD_SOL_VICRYL_BUFFER',
        "RELABEL": r'ETD_F_RELABEL',
        "LAB_ORDER": r'^(ETD_NR_LABORDER_).*',
        "SFG_NEEDLES_WIRE": r'^(ETD_R_WIREMILL).*',
        "SOL_CIA": r'^(ETD_SOL).*|ETD_BALANCE_PERFORMANCE',
        
        "SFG_NEEDLES": r'^(ETD_N_).*',
        "SFG_LANI": r'^(ETD_S_).*', 
        "FG": r'^(ETD_F_).*',
        "MICRO": r'^(ETD_M_).*',
        "ETD_R": r'^(ETD_R_).*',
    }
    # Iterate through the value patterns and check if prod_spec matches any of them
    for value, pattern in value_patterns.items():
        if re.match(pattern, prod_spec):
            return value
    # If no match is found, return None or a default value
    return None


def column_to_column_compare_(column, v7_prod, v6_prod, Analysis_MD_Trak, Prod_MD_Traker, styler,component=False,rerun=False):
    """
    column to column comparison for stage and specification level
    """
    for index, value in v7_prod[column].items():
        color = styler.get_cell_color(index, column)
        
        # print(v7_prod['PRODUCT'][index],color,JsonData)
        if color == "":
            if rerun:
                JsonData = v7_prod['JsonData'][index]
                if JsonData == 'Remove':
                    styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                    continue
                elif JsonData != "Passed":
                    JsonData = json.loads(JsonData.replace("'", "\""))
                    if column in JsonData.keys():
                        if JsonData[column] == 'Manual Correction':
                            styler.highlight_cell(index, column,"#92D050") # Light Green
                            continue
                        elif JsonData[column] == 'SME Verification':
                            styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                            comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                            styler.add_comments( index, comment)
                            continue
                        elif JsonData[column] == "No":
                            styler.highlight_cell(index, column,"#92D050") # Light Green
                            continue
                else:
                    styler.highlight_cell(index, column,"#92D050") # Light Green
                    continue
            v7_name = v7_prod['PRODUCT'][index]
            v7_grade = v7_prod['GRADE'][index]
            v7_analysis = v7_prod['ANALYSIS'][index]
            if component ==True:
                v7_Comp = v7_prod['COMPONENT'][index]
                v6_comp = Util.get_v6_component(Compnd_MD_Trak,v7_Comp,v7_analysis)
            MD_v6_analysis = Util.get_v6_analysis_from_Tracker(Analysis_MD_Trak, v7_analysis)
            if MD_v6_analysis:
                status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker, v7_name, v7_grade)
                if status:
                    if component:
                        v6_entry = Util.get_v6_row(v6_prod, v6_val['v6_code'], v6_val['v6_grade'], MD_v6_analysis,v6_comp)
                    else:
                        v6_entry = Util.get_v6_row(v6_prod, v6_val['v6_code'], v6_val['v6_grade'], MD_v6_analysis)
                        # print(v6_entry)
                    if not v6_entry.empty:
                        v6_value = v6_entry[column].values[0]
                        if v6_value == 'nil' or value == "":
                            status = Util.blank_check(v6_value,value)
                            if status:
                                styler.highlight_cell(index, column, "#92D050")  # Light Green
                            else:
                                styler.highlight_cell(index, column, "#FF0000") # red color
                                if value == '': value = 'Blank'
                                if v6_value == 'nil': v6_value = 'Blank'
                                comment = f'The {column} is "{value}" in v7 DEV. It should be "{v6_value}" as per v6 PROD.'
                                styler.add_comments( index, comment)
                        elif value in v6_entry[column].values:
                            styler.highlight_cell(index, column, "#92D050")  # Light Green
                        else:
                            styler.highlight_cell(index, column, "#FF0000") # red color
                            comment = f'The {column} is "{value}" in v7 DEV. It should be "{v6_entry[column].values[0]}" as per v6 PROD.'
                            styler.add_comments( index, comment)
                    else:
                        # print(index,v7_name,v7_grade,v6_val['v6_code'], v6_val['v6_grade'], MD_v6_analysis)
                        comment = f'The PRODUCT "{v7_name}" is not available in v6 PROD.'
                        styler.highlight_entire_row(index,"#FFFF00")  #Standard Yellow color
                        styler.add_comments( index, comment) 
                else:
                    comment = f'The PRODUCT "{v7_name}" is not available in MD Tracker.'
                    styler.highlight_entire_row(index,"#7030A0")   #Standard Purple color
                    styler.add_comments( index, comment) 
            else:
                # print(index,f'The ANALYSIS "{v7_analysis}" is not available in MD Tracker.')
                styler.highlight_entire_row(index,"#7030A0")  #Standard Purple color
                comment = 'The ANALYSIS "{}" is not present in MD Tracker.'.format(v7_analysis)
                styler.add_comments( index, comment)

def get_stage_match(stage):
    value_patterns = {
        "CIA_RECEIPT": r'^(CIA_RECEIPT).*',
        "RM_RECEIPT": r'^(RM_RECEIPT).*', 
    }
    for value, pattern in value_patterns.items():
        if re.match(pattern, stage):
            return value    
    return None
def get_spectype_match(spec):
    value_patterns = {
        "CIA": r'^(CIA).*',
        "RM": r'^(RM).*', 
    }
    for value, pattern in value_patterns.items():
        if re.match(pattern, spec):
            return value    
    return None
def get_spectype_stage_from_specification(prod_name, v7_stage, spec_type, stage):
    # Filter the DataFrame based on the product name
    filtered_v7_spec =  v7_stage.filter_rows_by_value('PRODUCT',prod_name)
    # Check if the filtered DataFrame is empty
    if filtered_v7_spec.empty:
        return False
    # Get unique values for 'SPEC_TYPE' and 'STAGE'
    mismatched_spec_types = filtered_v7_spec['SPEC_TYPE'].unique().tolist()
    mismatched_stages = filtered_v7_spec['STAGE'].unique().tolist()
    # Apply the matching functions to the unique values
    mismatched_spec_types1 = list(set([get_spectype_match(spec) for spec in mismatched_spec_types]))
    mismatched_stages1 = list(set([get_stage_match(stage) for stage in mismatched_stages]))
    
    comments1 ,comments2 = "",""
    status1 = False
    status2 = False
    comment = ""
    # If there are mismatches in SPEC_TYPE, add them to the result dictionary
    if len(mismatched_spec_types1) >1 and len(mismatched_spec_types1) !=0:
        # comments1 = f"SPEC TYPE - {', '.join(mismatched_spec_types)} (STAGE as {', '.join(mismatched_stages) if len(mismatched_stages)>1 else mismatched_stages[0]})"
        comments1 = f"SPEC_TYPE - {', '.join(mismatched_spec_types)}"

    else:
        if mismatched_spec_types1[0] == spec_type:
            status1 = True
        else:
            comment = comment+f'The T_PH_CU_DOSAGE is "{spec_type}" in v7 DEV. It should be "{mismatched_spec_types1[0]}" as per MD Protocol as the Analyses within the product has SPEC TYPE "{mismatched_spec_types[0]}" '
    if len(mismatched_stages1) >1 and len(mismatched_stages1) !=0:
        comments2 = f"STAGE - {', '.join(mismatched_stages)}"
    else:
        if mismatched_stages1[0] == stage:
            status2 = True
        else:
            comment = comment+f'and STAGE {mismatched_stages[0]} in the Product Grade Stage.'
    if status1 and status2:
        return True
    else:
        if comments1+''+comments2 != "":
            comment = 'In the Product Grade Stage, the Analyses has multiple '+comments1+' '+comments2+' in the Product. Thus, the T_PH_CU_DOSAGE is marked in blue for SME verification.'
            color = "#00B0F0" #blue
        else:
            color = "#FF0000" #red
        return {'comment':comment,'color':color}
def get_stage_spec_type_combination(comb_file,sample_plan,stage,spec_type):
    matched_rows = comb_file[(comb_file['SPEC_TYPE'] == spec_type) & (comb_file['STAGE'] == stage)]
    if not matched_rows.empty:
        if sample_plan in matched_rows['T_PH_SAMPLE_PLAN'].values:
            return True
        
    return False
def get_v6_stage_and_spec_type(v7,v6,index,spec=False):
    v7_name = v7['PRODUCT'][index]
    v7_analysis = v7['ANALYSIS'][index]
    if spec:
        v7_Comp = v7['COMPONENT'][index]
        v6_comp = Util.get_v6_component(Compnd_MD_Trak,v7_Comp,v7_analysis)
    MD_v6_analysis = Util.get_v6_analysis_from_Tracker(Analysis_MD_Trak, v7_analysis)
    if MD_v6_analysis:
        status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker, v7_name)
        if status:
            if spec:
                v6_entry = Util.get_v6_row(v6, v6_val['v6_code'], v6_val['v6_grade'], analysis=MD_v6_analysis,component=v6_comp)
            else:
                v6_entry = Util.get_v6_row(v6, v6_val['v6_code'], v6_val['v6_grade'], analysis=MD_v6_analysis)
            if not v6_entry.empty:
                v6_stage = v6_entry['STAGE'].values[0]
                v6_spec_type = v6_entry['SPEC_TYPE'].values[0]
            else:
                v6_stage = ""
                v6_spec_type = ""
            return v6_stage, v6_spec_type
        else:
            return "", ""
    else:
        return "", ""
def get_IC_sample_plan(IC_v7_spec,IC_v7_summary,prod_name,comb_file,stage,spec_type):
    matched_rows = IC_v7_spec[IC_v7_spec['PRODUCT_SPEC'] == prod_name]
    sample_plan = set()
    if not matched_rows.empty:
        itemcode_list = matched_rows['T_PH_ITEM_CODE'].values
        for itemcode in itemcode_list:
            s_plan = IC_v7_summary.loc[IC_v7_summary['NAME'] == itemcode, 'SAMPLE_PLAN'].values[0]
            sample_plan.add(s_plan) 
    if len(sample_plan) == 1:
        SP = list(sample_plan)[0]
        match = get_stage_spec_type_combination(comb_file,SP,stage,spec_type)
        if match:
            return True,"matched",""
        else:
            return False, f'The STAGE is "{stage}" and the Spec Type is "{spec_type}" in v7 DEV. The Stage and Spec Type combination for the Sample Plan "{SP}" is unavailable in the reference file to perform the comparison. The Stage is "_stage" and the Spec Type is "_spec_type" in v6 PROD. (Note: v6 Stage = v7 Spec type; v6 spec type = v7 Stage)',"#FF0000" # red color
    elif len(sample_plan) == 0:
        return False,f"The v7 Product {prod_name} is not linked to any of the Item Code in the v7 Item Code Specification level. Hence, The STAGE and Spec Type is unsure. Hence, marked in blue for SME verification.", "#00B0F0" #blue
    else:
        return False,f"The sample plan is not unique for the product {prod_name}", "#7030A0" #Standard Purple color

def get_v6_entry_for_specification(v7_prod,v6_prod,index,value):
    v7_name = v7_prod['PRODUCT'][index]
    v7_grade = v7_prod['GRADE'][index]
    v7_analysis = v7_prod['ANALYSIS'][index]
    v7_Comp = v7_prod['COMPONENT'][index]
    v6_comp = Util.get_v6_component(Compnd_MD_Trak,v7_Comp,v7_analysis)
    MD_v6_analysis = Util.get_v6_analysis_from_Tracker(Analysis_MD_Trak, v7_analysis)
    if MD_v6_analysis:
        status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker, v7_name,v7_grade)
        if status:
            v6_entry = Util.get_v6_row(v6_prod, v6_val['v6_code'], v6_val['v6_grade'], MD_v6_analysis,v6_comp)
            if not v6_entry.empty:
                return True,v6_entry,"",""
            else:
                return False,v6_comp,'The COMPONENT is "{}"  in v7 DEV. It\'s corresponding v6 component is "{}" not available in v6 PROD.'.format(v7_Comp,v6_comp),"#FF99FF"  #pink color
        else:
            return False,v6_comp,'The PRODUCT Name "{}" is not available in Product MD Tracker.'.format(v7_name),"#7030A0" #Standard Purple color
    else:
        return False,v6_comp,'The ANALYSIS "{}" is not present in MD Tracker.'.format(v7_analysis),"#7030A0" #Standard Purple color
def highlight_excess_row_prod(v6,v7,Prod_MD_Traker,s_color="#FFFF00",prod_column='PRODUCT',grade=True,compound=False,string=""): #Standard Yellow color

    # Iterate over rows in v6 and compare with v7
    for index, row in v6.dataframe.iterrows():
        # Replace or append the string during comparison
        if not compound:
            v6_prod = v6.dataframe[prod_column][index]
        else:
            v6_prod = v6.dataframe['PRODUCT_SPEC'][index]
        
        if grade or compound:
            v6_grade = v6.dataframe['GRADE'][index]
            filtered_rows = Prod_MD_Traker.loc[(Prod_MD_Traker['v6 Product entry code'] == str(v6_prod)) & (Prod_MD_Traker['v6 Grades'] == str(v6_grade))]
            if len(filtered_rows) > 0:
                MD_Trak_v7_prod = filtered_rows['v7 Product entry code'].values[0]
                if grade:
                    MD_Trak_v7_grade = filtered_rows['v7 Grades'].values[0]
                    filtered_v7 = v7.loc[(v7[prod_column] == str(MD_Trak_v7_prod)) & (v7['GRADE'] == str(MD_Trak_v7_grade))]
                elif compound:
                    v6_item = str(v6.dataframe['T_PH_ITEM_CODE'][index])
                    # print(v7.columns)
                    filtered_v7 = v7.loc[(v7[prod_column] == str(MD_Trak_v7_prod)) & (v7['ITEM'] == 'ETD_'+v6_item)]
                else:
                    filtered_v7 = v7.loc[v7[prod_column] == str(MD_Trak_v7_prod)]
                if len(filtered_v7) == 0:
                    # print("not in v7 ", str(v6_prod),str(v6_grade),"color ",s_color)
                    v6.highlight_entire_row(index, s_color)
                    continue
            else:
                # print("not in MD Tracker ", str(v6_prod),str(v6_grade),"color ",s_color)
                v6.highlight_entire_row(index, "#7030A0")  #Standard Purple color
                continue
        else:
            filtered_rows = Prod_MD_Traker.loc[Prod_MD_Traker['v6 Product entry code'] == str(v6_prod)]
            if len(filtered_rows) > 0:
                MD_Trak_v7_prod = filtered_rows['v7 Product entry code'].values
                if any(value in v7['NAME'].values for value in MD_Trak_v7_prod):
                    pass
                else:
                    # print("not in v7 summary ", str(v6_prod),"color ",s_color)
                    v6.highlight_entire_row(index, s_color) #Standard Yellow color
                    continue
        if 'ANALYSIS' in v6.dataframe.columns: 
            color = v6.get_cell_color(index, 'ANALYSIS')
            if color == "":
                v6_analysis = v6.dataframe['ANALYSIS'][index]
                v7_MD_analysis = Util.get_v7_analysis_from_Tracker(Analysis_MD_Trak,v6_analysis)
                if v7_MD_analysis:
                    if any(value in filtered_v7['ANALYSIS'].values for value in v7_MD_analysis):
                        pass
                    else:
                        # print("not in v7 MD Trackeranalysis ", str(v6_prod),str(v6_grade))
                        v6.highlight_entire_row(index, "#66FFFF")  #teal color excess analysis
                        continue
        if 'COMPONENT' in v6.dataframe.columns:
            color = v6.get_cell_color(index, 'COMPONENT')
            if color == "":
                v6_Component = v6.dataframe['COMPONENT'][index]
                MD_Component = Util.get_v7_component(Compnd_MD_Trak,v6_Component)
                if not MD_Component:
                    # print("not in v7 MD component ", str(v6_prod),str(v6_grade))
                    v6.highlight_entire_row(index, "#FF99FF")  #pink color excess component
                    continue
def specification_comparison(v7_prod_spec,v6_prod_spec,v7_IC_spec,v7_IC_summary, rerun=False):
    v7_prod_spec = add_manual_columns(v7_prod_spec,rerun=rerun)
    spec_styler = DF_Styler(v7_prod_spec,prod_spec_columns+manual_columns)
    v6_spec_styler = DF_Styler(v6_prod_spec,v6_prod_spec.columns)
    highlight_excess_row_prod(v6_spec_styler,v7_prod_spec,Prod_MD_Traker)
    spec_typ_cols = ['RULE_TYPE', 'UNITS','SPEC_RULE','MIN_VALUE','MAX_VALUE','TEXT_VALUE','ROUND','PLACES','HI_CONTROL_1','HI_CONTROL_2','LO_CONTROL_1', 'LO_CONTROL_2']
    # Iterate over the columns in v7_query
    for column in prod_spec_columns: # iterating
        if column in v7_prod_spec.columns:
            if not pd.isna(prod_spec_req.loc[prod_spec_req['Column Name'] == column, 'Bot Instructions'].values[0]):
                instructions = json.loads(prod_spec_req.loc[prod_spec_req['Column Name'] == column, 'Bot Instructions'].values[0])
                if instructions['Type'] == 'column to column':
                        if column == 'PRODUCT':
                            for index, value in v7_prod_spec[column].items():
                                if rerun:
                                    JsonData = v7_prod_spec['JsonData'][index]
                                    if JsonData == 'Remove':
                                        spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        continue
                                    elif JsonData == "Passed":
                                        spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        continue
                                prod,comment,color_ = Util.check_prodname_in_v6(Prod_MD_Traker,v6_prod_spec,value,grade=True)
                                if prod:
                                    spec_styler.highlight_cell(index, column,color_) # Light Green
                                else:
                                    spec_styler.highlight_entire_row(index,color_) 
                                    spec_styler.add_comments(index, comment) 
                        if column == 'UNITS':
                            for index, value in v7_prod_spec[column].items():
                                color = spec_styler.get_cell_color(index, column)
                                if color == "":
                                    if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                    rule_type = v7_prod_spec['RULE_TYPE'][index]
                                    if rule_type == 'T':
                                        spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                    else:
                                        status,v6_entry,comment,color_ = get_v6_entry_for_specification(v7_prod_spec,v6_prod_spec,index,value)
                                        if status:
                                            v6_unit = v6_entry[column].values[0]
                                            if value == "" and v6_unit == 'nil':
                                                spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                            else:
                                                v7_MD_units = Util.get_v7_units(Units_MD_Trak,v6_unit)
                                                if value in v7_MD_units:
                                                    spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                                else:
                                                    spec_styler.highlight_cell(index, column, "#FF0000") # red color
                                                    if value == '': value = 'Blank'
                                                    comment = f'The {column} is "{value}" in v7 DEV. It is "{v6_unit}" in v6 PROD. It should be "{",".join(v7_MD_units)}" as per v6 PROD and MD Tracker.'
                                                    spec_styler.add_comments( index, comment)
                                        else:
                                            spec_styler.highlight_cell(index, column, color_) 
                                            spec_styler.add_comments( index, comment)
                                    
                        if column == 'RULE_TYPE':
                            for index, value in v7_prod_spec[column].items():
                                color = spec_styler.get_cell_color(index, column)
                                if color == "":
                                    if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                    status,v6_entry,comment,color_ = get_v6_entry_for_specification(v7_prod_spec,v6_prod_spec,index,value)
                                    if status:
                                        v6_rule_type = v6_entry[column].values[0]
                                        if value == v6_rule_type:
                                            spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                        else:
                                            spec_styler.color_specific_columns(index, spec_typ_cols, "#C00000")  #Standard Brown color
                                            comment = f'The RULE_TYPE is "{value}" in v7 DEV. It is "{v6_rule_type}" in v6 PROD.'
                                            spec_styler.add_comments( index, comment)
                                    else:
                                        spec_styler.highlight_cell(index, column, color_) 
                                        spec_styler.add_comments( index, comment)
                                        
                        if column == 'SPEC_RULE':
                            for index, value in v7_prod_spec[column].items():
                                color = spec_styler.get_cell_color(index, column)
                                if color == "":
                                    if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                    rule_type = v7_prod_spec['RULE_TYPE'][index]
                                    if rule_type == 'F':
                                        spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                    else:
                                        status,v6_entry,comment,color_ = get_v6_entry_for_specification(v7_prod_spec,v6_prod_spec,index,value)
                                        if status:
                                            v6_spec_rule = v6_entry[column].values[0]
                                            if value == "" and v6_spec_rule == 'nil':
                                                spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                            elif value == v6_spec_rule:
                                                spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                            else:
                                                spec_styler.highlight_cell(index, column, "#FF0000") # red color
                                                if value == '': value = 'Blank'
                                                if v6_unit == 'nil': value = 'Blank'
                                                comment = f'The SPEC_RULE is "{value}" in v7 DEV. It should be "{v6_spec_rule}" as per v6 PROD'
                                                spec_styler.add_comments( index, comment)
                                        else:
                                            spec_styler.highlight_cell(index, column, color_) 
                                            spec_styler.add_comments( index, comment)
                        if column == 'MIN_VALUE': # columns MIN_VALUE,MAX_VALUE
                            for index, value in v7_prod_spec[column].items():
                                min_column = None
                                Max_column = None
                                places_column =None
                                color = spec_styler.get_cell_color(index, column)
                                if color == "":
                                    if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    min_column =True
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    min_column =True
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    min_column =True
                                            if 'PLACES' in JsonData.keys():
                                                if JsonData['PLACES'] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, 'PLACES',"#92D050") # Light Green
                                                    places_column = True
                                                elif JsonData['PLACES'] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, 'PLACES',"#00B0F0")  # SME blue
                                                    comment = f'The PLACES is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    places_column = True
                                                elif JsonData['PLACES'] == "No":
                                                    spec_styler.highlight_cell(index, 'PLACES',"#92D050") # Light Green
                                                    places_column = True
                                            if 'MAX_VALUE' in JsonData.keys():
                                                if JsonData['MAX_VALUE'] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, 'MAX_VALUE',"#92D050") # Light Green
                                                    Max_column = True
                                                elif JsonData['MAX_VALUE'] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, 'MAX_VALUE',"#00B0F0")  # SME blue
                                                    comment = f'The MAX_VALUE is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    Max_column = True
                                                elif JsonData['MAX_VALUE'] == "No":
                                                    spec_styler.highlight_cell(index, 'MAX_VALUE',"#92D050") # Light Green
                                                    Max_column = True
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            spec_styler.highlight_cell(index, 'MAX_VALUE', "#92D050")  # Light Green
                                            spec_styler.highlight_cell(index, 'PLACES', "#92D050")  # Light Green
                                            continue
                                    rule_type = v7_prod_spec['RULE_TYPE'][index]
                                    if rule_type == 'F' or rule_type == 'T':
                                        spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                        spec_styler.highlight_cell(index, 'MAX_VALUE', "#92D050")  # Light Green
                                        spec_styler.highlight_cell(index, 'PLACES', "#92D050")  # Light Green
                                    else:
                                        status,v6_entry,comment,color_ = get_v6_entry_for_specification(v7_prod_spec,v6_prod_spec,index,value)
                                        if status:
                                            spec_rule = v6_entry['SPEC_RULE'].values[0]
                                            v6_min = str(v6_entry[column].values[0])
                                            v7_min = value
                                            v6_max = str(v6_entry['MAX_VALUE'].values[0])
                                            v7_max = v7_prod_spec['MAX_VALUE'][index]
                                            v7_places = v7_prod_spec['PLACES'][index]
                                            v6_places = v6_entry['PLACES'].values[0]
                                            if spec_rule == 'Result >= MIN' or spec_rule == 'Result > MIN' or spec_rule == 'Result <= MIN' or spec_rule == 'Result < MIN':
                                                spec_styler.highlight_cell(index, 'MAX_VALUE', "#92D050")  # Light Green
                                                if v6_min == 'nil':
                                                    if v7_min != "":
                                                        spec_styler.highlight_cell(index, 'PLACES', "#00B0F0")
                                                        comment = f'The PLACES is "{v7_places}" in v7 DEV. The Places should be according to v6 Spec limits, but the v6 Min and Max values are "nil".  Hence, the "Places" requires SME verification.'
                                                        spec_styler.add_comments( index, comment)
                                                        
                                                elif v6_min != "" and v7_min == "": 
                                                    places = Util.get_decimal_places(v6_min.replace(",",'.'))
                                                    if places == v7_places:
                                                        spec_styler.highlight_cell(index, 'PLACES', "#92D050")  # Light Green
                                                    else:
                                                        spec_styler.highlight_cell(index, 'PLACES', "#FF0000") # red color
                                                        comment = f'The PLACES is "{v7_places}" in v7 DEV. It should be "{places}" according to v6 Spec limits (Min value - {v6_min}). Note: v7 Min value is Blank.'
                                                        spec_styler.add_comments( index, comment)
                                                else:
                                                    places = Util.get_decimal_places(v6_min.replace(",",'.'))
                                                    if places == v7_places:
                                                        spec_styler.highlight_cell(index, 'PLACES', "#92D050")  # Light Green
                                                    else:
                                                        spec_styler.highlight_cell(index, 'PLACES', "#FF0000") # red color
                                                        comment = f'The PLACES is "{v7_places}" in v7 DEV. It should be "{places}" according to v6 Spec limits (Min value - {v6_min}).'
                                                        spec_styler.add_comments( index, comment)
                                                if value.replace(",",'.') == v6_min.replace(",",'.'):
                                                    spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                                else:
                                                    spec_styler.highlight_cell(index, column, "#FF0000") # red color
                                                    if value == '': value = 'Blank'
                                                    if v6_min == 'nil': v6_min = 'Blank'
                                                    if ',' in v6_min: v6_min=v6_min.replace(",",'.')
                                                    comment = f'The {column} is "{value}" in v7 DEV. It should be "{v6_min}" as per v6 PROD'
                                                    spec_styler.add_comments( index, comment)
                                                    
                                            elif spec_rule == 'Result >= MAX' or spec_rule == 'Result > MAX' or spec_rule == 'Result <= MAX' or spec_rule == 'Result < MAX':
                                                spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                                if v6_max == 'nil':
                                                    if v7_max != "":
                                                        spec_styler.highlight_cell(index, 'PLACES', "#00B0F0")
                                                        comment = f'The PLACES is "{v7_places}" in v7 DEV. The Places should be according to v6 Spec limits, but the v6 Min and Max values are "nil".  Hence, the "Places" requires SME verification.'
                                                        spec_styler.add_comments( index, comment)
                                                elif v6_max != "" and v7_max == "":
                                                        places = Util.get_decimal_places(v6_max.replace(",",'.'))
                                                        if places == v7_places:
                                                            spec_styler.highlight_cell(index, 'PLACES', "#92D050")  # Light Green
                                                        else:
                                                            spec_styler.highlight_cell(index, 'PLACES', "#FF0000") # red color
                                                            comment = f'The PLACES is "{v7_places}" in v7 DEV. It should be "{places}" according to v6 Spec limits (Max value - {v6_max}). Note: v7 Max value is Blank.'
                                                            spec_styler.add_comments( index, comment)
                                                else:
                                                    places = Util.get_decimal_places(v6_max.replace(",",'.'))
                                                    if places == v7_places:
                                                        spec_styler.highlight_cell(index, 'PLACES', "#92D050")  # Light Green
                                                    else:
                                                        spec_styler.highlight_cell(index, 'PLACES', "#FF0000") # red color
                                                        comment = f'The PLACES is "{v7_places}" in v7 DEV. It should be "{places}" according to v6 Spec limits (Max value - {v6_max}).'
                                                        spec_styler.add_comments( index, comment)
                                                if not Max_column:
                                                    if v7_max.replace(",",'.') == v6_max.replace(",",'.'):
                                                        spec_styler.highlight_cell(index, 'MAX_VALUE', "#92D050")  # Light Green
                                                    else:
                                                        spec_styler.highlight_cell(index, 'MAX_VALUE', "#FF0000") # red color
                                                        if v7_max == '': v7_max = 'Blank'
                                                        if v6_min == 'nil': v6_min = 'Blank'
                                                        if ',' in v6_max: v6_max=v6_max.replace(",",'.')
                                                        comment = f'The MAX_VALUE is "{v7_max}" in v7 DEV. It should be "{v6_max}" as per v6 PROD'
                                                        spec_styler.add_comments( index, comment)
                                                    
                                            elif spec_rule == 'MIN <= Result <= MAX':
                                                if not places_column:
                                                    if v6_min == 'nil' and v6_max == 'nil':
                                                        spec_styler.highlight_cell(index, 'PLACES', "#00B0F0")
                                                        comment = f' The PLACES is "{v7_places}" in v7 DEV. The Places should be according to v6 Spec limits, but the v6 Min and Max values are "nil".  Hence, the "Places" requires SME verification.'
                                                        spec_styler.add_comments( index, comment)
                                                    elif v7_min == "" and v7_max == "":
                                                            status,places = Util.get_decimal_places(v6_min.replace(",",'.'),v6_max.replace(",",'.'))
                                                            if status:
                                                                if places == v7_places:
                                                                    spec_styler.highlight_cell(index, 'PLACES', "#92D050")  # Light Green
                                                                else:
                                                                    spec_styler.highlight_cell(index, 'PLACES', "#FF0000") # red color
                                                                    comment = f'The PLACES is "{v7_places}" in v7 DEV. It should be "{places}" according to v6 Spec limits (Min value - {v6_min}). Note: v7 Min value is Blank.'
                                                                    spec_styler.add_comments( index, comment)
                                                            else:
                                                                spec_styler.highlight_cell(index, 'PLACES', "#00B0F0")
                                                                comment = f'The PLACES is "{v7_places}" in v7 DEV. It has varied decimal places within the spec values. (Min value - {v6_min} and Max value - {v6_max}).'
                                                                spec_styler.add_comments( index, comment)
                                                    else:
                                                        status,places = Util.get_decimal_places(v6_min.replace(",",'.'),v6_max.replace(",",'.'))
                                                        if status:
                                                            if places == v7_places:
                                                                spec_styler.highlight_cell(index, 'PLACES', "#92D050")  # Light Green
                                                            else:
                                                                spec_styler.highlight_cell(index, 'PLACES', "#FF0000") # red color
                                                                comment = f'The PLACES is "{v7_places}" in v7 DEV. It should be "{places}" according to v6 Spec limits (Min value - {v6_min} and Max value - {v6_max}).'
                                                                spec_styler.add_comments( index, comment)
                                                        else:
                                                            spec_styler.highlight_cell(index, 'PLACES', "#00B0F0")
                                                            comment = f'The PLACES is "{v7_places}" in v7 DEV. It has varied decimal places within the spec values. (Min value - {v6_min} and Max value - {v6_max}).'
                                                            spec_styler.add_comments( index, comment)
                                                v7_discrepancy = Util.check_decimal_discrepancy(value,v7_max)
                                                if v7_discrepancy:
                                                    if not min_column:
                                                        v6_discrepancy = Util.check_decimal_discrepancy(v6_min,v6_max)
                                                        if v6_discrepancy:
                                                            if v6_min.replace(",",'.') == v7_min.replace(",",'.'):
                                                                spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                                            else:
                                                                spec_styler.highlight_cell(index, column, "#FF0000") # red color
                                                                if value == '': value = 'Blank'
                                                                if v6_min == 'nil': v6_min = 'Blank'
                                                                comment = f'The {column} is "{value}" in v7 DEV. It should be "{v6_min}" as per v6 PROD'
                                                                spec_styler.add_comments(index, comment) 
                                                            if v6_max.replace(",",'.') == v7_max.replace(",",'.'):
                                                                spec_styler.highlight_cell(index, 'MAX_VALUE', "#92D050")  # Light Green
                                                            else:
                                                                spec_styler.highlight_cell(index, 'MAX_VALUE', "#FF0000") # red color
                                                                if v7_max == '': v7_max = 'Blank'
                                                                if v6_min == 'nil': v6_min = 'Blank'
                                                                if ',' in v6_max: v6_max=v6_max.replace(",",'.')
                                                                comment = f'The MAX_VALUE is "{v7_max}" in v7 DEV. It should be "{v6_max}" as per v6 PROD'
                                                                spec_styler.add_comments( index, comment) 
                                                        else:
                                                            if not min_column:
                                                                spec_styler.highlight_cell(index, column, "#00B0F0")
                                                                spec_styler.highlight_cell(index, 'MAX_VALUE', "#00B0F0")
                                                                # if value == '': value = 'Blank'
                                                                # if v6_units == 'nil': value = 'Blank'
                                                                if ',' in v6_min: v6_min=v6_min.replace(",",'.')
                                                                if ',' in v6_max: v6_max=v6_max.replace(",",'.')
                                                                comment = f'The MIN_VALUE is "{value}" and Max value is "{v7_max}" in v7 DEV. The Min value is "{v6_min}" and Max value is "{v6_max}" in v6 PROD. It has varied decimal places within the spec values in v6. Hence, v7 spec values requires SME verification.'
                                                                spec_styler.add_comments( index, comment) 
                                                else:
                                                    if not min_column:
                                                        spec_styler.highlight_cell(index, column, "#00B0F0") # SME blue
                                                        spec_styler.highlight_cell(index, 'MAX_VALUE', "#00B0F0") # SME blue
                                                        # if value == '': value = 'Blank'
                                                        # if v6_units == 'nil': value = 'Blank'
                                                        if ',' in v6_min: v6_min=v6_min.replace(",",'.')
                                                        if ',' in v6_max: v6_max=v6_max.replace(",",'.')
                                                        comment = f'The MIN_VALUE is "{value}" and Max value is "{v7_max}" in v7 DEV. It has varied decimal places within the spec values. Hence, it requires SME verification. Note: The Min value is "{v6_min}" and Max value is "{v6_max}" in v6 PROD.'
                                                        spec_styler.add_comments( index, comment)
                                            else:
                                                if v7_max == '': v7_max = 'Blank'
                                                if v6_min == 'nil': v6_min = 'Blank'
                                                if not min_column:
                                                    spec_styler.highlight_cell(index, column, "#00B0F0")  # SME blue
                                                    comment = f'The MIN_VALUE is "{v7_min}" in v7 DEV. The MIN_VALUE is "{v6_min}" in v6 PROD. As we are unsure of the correct SPEC_RULE, it requires SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                if not places_column:
                                                    spec_styler.highlight_cell(index, 'PLACES', "#00B0F0")  # SME blue
                                                    comment = f'The PLACES is "{v7_places}" in v7 DEV. The PLACES is "{v6_places}" in v6 PROD. As we are unsure of the correct SPEC_RULE, it requires SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                if not Max_column:
                                                    spec_styler.highlight_cell(index, 'MAX_VALUE', "#00B0F0") # SME blue
                                                    comment = f'The MAX_VALUE is "{v7_max}" in v7 DEV. The MAX_VALUE is "{v6_max}" in v6 PROD. As we are unsure of the correct SPEC_RULE, it requires SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                        else:
                                            spec_styler.highlight_cell(index, column, color_) 
                                            spec_styler.add_comments( index, comment)
                                                    
                        if column == 'GRADE':
                            for index, value in v7_prod_spec[column].items():
                                color = spec_styler.get_cell_color(index,column)
                                if color =="":
                                    if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                    v7_name = v7_prod_spec['PRODUCT'][index]
                                    v7_grade = v7_prod_spec['GRADE'][index]
                                    status, MD_prod_row = Util.get_product_Tracker_row(Prod_MD_Traker,v7_name,v7_grade)
                                    if status:
                                        if str(value) in MD_prod_row['filtered_rows']['v7 Grades'].values:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        else:
                                            spec_styler.highlight_entire_row(index, "#7030A0") #Standard Purple color
                                            comment = 'The GRADE "{}" is in v7 DEV. It is not available in MD Tracker'.format(value)
                                            spec_styler.add_comments( index, comment)
                                    
                        if column == 'HI_CONTROL_2':
                            for index, value in v7_prod_spec[column].items():
                                color = spec_styler.get_cell_color(index, column)
                                if color == "":
                                    if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    spec_styler.highlight_cell(index, 'LO_CONTROL_2',"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    spec_styler.highlight_cell(index, 'LO_CONTROL_2',"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    comment = f'The LO_CONTROL_2 is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    spec_styler.highlight_cell(index, 'LO_CONTROL_2',"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            spec_styler.highlight_cell(index, 'LO_CONTROL_2',"#92D050") # Light Green
                                            continue
                                    v7_name = v7_prod_spec['PRODUCT'][index]
                                    v7_grade = v7_prod_spec['GRADE'][index]
                                    v7_analysis = v7_prod_spec['ANALYSIS'][index]
                                    v7_Comp = v7_prod_spec['COMPONENT'][index]
                                    v6_comp = Util.get_v6_component(Compnd_MD_Trak,v7_Comp,v7_analysis)
                                    MD_v6_analysis = Util.get_v6_analysis_from_Tracker(Analysis_MD_Trak, v7_analysis)
                                    if MD_v6_analysis:
                                        status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker, v7_name,v7_grade)
                                        if status:
                                            v6_entry = Util.get_v6_row(v6_prod_spec, v6_val['v6_code'], v6_val['v6_grade'], MD_v6_analysis,v6_comp)
                                            if not v6_entry.empty:
                                                v6_X_QS_MAX = v6_entry['X_QS_MAX'].values[0]
                                                v6_hi_cont_2 = v6_entry[column].values[0]
                                                color,comments = Util.handle_combinations(v6_hi_cont_2,v6_X_QS_MAX,value,column,"Range above")
                                                if comments == "":
                                                    spec_styler.highlight_cell(index, column, color)  # Light Green
                                                else:
                                                    spec_styler.highlight_cell(index, column, color)
                                                    spec_styler.add_comments( index, comments)
                                                v6_X_QS_MIN = v6_entry['X_QS_MIN'].values[0]
                                                v6_low_cont_2 = v6_entry['LO_CONTROL_2'].values[0]
                                                v7_low_2 = v7_prod_spec['LO_CONTROL_2'][index]
                                                color,comments = Util.handle_combinations(v6_low_cont_2,v6_X_QS_MIN,v7_low_2,"LO_CONTROL_2","Range below")
                                                if comments == "":
                                                    spec_styler.highlight_cell(index, 'LO_CONTROL_2', color)  # Light Green
                                                else:
                                                    spec_styler.highlight_cell(index, 'LO_CONTROL_2', color)
                                                    spec_styler.add_comments( index, comments)
                                            else:
                                                print(index,f'The PRODUCT "{v7_name}" is not available in v6 PROD.')
                                        else:
                                            print(index,f'The PRODUCT Name "{v7_name}" is not available in MD Tracker.')
                                    else:
                                        print(index,f'The ANALYSIS "{v7_analysis}" is not available in MD Tracker.')
                        if column == 'TEXT_VALUE':
                            for index, value in v7_prod_spec[column].items():
                                color = spec_styler.get_cell_color(index, column)
                                if color == "":
                                    if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                    rule_type = v7_prod_spec['RULE_TYPE'][index]
                                    if rule_type == 'F' or rule_type == 'N':
                                        spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                    else:
                                        v7_name = v7_prod_spec['PRODUCT'][index]
                                        v7_grade = v7_prod_spec['GRADE'][index]
                                        v7_analysis = v7_prod_spec['ANALYSIS'][index]
                                        v7_Comp = v7_prod_spec['COMPONENT'][index]
                                        v6_comp = Util.get_v6_component(Compnd_MD_Trak,v7_Comp,v7_analysis)
                                        MD_v6_analysis = Util.get_v6_analysis_from_Tracker(Analysis_MD_Trak, v7_analysis)
                                        if MD_v6_analysis:
                                            status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker, v7_name,v7_grade)
                                            if status:
                                                v6_entry = Util.get_v6_row(v6_prod_spec, v6_val['v6_code'], v6_val['v6_grade'], MD_v6_analysis,v6_comp)
                                                if not v6_entry.empty:
                                                    if value == "":
                                                        if v6_entry[column].values[0] == 'nil':
                                                            spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                                        else:
                                                            spec_styler.highlight_cell(index, column, "#FF0000") # red color
                                                            comment = f'The {column} is "Blank" in v7 DEV. It should be "{v6_entry[column].values[0]}" as per v6 PROD'
                                                            spec_styler.add_comments( index, comment)
                                                    if value in v6_entry[column].values:
                                                        spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                                    else:
                                                        spec_styler.highlight_cell(index, column, "#FF0000") # red color
                                                        comment = f'The {column} is "{value}" in v7 DEV. It should be "{v6_entry[column].values[0]}" as per v6 PROD'
                                                        spec_styler.add_comments( index, comment)
                                        #         else:
                                        #             print(index,f'The PRODUCT "{v7_name}" is not available in v6 PROD.')
                                        #     else:
                                        #         print(index,f'The PRODUCT Name "{v7_name}" is not available in MD Tracker.')
                                        # else:
                                        #     print(index,f'The ANALYSIS "{v7_analysis}" is not available in MD Tracker.')
                        if column == 'REQUIRED':
                            for index, value in v7_prod_spec[column].items():
                                color = spec_styler.get_cell_color(index, column)
                                if color == "":
                                    if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                    prod = v7_prod_spec['PRODUCT'][index]
                                    status,val = Util.find_prod_for_required(prod)
                                    if status:
                                        if value == "T":
                                            spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                        else:
                                            spec_styler.highlight_cell(index, column, "#FF0000") # red color
                                            comment = f'The REQUIRED Boolean is "False" in v7 DEV. It Should be "True" as per site instruction for {val} prefix Products.'
                                            spec_styler.add_comments( index, comment) 
                                    else:
                                        spec_styler.highlight_cell(index, column,"#00B0F0")
                                        if value =='T': value="True" 
                                        else: value="False"
                                        comment = 'The REQUIRED boolean is "True" in v7 DEV. But based on site instruction it is marked in Blue for SME verification.'
                                        spec_styler.add_comments( index, comment)
                        if column == 'FORMULA':
                            for index, value in v7_prod_spec[column].items():
                                color = spec_styler.get_cell_color(index, column)
                                if color == "":
                                    if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                    rule_type = v7_prod_spec['RULE_TYPE'][index]
                                    if rule_type == 'T' or rule_type == 'N':
                                        spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                    else:
                                        spec_styler.highlight_cell(index, column,"#00B0F0") # SME blue 
                                        comment = f'The {column} field is marked in Blue for SME verification, as per the site instruction.'
                                        spec_styler.add_comments( index, comment)
                        if column == 'ROUND':
                            for index, value in v7_prod_spec[column].items():
                                color = spec_styler.get_cell_color(index, column)
                                if color == "":
                                    if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                    rule_type = v7_prod_spec['RULE_TYPE'][index]
                                    if rule_type == 'F':
                                        spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                    elif rule_type == 'N':
                                        if value == 'T':
                                            spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                        else:
                                            spec_styler.highlight_cell(index, column, "#FF0000") # red color
                                            comment = 'The ROUND is "False" in v7 DEV. It should be "True" as per MD Protocol for Numeric component.'
                                            spec_styler.add_comments( index, comment)
                                    elif rule_type == 'T':
                                        if value == 'F':
                                            spec_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                        else:
                                            spec_styler.highlight_cell(index, column, "#FF0000") # red color
                                            comment = 'The ROUND is "True" in v7 DEV. It should be "False" as per MD Protocol for Text component.'
                                            spec_styler.add_comments( index, comment)
                        if column in ['NUM_RESULT_REPS','CLASS','REPORTED_NAME','DESCRIPTION','HI_CONTROL_1','LO_CONTROL_1']:
                            column_to_column_compare_(column, v7_prod_spec, v6_prod_spec, Analysis_MD_Trak, Prod_MD_Traker, spec_styler,component=True,rerun=rerun)
                                                            
                elif instructions['Type'] == 'column to others':
                    if column == 'STAGE':
                        for index, value in v7_prod_spec[column].items():
                            color = spec_styler.get_cell_color(index,column)
                            if color =="":
                                if rerun:
                                    JsonData = v7_prod_spec['JsonData'][index]
                                    if JsonData == 'Remove':
                                        spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        continue
                                    elif JsonData != "Passed":
                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                        if column in JsonData.keys():
                                            if JsonData[column] == 'Manual Correction':
                                                spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                spec_styler.highlight_cell(index, 'SPEC_TYPE',"#92D050") # Light Green
                                                continue
                                            elif JsonData[column] == 'SME Verification':
                                                spec_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                spec_styler.add_comments( index, comment)
                                                spec_styler.highlight_cell(index, 'SPEC_TYPE',"#00B0F0")  # SME blue
                                                comment = f'The SPEC_TYPE is unsure, Hence marked in blue for SME verification.'
                                                spec_styler.add_comments( index, comment)
                                                continue
                                            elif JsonData[column] == "No":
                                                spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                spec_styler.highlight_cell(index, 'SPEC_TYPE',"#92D050") # Light Green
                                                continue
                                    else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            spec_styler.highlight_cell(index, 'SPEC_TYPE',"#92D050") # Light Green
                                            continue
                                v7_name = v7_prod_spec['PRODUCT'][index]
                                spec_type = v7_prod_spec['SPEC_TYPE'][index]
                                status,comment,color = get_IC_sample_plan(v7_IC_spec,v7_IC_summary,v7_name,stage_spec_type_comb_file,value,spec_type)
                                if status:
                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    spec_styler.highlight_cell(index, 'SPEC_TYPE',"#92D050") # Light Green
                                else:
                                    v6_stage,v6_spec_type = get_v6_stage_and_spec_type(v7_prod_spec,v6_prod_spec,index,spec=True)
                                    comment = comment.replace('"_stage"', f'"{v6_stage}"').replace('"_spec_type"', f'"{v6_spec_type}"')
                                    spec_styler.highlight_cell(index, column,color)
                                    spec_styler.highlight_cell(index, 'SPEC_TYPE',color)
                                    spec_styler.add_comments( index, comment)
                    if column == "ANALYSIS":
                        for index, value in v7_prod_spec[column].items():
                            color = spec_styler.get_cell_color(index,column)
                            if color =="":
                                if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_entire_row(index,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                v7_name = v7_prod_spec['PRODUCT'][index]
                                v7_grade = v7_prod_spec['GRADE'][index]
                                v7_analysis = v7_prod_spec['ANALYSIS'][index]
                                MD_v6_analysis = Util.get_v6_analysis_from_Tracker(Analysis_MD_Trak,v7_analysis)
                                if MD_v6_analysis:
                                    status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker,v7_name,v7_grade)
                                    if status:
                                        v6_entry = Util.get_v6_row(v6_prod_spec,v6_val['v6_code'],v6_val['v6_grade'])
                                        # Check if any rows are found in v6 file
                                        if not v6_entry.empty:
                                            if any(value in v6_entry['ANALYSIS'].values for value in MD_v6_analysis):
                                                spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            else:
                                                spec_styler.highlight_entire_row(index,"#66FFFF")  #teal color
                                                comment = 'The ANALYSIS "{}" is in v7 DEV. It\'s correcsponding v6 analysis "{}" is not available in v6 PROD'.format(value,MD_v6_analysis)
                                                spec_styler.add_comments( index, comment)
                                        else:
                                            pass
                                            # comment = 'The PRODUCT Name "{}" is not present in v6 PROD.'.format(value)
                                    else:
                                        spec_styler.highlight_entire_row(index,"#66FFFF")  #teal color
                                        comment = 'The PRODUCT "{}" is in v7 DEV. It\'s correcsponding v6 analysis "{}" is not available in v6 PROD'.format(value,MD_v6_analysis)
                                        spec_styler.add_comments( index, comment)
                                else:
                                    spec_styler.highlight_entire_row(index,"#7030A0")  #Standard Purple color
                                    comment = 'The ANALYSIS "{}" is not present in MD Tracker.'.format(value)
                                    spec_styler.add_comments( index, comment)
                    if column == "COMPONENT":
                        for index, value in v7_prod_spec[column].items():
                            color = spec_styler.get_cell_color(index,column)
                            if color =="":
                                if rerun:
                                        JsonData = v7_prod_spec['JsonData'][index]
                                        if JsonData == 'Remove':
                                            spec_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    spec_styler.highlight_entire_row(index,"#00B0F0")  # SME blue
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    spec_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == "No":
                                                    spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                v7_name = v7_prod_spec['PRODUCT'][index]
                                v7_grade = v7_prod_spec['GRADE'][index]
                                v7_analysis = v7_prod_spec['ANALYSIS'][index]
                                MD_v6_analysis = Util.get_v6_analysis_from_Tracker(Analysis_MD_Trak,v7_analysis)
                                if MD_v6_analysis:
                                    status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker,v7_name,v7_grade)
                                    if status:
                                        v6_entry = Util.get_v6_row(v6_prod_spec,v6_val['v6_code'],v6_val['v6_grade'])
                                        # Check if any rows are found in v6 file
                                        if not v6_entry.empty:
                                            if any(value in v6_entry['ANALYSIS'].values for value in MD_v6_analysis):
                                                v6_comp = Util.get_v6_component(Compnd_MD_Trak,value,v7_analysis)
                                                # print(index,v7_name,v6_comp)
                                                if v6_comp:
                                                    duplicate_check = Util.get_v6_row(v6_prod_spec,v6_val['v6_code'],v6_val['v6_grade'],MD_v6_analysis,v6_comp)
                                                    # print(index, len(duplicate_check))
                                                    if len(duplicate_check) == 1:
                                                        spec_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    elif len(duplicate_check) > 1:
                                                        spec_styler.highlight_entire_row(index,"#FF99FF")  #pink color
                                                        comment = 'The COMPONENT "{}" is single entry in v7 DEV. However, the corresponding  v6 Component "{}" is double entry in v6 PROD. Hence, marked in pink.'.format(value,MD_v6_analysis)
                                                        spec_styler.add_comments( index, comment)
                                                    else:
                                                        spec_styler.highlight_entire_row(index,"#FF99FF")  #pink color
                                                        comment = 'The COMPONENT is "{}"  in v7 DEV. It\'s corresponding v6 component is "{}" not available in v6 PROD.'.format(value,v6_comp)
                                                        spec_styler.add_comments( index, comment)
                                                else:
                                                    spec_styler.highlight_entire_row(index,"#FF99FF")  #pink color
                                                    comment = 'The COMPONENT is "{}"  in v7 DEV. It is not available in MD Tracker.'.format(value)
                                                    spec_styler.add_comments( index, comment)
                                            else:
                                                spec_styler.highlight_entire_row(index,"#66FFFF")  #teal color
                                                comment = 'The ANALYSIS "{}" is in v7 DEV. It\'s correcsponding v6 analysis "{}" is not available in v6 PROD'.format(v7_analysis,MD_v6_analysis)
                                                spec_styler.add_comments( index, comment)
                                        else:
                                            # pass
                                            print('The PRODUCT Name "{}" is not present in v6 PROD.'.format(value))
                                    else:
                                        # pass
                                        print('The PRODUCT Name "{}" is not present in MD Tracker.'.format(value))
                                else:
                                    spec_styler.highlight_entire_row(index,"#7030A0")  #Standard Purple color
                                    comment = 'The ANALYSIS "{}" is not present in MD Tracker.'.format(v7_analysis)
                                    spec_styler.add_comments( index, comment)
                else:
                    pass
    return {"v7":{'spec':spec_styler},"v6":{'spec':v6_spec_styler}}
#============================================================stage=====================================
def stage_and_summary_comparison(v7_prod_stage,v6_prod_stage,v7_prod_sum,v6_prod_sum,v7_IC_spec,v7_IC_summary, rerun=False):
    v6_stage_styler = DF_Styler(v6_prod_stage,v6_prod_stage.columns)
    highlight_excess_row_prod(v6_stage_styler,v7_prod_stage,Prod_MD_Traker)
    
    v7_prod_stage = add_manual_columns(v7_prod_stage,rerun=rerun)
    stage_styler = DF_Styler(v7_prod_stage,prod_stage_columns+manual_columns)
    # rearranged_list = ['PRODUCT', 'ANALYSIS', 'GRADE', 'DESCRIPTION', 'SPEC_TYPE', 'STAGE', 'REPORTED_NAME', 'T_PH_STATUS1', 'T_PH_SAME_LOT', 'NUM_REPS']
    # Iterate over the columns in v7_query
    for column in prod_stage_columns: # iterating
        if column in v7_prod_stage.columns:
            if not pd.isna(prod_stage_req.loc[prod_stage_req['Column Name'] == column, 'Bot Instructions'].values[0]):
                instructions = json.loads(prod_stage_req.loc[prod_stage_req['Column Name'] == column, 'Bot Instructions'].values[0])
                if instructions['Type'] == 'column to column':
                        if column == 'PRODUCT':
                            for index, value in v7_prod_stage[column].items():
                                if rerun:
                                    JsonData = v7_prod_stage['JsonData'][index]
                                    if JsonData == 'Remove':
                                        stage_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        continue
                                    elif JsonData == "Passed":
                                        stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        continue
                                prod,comment,color_ = Util.check_prodname_in_v6(Prod_MD_Traker,v6_prod_stage,value,grade=True)
                                if prod:
                                    stage_styler.highlight_cell(index, column,color_)
                                else:
                                    stage_styler.highlight_entire_row(index,color_) 
                                    stage_styler.add_comments(index, comment) 
                        if column == 'GRADE':
                            for index, value in v7_prod_stage[column].items():
                                color = stage_styler.get_cell_color(index,column)
                                if color =="":
                                    if rerun:
                                        JsonData = v7_prod_stage['JsonData'][index]
                                        if JsonData == 'Remove':
                                            stage_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            # print(v7_prod_stage['PRODUCT'][index],JsonData)
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    stage_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    stage_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    continue
                                                elif JsonData[column] == "No":
                                                    stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                    v7_name = v7_prod_stage['PRODUCT'][index]
                                    status, MD_prod_row = Util.get_product_Tracker_row(Prod_MD_Traker,v7_name)
                                    if status:
                                        if str(value) in MD_prod_row['filtered_rows']['v7 Grades'].values:
                                            stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        else:
                                            stage_styler.highlight_entire_row(index, "#7030A0") # purple
                                            comment = 'The GRADE "{}" is in v7 DEV. It is not available in MD Tracker'.format(value)
                                            stage_styler.add_comments( index, comment)
                        if column in ['DESCRIPTION','NUM_REPS','T_PH_SAME_LOT','T_PH_STATUS1']:
                            column_to_column_compare_(column, v7_prod_stage, v6_prod_stage, Analysis_MD_Trak, Prod_MD_Traker, stage_styler,rerun=rerun)
                        
                        if column == 'REPORTED_NAME':
                            for index, value in v7_prod_stage[column].items():
                                color = stage_styler.get_cell_color(index,column)
                                if color =="":
                                    if rerun:
                                        JsonData = v7_prod_stage['JsonData'][index]
                                        if JsonData == 'Remove':
                                            stage_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                            continue
                                        elif JsonData != "Passed":
                                            JsonData = json.loads(JsonData.replace("'", "\""))
                                            if column in JsonData.keys():
                                                if JsonData[column] == 'Manual Correction':
                                                    stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                    stage_styler.add_comments( index, comment)
                                                    continue
                                                elif JsonData[column] == 'SME Verification':
                                                    stage_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                    continue
                                                elif JsonData[column] == "No":
                                                    stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    continue
                                        else:
                                            stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            continue
                                    prod,comment,color_ = Util.check_prodname_in_v6(Prod_MD_Traker,v6_prod_stage,value,grade=True)
                                    if v7_prod_stage[column][index] == v7_prod_stage['ANALYSIS'][index]:
                                        stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    else:
                                        stage_styler.highlight_cell(index, column,"#FF0000") # red color
                                        comment = 'The REPORTED_NAME is "{}" in v7 DEV. It should be "{}" as per MD Protocol'.format(v7_prod_stage[column][index],v7_prod_stage['ANALYSIS'][index])
                                        stage_styler.add_comments( index, comment)                                     
                elif instructions['Type'] == 'column to others':
                    if column == 'STAGE':
                        for index, value in v7_prod_stage[column].items():
                            color = stage_styler.get_cell_color(index,column)
                            if color =="":
                                if rerun:
                                    JsonData = v7_prod_stage['JsonData'][index]
                                    if JsonData == 'Remove':
                                        stage_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        continue
                                    elif JsonData != "Passed":
                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                        if column in JsonData.keys():
                                            if JsonData[column] == 'Manual Correction':
                                                stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                stage_styler.highlight_cell(index, 'SPEC_TYPE',"#92D050") # Light Green
                                                continue
                                            elif JsonData[column] == 'SME Verification':
                                                stage_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                stage_styler.highlight_cell(index, 'SPEC_TYPE',"#00B0F0")  # SME blue
                                                comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                stage_styler.add_comments( index, comment)
                                                continue
                                            elif JsonData[column] == "No":
                                                stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                stage_styler.highlight_cell(index, 'SPEC_TYPE',"#92D050") # Light Green
                                                continue
                                    else:
                                        stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        stage_styler.highlight_cell(index, 'SPEC_TYPE',"#92D050") # Light Green
                                        continue
                                v7_name = v7_prod_stage['PRODUCT'][index]
                                spec_type = v7_prod_stage['SPEC_TYPE'][index]
                                status,comment,color = get_IC_sample_plan(v7_IC_spec,v7_IC_summary,v7_name,stage_spec_type_comb_file,value,spec_type)
                                if status:
                                    stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    stage_styler.highlight_cell(index, 'SPEC_TYPE',"#92D050") # Light Green
                                else:
                                    v6_stage,v6_spec_type = get_v6_stage_and_spec_type(v7_prod_stage,v6_prod_stage,index)
                                    comment = comment.replace('"_stage"', f'"{v6_stage}"').replace('"_spec_type"', f'"{v6_spec_type}"')
                                    stage_styler.highlight_cell(index, column,color) 
                                    stage_styler.highlight_cell(index, 'SPEC_TYPE',color) 
                                    stage_styler.add_comments( index, comment)
                                    folloup_comment = 'The SPEC_TYPE "{}" is in v7 DEV.'.format(spec_type)
                                    stage_styler.add_comments( index, folloup_comment)
                    if column == "ANALYSIS":
                        for index, value in v7_prod_stage[column].items():
                            color = stage_styler.get_cell_color(index,column)
                            if color =="":
                                if rerun:
                                    JsonData = v7_prod_stage['JsonData'][index]
                                    if JsonData == 'Remove':
                                        stage_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        continue
                                    elif JsonData != "Passed":
                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                        if column in JsonData.keys():
                                            if JsonData[column] == 'Manual Correction':
                                                stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                stage_styler.add_comments( index, comment)
                                                continue
                                            elif JsonData[column] == 'SME Verification':
                                                stage_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                continue
                                            elif JsonData[column] == "No":
                                                stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                    else:
                                        stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        continue
                                v7_name = v7_prod_stage['PRODUCT'][index]
                                v7_grade = v7_prod_stage['GRADE'][index]
                                v7_analysis = v7_prod_stage['ANALYSIS'][index]
                                MD_v6_analysis = Util.get_v6_analysis_from_Tracker(Analysis_MD_Trak,v7_analysis)
                                if MD_v6_analysis:
                                    status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker,v7_name,v7_grade)
                                    if status:
                                        v6_entry = Util.get_v6_row(v6_prod_stage,v6_val['v6_code'],v6_val['v6_grade'])
                                        # Check if any rows are found in v6 file
                                        if not v6_entry.empty:
                                            analysis_present = False
                                            
                                            if any(value in v6_entry['ANALYSIS'].values for value in MD_v6_analysis):
                                                duplicate_check = Util.get_v6_row(v6_prod_stage,v6_val['v6_code'],v6_val['v6_grade'],MD_v6_analysis)
                                                if len(duplicate_check) >1:
                                                    stage_styler.highlight_entire_row(index,"#7030A0")  #Standard Purple color
                                                    comment = 'The ANALYSIS "{}" is single entry in v7 DEV. However, the corresponding  v6 analysis "{}" is double entry in v6 PROD. Hence, marked in Purple.'.format(value,MD_v6_analysis)
                                                    stage_styler.add_comments( index, comment)
                                                else:
                                                    stage_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            else:
                                                stage_styler.highlight_entire_row(index,"#66FFFF")  #teal color
                                                comment = 'The ANALYSIS "{}" is available in v7 DEV. However, its corresponding v6 analysis "{}" is not available in v6 PROD'.format(value,MD_v6_analysis)
                                                stage_styler.add_comments( index, comment)
                                        else:
                                            # pass
                                            print('The PRODUCT Name "{}" is not present in v6 PROD.'.format(value))
                                    else:
                                        # pass
                                        print('The PRODUCT Name "{}" is not present in MD Tracker.'.format(value))
                                else:
                                    stage_styler.highlight_entire_row(index,"#7030A0")  #Standard Purple color
                                    comment = 'The ANALYSIS "{}" is not present in MD Tracker.'.format(value)
                                    stage_styler.add_comments( index, comment)
                else:
                    pass
#=====================================================summary==========================================================
    
    v7_prod_sum = add_manual_columns(v7_prod_sum,rerun=rerun)
    summary_styler = DF_Styler(v7_prod_sum,summary_columns+manual_columns)
    v6_sum_styler = DF_Styler(v6_prod_sum,v6_prod_sum.columns)
    highlight_excess_row_prod(v6_sum_styler,v7_prod_sum,Prod_MD_Traker,prod_column='NAME',grade=False)
    
    # Iterate over the columns in v7_query
    for column in summary_columns: # iterating
        if column in v7_prod_sum.columns:
            if not pd.isna(prod_sum_req.loc[prod_sum_req['Column Name'] == column, 'Bot Instructions'].values[0]):
                instructions = json.loads(prod_sum_req.loc[prod_sum_req['Column Name'] == column, 'Bot Instructions'].values[0])
                # print(instructions)
                if instructions['Type'] == 'column to column':
                    if column == 'NAME':
                        for index, value in v7_prod_sum[column].items():
                            if rerun:
                                JsonData = v7_prod_sum['JsonData'][index]
                                if JsonData == 'Remove':
                                    summary_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                    continue
                                elif JsonData == "Passed":
                                    summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    continue
                            prod,comment,color_ = Util.check_prodname_in_v6(Prod_MD_Traker,v6_prod_sum,value)
                            if prod:
                                summary_styler.highlight_cell(index, column,color_) # Light Green
                            else:
                                summary_styler.highlight_entire_row(index,color_)  
                                summary_styler.add_comments( index, comment) 
                elif instructions['Type'] == 'column to constant':
                    if column == "CODE":
                        const_values = ["sgs","charles river"]
                        for index, value in v7_prod_sum[column].items():
                            value = str(value)
                            color = summary_styler.get_cell_color(index,column)
                            if color =="":
                                if rerun:
                                    JsonData = v7_prod_sum['JsonData'][index]
                                    if JsonData == 'Remove':
                                        summary_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        continue
                                    elif JsonData != "Passed":
                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                        if column in JsonData.keys():
                                            if JsonData[column] == 'Manual Correction':
                                                summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                summary_styler.add_comments( index, comment)
                                                continue
                                            elif JsonData[column] == 'SME Verification':
                                                summary_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                continue
                                            elif JsonData[column] == "No":
                                                summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                    else:
                                        summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        continue
                                prod_name = v7_prod_sum['NAME'][index]
                                prod,v6_entry, color_ = Util.check_prodname_in_v6(Prod_MD_Traker,v6_prod_sum,prod_name)
                                if prod:
                                    v6_code = str(v6_entry['CODE'].values[0])
                                    # print(index,value,type(value))
                                    if value.lower() in const_values:
                                        if value == v6_code:
                                            summary_styler.highlight_cell(index, column, "#92D050")  # Light Green
                                        elif v6_code.lower() in const_values:
                                            summary_styler.highlight_cell(index, column,"#FF0000") # red color
                                            if value == '': value = 'Blank'
                                            comment = 'The CODE is "{}" in v7 DEV and "{}" in v6 PROD'.format(value,v6_code)
                                            summary_styler.add_comments( index, comment)
                                        else:
                                            summary_styler.highlight_cell(index, column,"#00B0F0")
                                            if value == '': value = 'Blank'
                                            comment = 'The CODE is "{}" in v7 DEV and "{}" in v6 PROD. Hence, requires SME verification.'.format(value,v6_code)
                                            summary_styler.add_comments( index, comment)

                                    elif v6_code.lower() in const_values:
                                        summary_styler.highlight_cell(index, column,"#FF0000") # red color # Light Green
                                        if value == '': value = 'Blank'
                                        comment = 'The CODE is "{}" in v7 DEV and "{}" in v6 PROD'.format(value,v6_code)
                                        summary_styler.add_comments( index, comment)
                                    else:
                                        summary_styler.highlight_cell(index, column,"#00B0F0")
                                        if value == '': value = 'Blank'
                                        comment = 'The CODE is "{}" in v7 DEV and "{}" in v6 PROD. Hence, requires SME verification.'.format(value,v6_code)
                                        summary_styler.add_comments( index, comment)
                                else:
                                    summary_styler.highlight_entire_row(index,color_)  
                                    summary_styler.add_comments( index, comment) 
                    if column == "SAMPLE_PLAN":
                        for index, value in v7_prod_sum[column].items():
                            color = summary_styler.get_cell_color(index,column)
                            if color =="":
                                if rerun:
                                    JsonData = v7_prod_sum['JsonData'][index]
                                    if JsonData == 'Remove':
                                        summary_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        continue
                                    elif JsonData != "Passed":
                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                        if column in JsonData.keys():
                                            if JsonData[column] == 'Manual Correction':
                                                summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                summary_styler.add_comments( index, comment)
                                                continue
                                            elif JsonData[column] == 'SME Verification':
                                                summary_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                continue
                                            elif JsonData[column] == "No":
                                                summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                    else:
                                        summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        continue
                                if value == "":
                                    summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                else:
                                    summary_styler.highlight_cell(index, column,"#FF0000") # red color
                                    comment = 'The SAMPLE_PLAN is "{}" in v7 DEV.'.format(value)
                                    summary_styler.add_comments( index, comment)
                            
                elif instructions['Type'] == 'column to others':
                    if column == "T_PH_CU_DOSAGE":
                        for index, value in v7_prod_sum[column].items():
                            color = summary_styler.get_cell_color(index,column)
                            if color =="":
                                if rerun:
                                    JsonData = v7_prod_sum['JsonData'][index]
                                    if JsonData == 'Remove':
                                        summary_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        continue
                                    elif JsonData != "Passed":
                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                        if column in JsonData.keys():
                                            if JsonData[column] == 'Manual Correction':
                                                summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                summary_styler.add_comments( index, comment)
                                                continue
                                            elif JsonData[column] == 'SME Verification':
                                                summary_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                continue
                                            elif JsonData[column] == "No":
                                                summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                    else:
                                        summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        continue
                                prod_spec = v7_prod_sum['NAME'][index]
                                SM_from_spec = find_prod_for_dosage(prod_spec)
                                if SM_from_spec:
                                    if SM_from_spec == 'BLANK':
                                        if value == "":
                                            summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        else:
                                            summary_styler.highlight_cell(index, column,"#FF0000") # red color
                                            comment = 'The T_PH_CU_DOSAGE is "{}" in v7 DEV. It should be BLANK as per MD Protocol.'.format(value)
                                            summary_styler.add_comments( index, comment)
                                    elif SM_from_spec == 'ETD_R':
                                        if value == 'CIA':
                                            result = get_spectype_stage_from_specification(prod_spec,stage_styler,spec_type="CIA",stage="CIA_RECEIPT")
                                            
                                            if result is True:
                                                summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            else:
                                                summary_styler.highlight_cell(index, column,result['color']) # red color
                                                summary_styler.add_comments( index, result['comment'])
                                        elif value == 'RM':
                                            result = get_spectype_stage_from_specification(prod_spec,stage_styler,spec_type="RM",stage="RM_RECEIPT")
                                            if result is True:
                                                summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                            else:
                                                summary_styler.highlight_cell(index, column,result['color']) # red color
                                                summary_styler.add_comments( index, result['comment'])
                                        else:
                                          summary_styler.highlight_cell(index, column,"#FF0000") # red color
                                          comment = 'The T_PH_CU_DOSAGE is "{}" in v7 DEV. It should be "CIA or RM" as per MD Protocol.'.format(value)
                                          summary_styler.add_comments( index, comment)  
                                    
                                    
                                    elif SM_from_spec == value:
                                        summary_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    else:
                                      summary_styler.highlight_cell(index, column,"#FF0000") # red color
                                      comment = 'The T_PH_CU_DOSAGE is "{}" in v7 DEV. It should be "{}" as per MD Protocol.'.format(value,SM_from_spec)
                                      summary_styler.add_comments( index, comment)
                                else:
                                  summary_styler.highlight_cell(index, column,"#FF0000") # red color
                                  comment = 'Unknown T_PH_CU_DOSAGE "{}" in v7 DEV.'.format(value)
                                  summary_styler.add_comments( index, comment) 
                          
                else:
                    pass
        else:
            pass
    return {"v7":{'stage':stage_styler,'summary':summary_styler},"v6":{'stage':v6_stage_styler,'summary':v6_sum_styler}}
#=========================================================Compound ETDF==================================================
def compare_PRODUCT_compound(v7_comp_ETDF,v6_comp_ETDF,ETD_styler,column, rerun=False):
    for index, value in v7_comp_ETDF[column].items():
        color = ETD_styler.get_cell_color(index,column)
        if color =="":
            if rerun:
                JsonData = v7_comp_ETDF['JsonData'][index]
                if JsonData == 'Remove':
                    ETD_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                    continue
                elif JsonData != "Passed":
                    JsonData = json.loads(JsonData.replace("'", "\""))
                    if column in JsonData.keys():
                        if JsonData[column] == 'Manual Correction':
                            ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                            continue
                        elif JsonData[column] == 'SME Verification':
                            ETD_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                            comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                            ETD_styler.add_comments( index, comment)
                            continue
                        elif JsonData[column] == "No":
                            ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                            continue
                        if 'ITEM' in JsonData.keys():
                            if JsonData['ITEM'] == 'Manual Correction':
                                ETD_styler.highlight_cell(index, 'ITEM',"#92D050") # Light Green
                                continue
                            elif JsonData['ITEM'] == 'SME Verification':
                                ETD_styler.highlight_cell(index, 'ITEM',"#00B0F0")  # SME blue
                                comment = f'The ITEM is unsure, Hence marked in blue for SME verification.'
                                ETD_styler.add_comments( index, comment)
                                continue
                            elif JsonData['ITEM'] == "No":
                                ETD_styler.highlight_cell(index, 'ITEM',"#92D050") # Light Green
                                continue
                else:
                    ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                    ETD_styler.highlight_cell(index, 'ITEM',"#92D050") # Light Green  
                    continue
            status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker,value)
            if status:
                item = v7_comp_ETDF['ITEM'][index]
                MD_Trak_v6_code = v6_val['v6_code']
                v6_entry = Util.get_v6_row(v6_comp_ETDF,MD_Trak_v6_code,v6_val['v6_grade'],product="PRODUCT_SPEC").astype(str)
                if not v6_entry.empty:
                    item_filtered = v6_entry[v6_entry['T_PH_ITEM_CODE']== str(item.replace("ETD_",""))]
                    if len(item_filtered) > 0:
                        ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                        ETD_styler.highlight_cell(index, 'ITEM',"#92D050") # Light Green                                        
                    else:
                        ETD_styler.highlight_entire_row(index,"#66FFFF")  #teal color
                        comment = f'The ITEM "{item}" is not available in v6 PROD to perform the comparison.' 
                        ETD_styler.add_comments(index, comment) 
                else:
                   ETD_styler.highlight_entire_row(index,"#66FFFF")  #teal color
                   comment = f'The ITEM "{item}" is not available in v6 PROD to perform the comparison.' 
                   ETD_styler.add_comments(index, comment)
            else:
               ETD_styler.highlight_entire_row(index,"#7030A0")  #Standard Purple color
               comment = 'The PRODUCT Name "{}" is not available in Product MD Tracker.'.format(value) 
               ETD_styler.add_comments(index, comment) 
def compare_COMPOUND_compound(v7_comp_ETDF,v6_comp_ETDF,ETD_styler,column,compns, rerun=False):
    for index, value in v7_comp_ETDF[column].items():
        color = ETD_styler.get_cell_color(index, column)
        if color == "":
            if rerun:
                JsonData = v7_comp_ETDF['JsonData'][index]
                if JsonData == 'Remove':
                    ETD_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                    continue
                elif JsonData != "Passed":
                    JsonData = json.loads(JsonData.replace("'", "\""))
                    if column in JsonData.keys():
                        if JsonData[column] == 'Manual Correction':
                            ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                            comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                            ETD_styler.add_comments( index, comment)
                            continue
                        elif JsonData[column] == 'SME Verification':
                            ETD_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                            continue
                        elif JsonData[column] == "No":
                            ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                            continue
                else:
                    ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                    continue
            if value in compns:
                ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
            elif "LENGTH" in value:
                ETD_styler.highlight_cell(index, column,"#FF0000") # red color
                corrected = value.replace('GTH',"")
                comment = f'The COMPOUND is "{value}" in v7 DEV. It should be "{corrected}" as per site instruction for ETD_F Prefix Products.'
                ETD_styler.add_comments(index, comment)
            else:
                ETD_styler.highlight_cell(index, column,"#7030A0")  #Standard Purple color
                comment = f'The COMPOUND is "{value}" in v7 DEV.It is apart from the mentioned compound list.' 
                ETD_styler.add_comments(index, comment)
def compare_DESCRIPTION_compound(v7_comp_ETDF,v6_comp_ETDF,ETD_styler,column, rerun=False):
    for index, value in v7_comp_ETDF[column].items():
        color = ETD_styler.get_cell_color(index, column)
        if color == "":
            if rerun:
                JsonData = v7_comp_ETDF['JsonData'][index]
                if JsonData == 'Remove':
                    ETD_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                    continue
                elif JsonData != "Passed":
                    JsonData = json.loads(JsonData.replace("'", "\""))
                    if column in JsonData.keys():
                        if JsonData[column] == 'Manual Correction':
                            ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                            comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                            ETD_styler.add_comments( index, comment)
                            continue
                        elif JsonData[column] == 'SME Verification':
                            ETD_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                            continue
                        elif JsonData[column] == "No":
                            ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                            continue
                else:
                    ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                    continue
            item = v7_comp_ETDF['ITEM'][index].replace('ETD_', '')
            df = Tabelle3[Tabelle3['Number']== item]
            if len(df)>0:
                AL_desc = df['Description'].values[0]
                if value.replace("Item Code ","") == AL_desc:
                    ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                else:
                    ETD_styler.highlight_cell(index, column,"#FF0000") # red color
                    comment = f'The DESCRIPTION is "{value}" in v7 DEV. It should be "{AL_desc}" as per Artikel Liste file.' 
                    ETD_styler.add_comments(index, comment)
            else:
                item = v7_comp_ETDF['ITEM'][index]
                prod = v7_comp_ETDF['PRODUCT'][index]
                status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker,prod)
                if status:
                    MD_Trak_v6_code = v6_val['v6_code']
                    v6_entry = Util.get_v6_row(v6_comp_ETDF,MD_Trak_v6_code,v6_val['v6_grade'],product="PRODUCT_SPEC").astype(str)
                    if not v6_entry.empty:
                        item_filtered = v6_entry[v6_entry['T_PH_ITEM_CODE']== str(item.replace("ETD_",""))]
                        if len(item_filtered) > 0:
                            v6_desc = item_filtered['DESCRIPTION'].values[0]
                            if value.replace("Item Code ","") == v6_desc:
                                ETD_styler.highlight_cell(index, column,"#92D050") # Light Green
                            else:
                                ETD_styler.highlight_cell(index, column,"#FF0000") # red color
                                comment = f'The DESCRIPTION is "{value}" in v7 DEV. The Item Code "{item}" is unavailable in Artikel liste file. It should be "{v6_desc}" as per v6 PROD.' 
                                ETD_styler.add_comments(index, comment)
def compound_ETDF_comparison(v7_comp_ETDF,v6_comp_ETDF, rerun=False):
    v7_comp_ETDF = add_manual_columns(v7_comp_ETDF,rerun=rerun)
    Comp_ETDF_styler = DF_Styler(v7_comp_ETDF,prod_comp_col_ETDF+manual_columns)
    v6_comp_ETDF_styler = DF_Styler(v6_comp_ETDF,v6_comp_ETDF.columns)
    highlight_excess_row_prod(v6_comp_ETDF_styler,v7_comp_ETDF,Prod_MD_Traker,grade=False,compound=True)
    
    columns_to_check = ['PRODUCT', 'COMPOUND','ITEM','VALUE','DESCRIPTION']
    # Find indices of duplicate rows
    duplicate_indices = v7_comp_ETDF[v7_comp_ETDF.duplicated(subset=columns_to_check, keep=False)].index
    for i in duplicate_indices:
        Comp_ETDF_styler.highlight_entire_row(i,"#FBE2D5")  #Duplicate Scenario due to save as in the Product compounds tab
        item = v7_comp_ETDF['ITEM'][i]
        prod = v7_comp_ETDF['PRODUCT'][i]
        comment = f'The ITEM Code "{item}" along with its Compound, Value and Description has been duplicated within the Product "{prod}".'
        Comp_ETDF_styler.add_comments(i, comment) 
    # Iterate over the columns in v7_query
    for column in prod_comp_col_ETDF: # iterating
        if column in v7_comp_ETDF.columns:
            if not pd.isna(prod_comp_req_ETDF.loc[prod_comp_req_ETDF['Column Name'] == column, 'Bot Instructions'].values[0]):
                instructions = json.loads(prod_comp_req_ETDF.loc[prod_comp_req_ETDF['Column Name'] == column, 'Bot Instructions'].values[0])
                # print(instructions)
                if instructions['Type'] == 'column to column':
                    if column == 'PRODUCT':
                        compare_PRODUCT_compound(v7_comp_ETDF,v6_comp_ETDF,Comp_ETDF_styler,column,rerun=rerun)
                    if column == 'VALUE':
                        for index, value in v7_comp_ETDF[column].items():
                            color = Comp_ETDF_styler.get_cell_color(index, column)
                            if color == "":
                                Comp_ETDF_styler.highlight_cell(index,column,"#7030A0")  #Standard Purple color
                    if column == 'COMPOUND':
                        compns = ['TARGET_LEN','QS_MAX_LEN','QS_MIN_LEN','QS_UNIT_LEN','ATTACHMENT_STR_MAX_1','ATTACHMENT_STR_MAX_2','ATTACHMENT_STR_MIN_1',
                                  'ATTACHMENT_STR_MIN_2','DISPLACE_PEAK_WD','TARGET_WIDTH','QS_UNIT_WIDTH','QS_MIN_WIDTH','QS_MAX_WIDTH']
                        compare_COMPOUND_compound(v7_comp_ETDF,v6_comp_ETDF,Comp_ETDF_styler,column,compns)
                    if column == 'DESCRIPTION':
                        compare_DESCRIPTION_compound(v7_comp_ETDF,v6_comp_ETDF,Comp_ETDF_styler,column)
                else: # type split
                    pass
        else: # Bot instructions
            pass
    return  {"v7":{'Compds_ETDF':Comp_ETDF_styler},"v6":{'Compds':v6_comp_ETDF_styler}}
#=========================================================Compound ETDN==================================================
def compound_ETDN_comparison(v7_comp_ETDN,v6_comp_ETDN, rerun=False):
    v7_comp_ETDN = add_manual_columns(v7_comp_ETDN,rerun=rerun)
    Comp_ETDN_styler = DF_Styler(v7_comp_ETDN,prod_comp_col_ETDN+manual_columns)
    v6_comp_ETDN_styler = DF_Styler(v6_comp_ETDN,v6_comp_ETDN.columns)
    highlight_excess_row_prod(v6_comp_ETDN_styler,v7_comp_ETDN,Prod_MD_Traker,grade=False,compound=True)
    
    columns_to_check = ['PRODUCT', 'COMPOUND','ITEM','VALUE','DESCRIPTION']
    # Find indices of duplicate rows
    duplicate_indices = v7_comp_ETDN[v7_comp_ETDN.duplicated(subset=columns_to_check, keep=False)].index
    for i in duplicate_indices:
        Comp_ETDN_styler.highlight_entire_row(i,"#FBE2D5")  #Duplicate Scenario due to save as in the Product compounds tab
        item = v7_comp_ETDN['ITEM'][i]
        prod = v7_comp_ETDN['PRODUCT'][i]
        comment = f'The ITEM Code "{item}" along with its Compound, Value and Description has been duplicated within the Product "{prod}".'
        Comp_ETDN_styler.add_comments(i, comment) 
    # Iterate over the columns in v7_query
    for column in prod_comp_col_ETDN: # iterating
        if column in v7_comp_ETDN.columns:
            if not pd.isna(prod_comp_req_ETDF.loc[prod_comp_req_ETDF['Column Name'] == column, 'Bot Instructions'].values[0]):
                instructions = json.loads(prod_comp_req_ETDF.loc[prod_comp_req_ETDF['Column Name'] == column, 'Bot Instructions'].values[0])
                # print(instructions)
                if instructions['Type'] == 'column to column':
                    if column == 'PRODUCT':
                        compare_PRODUCT_compound(v7_comp_ETDN,v6_comp_ETDN,Comp_ETDN_styler,column, rerun=rerun)
                    if column == 'VALUE':
                        for index, value in v7_comp_ETDN[column].items():
                            color = Comp_ETDN_styler.get_cell_color(index, column)
                            if color == "":
                                if rerun:
                                    JsonData = v7_comp_ETDN['JsonData'][index]
                                    if JsonData == 'Remove':
                                        Comp_ETDN_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        continue
                                    elif JsonData != "Passed":
                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                        if column in JsonData.keys():
                                            if JsonData[column] == 'Manual Correction':
                                                Comp_ETDN_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                            elif JsonData[column] == 'SME Verification':
                                                Comp_ETDN_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                Comp_ETDN_styler.add_comments( index, comment)
                                                continue
                                            elif JsonData[column] == "No":
                                                Comp_ETDN_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                    else:
                                        Comp_ETDN_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        continue
                                v7_compound = v7_comp_ETDN['COMPOUND'][index]
                                if v7_compound in ["QS_MAX_DRILL_HOLE","QS_MIN_DRILL_HOLE"]:
                                    if str(value) == "0.01":
                                        Comp_ETDN_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    else:
                                       Comp_ETDN_styler.highlight_cell(index, column,"#FF0000") # red color 
                                       comment = f'The VALUE of {v7_compound} is "{str(value)}" in v7 DEV. It should be "0.01" as per site instruction.' 
                                       Comp_ETDN_styler.add_comments(index, comment)
                                elif v7_compound in ["QS_MAX_SIZE_WIRE","QS_MIN_SIZE_WIRE"]:
                                    if str(value) == "1":
                                        Comp_ETDN_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    else:
                                       Comp_ETDN_styler.highlight_cell(index, column,"#FF0000") # red color 
                                       comment = f'The VALUE of {v7_compound} is "{str(value)}" in v7 DEV. It should be "1" as per site instruction.' 
                                       Comp_ETDN_styler.add_comments(index, comment)
                                elif v7_compound in ["QS_UNIT_DRILL_HOLE","QS_UNIT_SIZE_WIRE"]:
                                    if str(value) == "COUNT":
                                        Comp_ETDN_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    else:
                                       Comp_ETDN_styler.highlight_cell(index, column,"#FF0000") # red color 
                                       comment = f'The VALUE of {v7_compound} is "{str(value)}" in v7 DEV. It should be "COUNT" as per site instruction.' 
                                       Comp_ETDN_styler.add_comments(index, comment)
                                elif v7_compound == "TARGET_DRILL_HOLE":
                                    itemcode = v7_comp_ETDN['ITEM'][index]
                                    val = '0.'+str(itemcode[10:12])
                                    if str(value) == val:
                                        Comp_ETDN_styler.highlight_cell(index, column,"#92D050") # Light Green
                                    else:
                                       Comp_ETDN_styler.highlight_cell(index, column,"#FF0000") # red color 
                                       comment = f'The VALUE of {v7_compound} is "{str(value)}" in v7 DEV. It should be "{val}" as per site instruction.' 
                                       Comp_ETDN_styler.add_comments(index, comment)
                                elif v7_compound == "TARGET_SIZE_WIRE":
                                    v7_product = v7_comp_ETDN['PRODUCT'][index]
                                    # Regular expression pattern
                                    pattern = r'_(\d{1,2})M'
                                    match = re.search(pattern, v7_product)
                                    if match:
                                        val = str(match.group(1))
                                        if str(value) == val:
                                            Comp_ETDN_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        else:
                                            Comp_ETDN_styler.highlight_cell(index, column,"#FF0000") # red color 
                                            comment = f'The VALUE of {v7_compound} is "{str(value)}" in v7 DEV. It should be "{val}" as per site instruction.' 
                                            Comp_ETDN_styler.add_comments(index, comment)
                                    else:
                                        Comp_ETDN_styler.highlight_cell(index, column,"#7030A0") #Standard Purple color
                                        comment = f"The VALUE, the product {v7_product} doesn't have M pattern." 
                                        Comp_ETDN_styler.add_comments(index, comment)
                                else:
                                    Comp_ETDN_styler.highlight_cell(index, column,"#7030A0") #Standard Purple color
                                    comment = f"The Compound is marked in purple (Apart from mentioned compound). Similiarly The VALUE is marked in Purple." 
                                    Comp_ETDN_styler.add_comments(index, comment)
                                       
                    if column == 'COMPOUND':
                        compns = ['QS_UNIT_DRILL_HOLE','TARGET_DRILL_HOLE','QS_MAX_DRILL_HOLE','QS_MIN_DRILL_HOLE','QS_UNIT_SIZE_WIRE',
                                    'TARGET_SIZE_WIRE','QS_MAX_SIZE_WIRE','QS_MIN_SIZE_WIRE']
                        compare_COMPOUND_compound(v7_comp_ETDN,v6_comp_ETDN,Comp_ETDN_styler,column,compns)
                    if column == 'DESCRIPTION':
                        compare_DESCRIPTION_compound(v7_comp_ETDN,v6_comp_ETDN,Comp_ETDN_styler,column)
                else: # type split
                    pass
        else: # Bot instructions
            pass
    return  {"v7":{'Compds_ETDN':Comp_ETDN_styler},"v6":{'Compds':v6_comp_ETDN_styler}}
#=========================================================Compound ETDS==================================================

def compound_ETDS_comparison(v7_comp_ETDS,v6_comp_ETDS, rerun=False):
    v7_comp_ETDS = add_manual_columns(v7_comp_ETDS,rerun=rerun)
    Comp_ETDS_styler = DF_Styler(v7_comp_ETDS,prod_comp_col_ETDS+manual_columns)
    v6_comp_ETDS_styler = DF_Styler(v6_comp_ETDS,v6_comp_ETDS.columns)
    highlight_excess_row_prod(v6_comp_ETDS_styler,v7_comp_ETDS,Prod_MD_Traker,grade=False,compound=True)
    
    columns_to_check = ['PRODUCT', 'COMPOUND','ITEM','VALUE','DESCRIPTION']
    # Find indices of duplicate rows
    duplicate_indices = v7_comp_ETDS[v7_comp_ETDS.duplicated(subset=columns_to_check, keep=False)].index
    for i in duplicate_indices:
        Comp_ETDS_styler.highlight_entire_row(i,"#FBE2D5")  #Duplicate Scenario due to save as in the Product compounds tab
        item = v7_comp_ETDS['ITEM'][i]
        prod = v7_comp_ETDS['PRODUCT'][i]
        comment = f'The ITEM Code "{item}" along with its Compound, Value and Description has been duplicated within the Product "{prod}".'
        Comp_ETDS_styler.add_comments(i, comment) 
    # Iterate over the columns in v7_query
    for column in prod_comp_col_ETDS: # iterating
        if column in v7_comp_ETDS.columns:
            if not pd.isna(prod_comp_req_ETDF.loc[prod_comp_req_ETDF['Column Name'] == column, 'Bot Instructions'].values[0]):
                instructions = json.loads(prod_comp_req_ETDF.loc[prod_comp_req_ETDF['Column Name'] == column, 'Bot Instructions'].values[0])
                # print(instructions)
                if instructions['Type'] == 'column to column':
                    if column == 'PRODUCT':
                        compare_PRODUCT_compound(v7_comp_ETDS,v6_comp_ETDS,Comp_ETDS_styler,column, rerun=rerun)
                    if column == 'VALUE':
                        for index, value in v7_comp_ETDS[column].items():
                            color = Comp_ETDS_styler.get_cell_color(index, column)
                            if color == "":
                                if rerun:
                                    JsonData = v7_comp_ETDS['JsonData'][index]
                                    if JsonData == 'Remove':
                                        Comp_ETDS_styler.highlight_entire_row(index,"#001D58") # for removed itemcode
                                        continue
                                    elif JsonData != "Passed":
                                        JsonData = json.loads(JsonData.replace("'", "\""))
                                        if column in JsonData.keys():
                                            if JsonData[column] == 'Manual Correction':
                                                Comp_ETDS_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                            elif JsonData[column] == 'SME Verification':
                                                Comp_ETDS_styler.highlight_cell(index, column,"#00B0F0")  # SME blue
                                                comment = f'The {column} is unsure, Hence marked in blue for SME verification.'
                                                Comp_ETDS_styler.add_comments( index, comment)
                                                continue
                                            elif JsonData[column] == "No":
                                                Comp_ETDS_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                continue
                                    else:
                                        Comp_ETDS_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        continue
                                v7_product = v7_comp_ETDS['PRODUCT'][index]
                                v7_compound = v7_comp_ETDS['COMPOUND'][index]
                                if v7_compound == "SIZE_USP":
                                    pattern = r'_([\d-]{1,3})_'
                                    match = re.search(pattern, v7_product)
                                    if match:
                                        val = str(match.group(1))
                                        if str(value) == val:
                                            Comp_ETDS_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        else:
                                           Comp_ETDS_styler.highlight_cell(index, column,"#FF0000") # red color 
                                           comment = f'The VALUE of {v7_compound} is "{str(value)}" in v7 DEV. It should be "{val}" as per site instruction.' 
                                           Comp_ETDS_styler.add_comments(index, comment)
                                elif v7_compound == "METRIC_LENGTH":
                                    v7_description = v7_comp_ETDS['DESCRIPTION'][index]
                                    pattern = r' M([\d.]{1,3}) '
                                    match = re.search(pattern, v7_description)
                                    if match:
                                        val = str(match.group(1))
                                        if str(value) == val:
                                            Comp_ETDS_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        else:
                                           Comp_ETDS_styler.highlight_cell(index, column,"#FF0000") # red color 
                                           comment = f'The VALUE of {v7_compound} is "{str(value)}" in v7 DEV. It should be "{val}" as per site instruction.' 
                                           Comp_ETDS_styler.add_comments(index, comment)
                                elif v7_compound in ["FACTOR","TARGET"]:
                                    item = v7_comp_ETDS['ITEM'][index]
                                    status, v6_val = Util.get_product_Tracker_row(Prod_MD_Traker,v7_product)
                                    if status:
                                        MD_Trak_v6_code = v6_val['v6_code']
                                        v6_entry = Util.get_v6_row(v6_comp_ETDS,MD_Trak_v6_code,v6_val['v6_grade'],product="PRODUCT_SPEC").astype(str)
                                        if not v6_entry.empty:
                                            v6_v7_coumpound = {"FACTOR":"FACTOR","TARGET":"TARGET","SIZE_USP":"SIZE","METRIC_LENGTH":"METRIC","TERM":"TERM"}
                                            # Extract the target value
                                            target_name = str(v6_v7_coumpound[v7_compound])
                                            # Check if the target_name exists in the 'X_TARGET_NAME' column
                                            if target_name in v6_entry['X_TARGET_NAME'].values:
                                                # Filter the data
                                                item_filtered = v6_entry[
                                                    (v6_entry['T_PH_ITEM_CODE'] == str(item.replace("ETD_", ""))) &
                                                    (v6_entry['X_TARGET_NAME'] == target_name)
                                                ]
                                                # item_filtered = v6_entry.iloc[(v6_entry['T_PH_ITEM_CODE']== str(item.replace("ETD_",""))) & (v6_entry['X_TARGET_NAME']== str(v6_v7_coumpound[X_TARGET_NAME[v7_compound]]))]
                                                if len(item_filtered) > 0:
                                                    v6_val = str(item_filtered['X_TARGET_AMOUNT'].values[0])
                                                    if str(value) == v6_val:
                                                        Comp_ETDS_styler.highlight_cell(index, column,"#92D050") # Light Green
                                                    else:
                                                        Comp_ETDS_styler.highlight_cell(index, column,"#FF0000") # red color 
                                                        comment = f'The VALUE is {str(value)} in v7 DEV. It should be {v6_val} as per v6 X_TARGET_AMOUNT.' 
                                                        Comp_ETDS_styler.add_comments(index, comment)
                                                else:
                                                    Comp_ETDS_styler.highlight_cell(index, column,"#7030A0") #Standard Purple color
                                                    comment = f'The VALUE is {str(value)} in v7 DEV. The compound {v7_compound} not available in v6 X_TARGET_AMOUNT .' 
                                                    Comp_ETDS_styler.add_comments(index, comment)
                                            else:
                                                print(v7_product,v7_compound,target_name,v6_entry['X_TARGET_NAME'].values)
                                elif v7_compound == "TERM": 
                                    exception_products = {'ETD_S_VIC-RAP_UND_6-0_NVC_PF':'ETD_S_HYDRO_1295608','ETD_S_VIC-RAP_UND_5-0_NVC_PF':'ETD_S_HYDRO_1295508'}
                                    if v7_product in list(exception_products.keys()):
                                        val = exception_products[v7_product]
                                        if value == val:
                                            Comp_ETDS_styler.highlight_cell(index, column,"#92D050") # Light Green
                                        else:
                                            Comp_ETDS_styler.highlight_cell(index, column,"#FF0000") # red color 
                                            comment = f'The VALUE is {str(value)} in v7 DEV. It should be {val} as per site instruction.' 
                                            Comp_ETDS_styler.add_comments(index, comment)
                                else:
                                    Comp_ETDS_styler.highlight_cell(index, column,"#7030A0") #Standard Purple color
                                    comment = f"The Compound is marked in purple (Apart from mentioned compound). Similiarly The VALUE is marked in Purple." 
                                    Comp_ETDS_styler.add_comments(index, comment)
                    if column == 'COMPOUND':
                        compns = ['FACTOR','TARGET','SIZE_USP','METRIC_LENGTH','TERM']
                        compare_COMPOUND_compound(v7_comp_ETDS,v6_comp_ETDS,Comp_ETDS_styler,column,compns)
                    if column == 'DESCRIPTION':
                        compare_DESCRIPTION_compound(v7_comp_ETDS,v6_comp_ETDS,Comp_ETDS_styler,column)
                else: # type split
                    pass
        else: # Bot instructions
            pass
    return  {"v7":{'Compds_ETDS':Comp_ETDS_styler},"v6":{'Compds':v6_comp_ETDS_styler}}
def create_zip_file(file_paths, zip_filename='PRODDUCT_Highlighted_files.zip'):
    zip_path = os.path.join('uploads', zip_filename)
    with zipfile.ZipFile(zip_path, 'w') as zipf:
        for file_path in file_paths:
            zipf.write(file_path, os.path.basename(file_path))
            # os.remove(file_path)  # Clean up individual files after zipping
    return zip_path
def process_Product_files(v6_file,v7_file,IC_file,rerun=False):
    # Read all sheets from the v6 Excel file
    v6_sheets = pd.read_excel(v6_file, sheet_name=None, keep_default_na=False)
    v6_prod_sum = v6_sheets['v6 PROD - Product Summary'].astype(str) 
    v6_grade = v6_sheets['v6 PROD - Product Grade'].astype(str)
    v6_grade = DF_Styler(v6_grade,list(v6_grade.columns))
    v6_prod_stage = v6_sheets['v6 PROD - Product Grade Stage'].astype(str)
    v6_prod_spec = v6_sheets['v6 PROD - Product Specification'].astype(str)
    if 'v6 PROD - IC Dimensions' in v6_sheets.keys():
        v6_comp = v6_sheets['v6 PROD - IC Dimensions'].astype(str) 
    else:
        v6_comp = None

    v7_sheets = pd.read_excel(v7_file, sheet_name=None, keep_default_na=False)
    v7_prod_sum = v7_sheets['v7 DEV - Product Summary'].astype(str)
    if 'v7 DEV - Product Grade' in v7_sheets.keys():
        v7_Grade = v7_sheets['v7 DEV - Product Grade'].astype(str)
        v7_Grade = add_manual_columns(v7_Grade)
        v7_Grade = DF_Styler(v7_Grade, list(v7_Grade.columns))
    else:
        v7_Grade = None
    
    v7_prod_stage = v7_sheets['v7 DEV - Product Grade Stage'].astype(str)
    v7_prod_spec = v7_sheets['v7 DEV - Product Specification'].astype(str)
    v7_comp_ETDS = v7_sheets['v7 DEV - ETD_S Prdt Cmpds Item'].astype(str) if 'v7 DEV - ETD_S Prdt Cmpds Item' in v7_sheets.keys() else None
    v7_comp_ETDF = v7_sheets['v7 DEV - ETD_F Prdt Cmpds Item'].astype(str) if 'v7 DEV - ETD_F Prdt Cmpds Item' in v7_sheets.keys() else None
    v7_comp_ETDN = v7_sheets['v7 DEV - ETD_N Prdt Cmpds Item'].astype(str) if 'v7 DEV - ETD_N Prdt Cmpds Item' in v7_sheets.keys() else None
    prefix = ""
    if 'v7 DEV - ETD_S Product Compds' in v7_sheets.keys():
        v7_compound_ETDS = v7_sheets['v7 DEV - ETD_S Product Compds'].astype(str) 
        v7_compound_ETDS = add_manual_columns(v7_compound_ETDS) 
        v7_compound_ETDS = DF_Styler(v7_compound_ETDS, list(v7_compound_ETDS.columns))
        prefix = "ETD_S_"
    else:
        v7_compound_ETDS =None
    if 'v7 DEV - ETD_F Product Compds' in v7_sheets.keys():
        v7_compound_ETDF = v7_sheets['v7 DEV - ETD_F Product Compds'].astype(str)
        v7_compound_ETDF = add_manual_columns(v7_compound_ETDF) 
        v7_compound_ETDF = DF_Styler(v7_compound_ETDF, list(v7_compound_ETDF.columns)) 
        prefix = "ETD_F_"
    else:
        v7_compound_ETDF = None
    if 'v7 DEV - ETD_N Product Compds' in v7_sheets.keys():
        v7_compound_ETDN = v7_sheets['v7 DEV - ETD_N Product Compds'].astype(str)  
        v7_compound_ETDN = add_manual_columns(v7_compound_ETDN)
        v7_compound_ETDN = DF_Styler(v7_compound_ETDN, list(v7_compound_ETDN.columns))
        prefix = "ETD_N_"
    else:
        v7_compound_ETDN = None
    
    IC_sheets = pd.read_excel(IC_file, sheet_name=None, keep_default_na=False)
    v7_IC_summary = IC_sheets[list(IC_sheets.keys())[0]].astype(str)
    v7_IC_spec = IC_sheets[list(IC_sheets.keys())[1]].astype(str)
    stage_summary_styler = stage_and_summary_comparison(v7_prod_stage, v6_prod_stage, v7_prod_sum, v6_prod_sum, v7_IC_spec, v7_IC_summary,rerun=rerun)
    spec_styler = specification_comparison(v7_prod_spec, v6_prod_spec, v7_IC_spec, v7_IC_summary,rerun=rerun)
    if v7_comp_ETDF is not None:
        comp_styler = compound_ETDF_comparison(v7_comp_ETDF, v6_comp,rerun=rerun) 
    elif v7_comp_ETDN is not None:
        comp_styler = compound_ETDN_comparison(v7_comp_ETDN, v6_comp,rerun=rerun)  
    elif v7_comp_ETDS is not None:
        comp_styler = compound_ETDS_comparison(v7_comp_ETDS, v6_comp,rerun=rerun)
    else:
        comp_styler = None
    return stage_summary_styler, spec_styler, comp_styler, prefix, {"v7_comp_ETDF" : v7_comp_ETDF, "v7_compound_ETDF" : v7_compound_ETDF,
                                                                    "v7_comp_ETDN" : v7_comp_ETDN, "v7_compound_ETDN" : v7_compound_ETDN,
                                                                    "v7_comp_ETDS" : v7_comp_ETDS, "v7_compound_ETDS" : v7_compound_ETDS,
                                                                    "v7_Grade" : v7_Grade, "v6_grade" : v6_grade, "v6_comp" : v6_comp}
if __name__ == '__main__':
    v6_file = pd.ExcelFile("sample files\\product v6 Query Results.xlsx")
    v7_file = pd.ExcelFile("sample files\\product v7 Query Results.xlsx")
    IC_file = pd.ExcelFile("sample files\\Highlighted_V7_DEV_MedTech Observations_Second Trial run.xlsx")
    if v6_file is not None and v7_file is not None and IC_file is not None:
        stage_summary_styler, spec_styler, comp_styler, prefix, Missing_data = process_Product_files(v6_file,v7_file,IC_file)
        output_filename = os.path.join('uploads', prefix+'PRODDUCT_Highlighted_V7_DEV.xlsx')
        with pd.ExcelWriter(output_filename, engine='openpyxl') as writer:
            stage_summary_styler['v7']['summary'].save_to_excel(writer, sheet_name='v7 DEV - Product Summary')
            Missing_data['v7_Grade'].save_to_excel(writer, sheet_name='v7 DEV - Product Grade')
            stage_summary_styler['v7']['stage'].save_to_excel(writer, sheet_name='v7 DEV - Product Grade Stage')
            spec_styler['v7']['spec'].save_to_excel(writer, sheet_name='v7 DEV - Product Specification')
            if Missing_data['v7_comp_ETDF'] is not None:
                comp_styler['v7']['Compds_ETDF'].save_to_excel(writer, sheet_name='v7 DEV - ETD_F Prdt Cmpds Item')
                Missing_data['v7_compound_ETDF'].save_to_excel(writer, sheet_name='v7 DEV - ETD_F Product Compds')
            if Missing_data['v7_comp_ETDN'] is not None:
                comp_styler['v7']['Compds_ETDN'].save_to_excel(writer, sheet_name='v7 DEV - ETD_N Prdt Cmpds Item')
                Missing_data['v7_compound_ETDN'].save_to_excel(writer, sheet_name='v7 DEV - ETD_N Product Compds')
            if Missing_data['v7_comp_ETDS'] is not None:
                comp_styler['v7']['Compds_ETDS'].save_to_excel(writer, sheet_name='v7 DEV - ETD_S Prdt Cmpds Item')
                Missing_data['v7_compound_ETDS'].save_to_excel(writer, sheet_name='v7 DEV - ETD_S Product Compds')
        output_filename1 = os.path.join('uploads',prefix+'PRODDUCT_Highlighted_V6_DEV.xlsx')
        with pd.ExcelWriter(output_filename1, engine='openpyxl') as writer:
            stage_summary_styler['v6']['summary'].save_to_excel(writer, sheet_name='v6 PROD - Product Summary')
            Missing_data['v6_grade'].save_to_excel(writer, sheet_name='v6 PROD - Product Grade')
            stage_summary_styler['v6']['stage'].save_to_excel(writer, sheet_name='v6 PROD - Product Grade Stage')
            spec_styler['v6']['spec'].save_to_excel(writer, sheet_name='v6 PROD - Product Specification')
            if Missing_data['v6_comp'] is not None:
                comp_styler['v6']['Compds'].save_to_excel(writer, sheet_name='v6 PROD - IC Dimensions')
        # Save individual Excel files and zip them
        # zip_file_path = create_zip_file([output_filename,output_filename1],zip_filename=prefix+'_PRODDUCT_Highlighted_files.zip')